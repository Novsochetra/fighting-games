# python3 sheet.py <dir> <start> <end> <step> <out> [cols] [width]
import sys, os
from PIL import Image
d, a, b, step, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
cols = int(sys.argv[6]) if len(sys.argv) > 6 else 4
w = int(sys.argv[7]) if len(sys.argv) > 7 else 384
idx = list(range(a, b, step))
ims = []
for i in idx:
    for ext in ('png', 'jpg'):
        f = os.path.join(d, f'f_{i:05d}.{ext}')
        if os.path.exists(f):
            im = Image.open(f).convert('RGB')
            ims.append((i, im.resize((w, int(im.height * w / im.width)), Image.NEAREST)))
            break
if not ims: sys.exit('none')
h = ims[0][1].height
rows = (len(ims) + cols - 1) // cols
sheet = Image.new('RGB', (cols * w, rows * (h + 14)), (0, 0, 0))
from PIL import ImageDraw
dr = ImageDraw.Draw(sheet)
for k, (i, im) in enumerate(ims):
    x, y = (k % cols) * w, (k // cols) * (h + 14)
    sheet.paste(im, (x, y + 14))
    dr.text((x + 3, y + 1), str(i), fill=(255, 255, 0))
sheet.save(out)
