# zoomed contact sheet that follows the hero: python3 zsheet.py <shot> <a> <b> <step> <out> [cols] [zoom]
import sys
from PIL import Image, ImageDraw
shot, a, b, step, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
cols = int(sys.argv[6]) if len(sys.argv) > 6 else 5
zoom = float(sys.argv[7]) if len(sys.argv) > 7 else 2.0
log = {}
for line in open(f'out/{shot}/log.txt'):
    r = line.rstrip('\n').split('\t')
    log[int(r[0])] = r
meta_hx = {}
import json
W, H = 768, 432
cw, ch = int(W / zoom), int(H / zoom)
tw = 300
th = int(ch * tw / cw)
idx = list(range(a, b, step))
rows = (len(idx) + cols - 1) // cols
sheet = Image.new('RGB', (cols * tw, rows * (th + 12)))
d = ImageDraw.Draw(sheet)
# hero x is not in log.txt columns; read from frames meta via log hx is missing, so center on x col relative cam
for k, i in enumerate(idx):
    im = Image.open(f'out/{shot}/f_{i:05d}.png').convert('RGB')
    r = log[i]
    cx = W / 2
    try:
        cx = float([c for c in r if c.startswith('hx')][0][2:]) * 2
    except Exception:
        pass
    x0 = int(min(max(cx - cw / 2, 0), W - cw))
    y0 = H - ch - int(20 * 2 / zoom)
    crop = im.crop((x0, max(0, y0), x0 + cw, max(0, y0) + ch)).resize((tw, th), Image.NEAREST)
    x, y = (k % cols) * tw, (k // cols) * (th + 12)
    sheet.paste(crop, (x, y + 12))
    d.text((x + 2, y), f'{i} {r[4]} {r[5]}', fill=(255, 255, 0))
sheet.save(out)
