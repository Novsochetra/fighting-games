# Renders the promo from the EDL in edl.py.
#   python3 compose.py video [--half] [--from F] [--to F]   -> out/promo_video.mp4 (no audio)
#   python3 compose.py stills F1,F2,...  [--half]          -> out/stills/t_F.png
#   python3 compose.py audio                               -> out/sfx.wav (game sound, remapped)
import json, math, os, subprocess, sys, wave
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
FPS = 60
SR = 48000
sys.path.insert(0, HERE)
import edl as EDL  # noqa: E402

ARGS = sys.argv[1:]
HALF = '--half' in ARGS
OW, OH = (960, 540) if HALF else (1920, 1080)
SS = 2  # supersample factor: draw at SS x output, then box-reduce


def arg(name, default=None):
    if name in ARGS:
        return ARGS[ARGS.index(name) + 1]
    return default


# ---------------- sources ----------------
@lru_cache(maxsize=8)
def frames_meta(shot):
    p = os.path.join(OUT, shot, 'frames.json')
    if os.path.exists(p):
        return json.load(open(p))
    return None


@lru_cache(maxsize=48)
def load_frame(shot, i):
    for ext in ('png', 'jpg'):
        p = os.path.join(OUT, shot, f'f_{i:05d}.{ext}')
        if os.path.exists(p):
            return Image.open(p).convert('RGB')
    raise FileNotFoundError(f'{shot} {i}')


@lru_cache(maxsize=64)
def load_title(name):
    return Image.open(os.path.join(HERE, 'titles', f'{name}.png')).convert('RGBA')


def ease_out(x):
    x = min(max(x, 0.0), 1.0)
    return 1 - (1 - x) ** 3


def ease_in_out(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


def interp_keys(keys, t):
    """keys: number or [(t, value), ...] with smoothstep between."""
    if not isinstance(keys, list):
        return keys
    if t <= keys[0][0]:
        return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            if isinstance(v0, (list, tuple)):
                k = ease_in_out((t - t0) / max(1e-9, t1 - t0))
                return tuple(a + (b - a) * k for a, b in zip(v0, v1))
            return v0 + (v1 - v0) * ease_in_out((t - t0) / max(1e-9, t1 - t0))
    return keys[-1][1]


# ---------------- time remap ----------------
def source_positions(clip):
    """Source frame (float) for every output frame of the clip."""
    dur = clip['dur']
    speed = clip.get('speed', 1.0)
    pos = float(clip['src'][1])
    out = []
    for t in range(dur):
        out.append(pos)
        s = speed if not isinstance(speed, list) else step_value(speed, t)
        pos += s
    return out


def step_value(keys, t):
    """piecewise constant [(t, value)]"""
    v = keys[0][1]
    for k, val in keys:
        if t >= k:
            v = val
    return v


# ---------------- camera ----------------
def hero_track(shot, lead=0.0, mix_enemies=0.25, smooth=0.08):
    meta = frames_meta(shot)
    if not meta:
        return None
    xs, ys = [], []
    sx = sy = None
    for f in meta:
        hx = f.get('hx')
        hy = f.get('hy')
        ex = f.get('ex')
        if hx is None:
            hx, hy = 192, 150
        tx = hx * 2
        if ex is not None and abs(ex - hx) < 140:
            tx = (hx * (1 - mix_enemies) + ex * mix_enemies) * 2
        ty = hy * 2 - 60
        if sx is None:
            sx, sy = tx, ty
        sx += (tx - sx) * smooth
        sy += (ty - sy) * smooth * 0.6
        xs.append(sx)
        ys.append(sy)
    return xs, ys


def view_canvas(img, zoom, cx, cy, shake=(0, 0)):
    """img is the 768x432 game canvas; returns an OW x OH view, pixel-crisp."""
    sw, sh = img.size
    zoom = max(zoom, 1.0)
    hw, hh = sw / (2 * zoom), sh / (2 * zoom)
    cx = min(max(cx, hw), sw - hw) + shake[0]
    cy = min(max(cy, hh), sh - hh) + shake[1]
    BW, BH = OW * SS, OH * SS
    scale = BW / sw * zoom
    data = (1 / scale, 0, cx - BW / 2 / scale, 0, 1 / scale, cy - BH / 2 / scale)
    big = img.transform((BW, BH), Image.AFFINE, data, resample=Image.NEAREST)
    return big.reduce(SS)


def render_source(clip, t, srcpos, track):
    shot = clip['src'][0]
    i = int(math.floor(srcpos + 1e-6))
    img = load_frame(shot, i)
    zoom = interp_keys(clip.get('zoom', 1.0), t)
    for fx in clip.get('fx', []):
        if fx[0] == 'punch':
            _, t0, d, amt = fx
            if t0 <= t < t0 + d:
                k = (t - t0) / d
                zoom *= 1 + amt * (1 - k) ** 2
    center = clip.get('center', 'hero')
    sw, sh = img.size
    if center == 'hero' and track:
        k = min(i, len(track[0]) - 1)
        cx, cy = track[0][k], track[1][k]
        off = interp_keys(clip.get('offset', (0, 0)), t)
        cx, cy = cx + off[0], cy + off[1]
    elif center == 'hero':
        cx, cy = sw / 2, sh / 2
    else:
        c = interp_keys(center, t)
        cx, cy = c[0] * sw, c[1] * sh
    whip = clip.get('whip')
    if whip and t >= whip[0]:
        # a whip zoom: the camera rushes to a point, so the next shot can open on it
        t0, d, (tx, ty), z1 = whip
        k = min(1.0, (t - t0) / d) ** 2
        cx += (tx * sw - cx) * k
        cy += (ty * sh - cy) * k
        zoom *= (z1 / zoom) ** k
    sh_amp = 0
    for fx in clip.get('fx', []):
        if fx[0] == 'shake':
            _, t0, d, amp = fx
            if t0 <= t < t0 + d:
                sh_amp = max(sh_amp, amp * (1 - (t - t0) / d))
    rng = np.random.default_rng(t * 7919 + 13)
    shake = (0, 0)
    if sh_amp:
        unit = sw / 768
        shake = (rng.uniform(-1, 1) * sh_amp * unit, rng.uniform(-1, 1) * sh_amp * unit)
    return view_canvas(img, zoom, cx, cy, shake)


# ---------------- effects ----------------
VIGNETTE = None


def vignette():
    global VIGNETTE
    if VIGNETTE is None:
        y, x = np.mgrid[0:OH, 0:OW]
        d = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        VIGNETTE = (1 - 0.32 * np.clip((d - 0.55) / 0.85, 0, 1) ** 1.6)[..., None].astype(np.float32)
    return VIGNETTE


def apply_frame_fx(arr, clip, t):
    """arr float32 HxWx3 0..255"""
    for fx in clip.get('fx', []):
        kind = fx[0]
        if kind == 'flash':
            _, t0, d, strength = fx[:4]
            color = np.array(fx[4] if len(fx) > 4 else (255, 250, 235), np.float32)
            if t0 <= t < t0 + d:
                a = strength * (1 - (t - t0) / d) ** 1.5
                arr = arr * (1 - a) + color * a
        elif kind == 'fadein':
            _, t0, d = fx
            if t < t0 + d:
                arr = arr * ease_in_out((t - t0) / d)
        elif kind == 'fadeout':
            _, t0, d = fx
            if t >= t0:
                arr = arr * (1 - ease_in_out((t - t0) / d))
        elif kind == 'shadeleft':
            _, t0, d = fx
            if t0 <= t < t0 + d:
                k = ease_out((t - t0) / 10)
                ramp = np.clip(np.linspace(0, 1, OW) / 0.6, 0, 1).astype(np.float32)
                arr = arr * (1 - 0.62 * k * (1 - ramp) ** 1.3)[None, :, None]
        elif kind == 'dim':
            _, t0, d, amount = fx
            if t0 <= t < t0 + d:
                arr = arr * (1 - amount)
        elif kind == 'chroma':
            _, t0, d, px = fx
            if t0 <= t < t0 + d:
                s = int(round(px * (1 - (t - t0) / d) * OW / 1920))
                if s:
                    arr[..., 0] = np.roll(arr[..., 0], s, axis=1)
                    arr[..., 2] = np.roll(arr[..., 2], -s, axis=1)
        elif kind == 'bloom':
            _, t0, d, amt = fx
            if t0 <= t < t0 + d:
                arr = bloom(arr, amt)
        elif kind == 'grade':
            _, sat, contrast = fx
            g = arr.mean(axis=2, keepdims=True)
            arr = g + (arr - g) * sat
            arr = (arr - 128) * contrast + 128
    return arr


def bloom(arr, amount):
    small = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).resize((OW // 8, OH // 8), Image.BILINEAR)
    s = np.asarray(small).astype(np.float32)
    s = np.clip(s - 150, 0, 255) * 1.6
    b = Image.fromarray(np.clip(s, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(4))
    b = np.asarray(b.resize((OW, OH), Image.BILINEAR)).astype(np.float32)
    return 255 - (255 - arr) * (255 - b * amount) / 255


def letterbox(arr, h):
    if h <= 0:
        return arr
    px = int(round(h * OH / 1080))
    arr[:px] = 0
    arr[OH - px:] = 0
    return arr


# ---------------- text ----------------
def place_text(base, spec, t):
    # spec: ('text', name, t0, dur, (x, y) as fraction, anim, scale)
    _, name, t0, d, pos = spec[:5]
    anim = spec[5] if len(spec) > 5 else 'fade'
    scale = spec[6] if len(spec) > 6 else 1.0
    if not (t0 <= t < t0 + d):
        return base
    k = t - t0
    img = load_title(name)
    alpha = 1.0
    s = scale
    dx = dy = 0
    if anim == 'slam':
        a = ease_out(k / 7)
        s = scale * (1.9 - 0.9 * a)
        alpha = min(1, k / 3)
    elif anim == 'fade':
        alpha = min(1, k / 14)
        dy = (1 - ease_out(k / 30)) * 18
    elif anim == 'rise':
        alpha = min(1, k / 10)
        dy = (1 - ease_out(k / 18)) * 40
    elif anim == 'drift':
        alpha = min(1, k / 18)
        s = scale * (1 + 0.04 * k / d)
    out_len = spec[7] if len(spec) > 7 else 10
    if k > d - out_len:
        alpha *= max(0, (d - k) / out_len)
    if alpha <= 0:
        return base
    f = OW / 1920 * s
    w, h = max(1, int(img.width * f)), max(1, int(img.height * f))
    im = img.resize((w, h), Image.NEAREST if s >= 1 else Image.BILINEAR)
    if anim == 'wipe':
        reveal = ease_out(k / 22)
        cut = int(w * reveal)
        mask = Image.new('L', (w, h), 0)
        mask.paste(255, (0, 0, cut, h))
        im.putalpha(Image.fromarray((np.asarray(im.split()[3]).astype(np.float32) * (np.asarray(mask) / 255)).astype(np.uint8)))
    if alpha < 1:
        a = np.asarray(im.split()[3]).astype(np.float32) * alpha
        im.putalpha(Image.fromarray(a.astype(np.uint8)))
    x = int(pos[0] * OW - w / 2 + dx * OW / 1920)
    y = int(pos[1] * OH - h / 2 + dy * OH / 1080)
    base.alpha_composite(im, (x, y))
    return base


# ---------------- particles ----------------
def embers(base, t, count=70, seed=3, strength=1.0, color=(255, 190, 110)):
    if strength <= 0:
        return base
    rng = np.random.default_rng(seed)
    layer = Image.new('RGBA', (OW, OH), (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer)
    u = OW / 1920
    for n in range(count):
        x0, y0 = rng.uniform(0, 1), rng.uniform(0, 1)
        sp = rng.uniform(0.6, 1.8)
        size = rng.choice([3, 4, 5, 6]) * u
        ph = rng.uniform(0, 6.28)
        y = (y0 - t * 0.0016 * sp) % 1.1 - 0.05
        x = x0 + 0.02 * math.sin(t * 0.03 * sp + ph)
        a = int(200 * strength * (0.5 + 0.5 * math.sin(t * 0.08 * sp + ph)))
        X, Y = x * OW, y * OH
        dr.rectangle([X, Y, X + size, Y + size], fill=(*color, a))
    glow = layer.filter(ImageFilter.GaussianBlur(3 * u))
    base.alpha_composite(glow)
    base.alpha_composite(layer)
    return base


# ---------------- frame ----------------
TRACKS = {}


def clip_at(frame):
    found = [c for c in EDL.CLIPS if c['at'] <= frame < c['at'] + c['dur']]
    return found[-1] if found else None


POSITIONS = {}


def render_frame(frame):
    clip = clip_at(frame)
    if clip is None:
        base = Image.new('RGBA', (OW, OH), (0, 0, 0, 255))
    else:
        cid = id(clip)
        if cid not in POSITIONS:
            POSITIONS[cid] = source_positions(clip)
        if clip['src'][0] not in TRACKS:
            TRACKS[clip['src'][0]] = hero_track(clip['src'][0])
        t = frame - clip['at']
        img = render_source(clip, t, POSITIONS[cid][t], TRACKS[clip['src'][0]])
        arr = np.asarray(img).astype(np.float32)
        arr = apply_frame_fx(arr, clip, t)
        arr = arr * vignette()
        base = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).convert('RGBA')
        if clip.get('embers'):
            base = embers(base, frame, strength=interp_keys(clip['embers'], t))
    for spec in EDL.TEXTS:
        base = place_text(base, spec, frame)
    arr = np.asarray(base.convert('RGB')).astype(np.float32)
    arr = apply_frame_fx(arr, {'fx': EDL.GLOBAL_FX}, frame)
    lb = interp_keys(EDL.LETTERBOX, frame)
    arr = letterbox(arr, lb)
    return np.clip(arr, 0, 255).astype(np.uint8)


# ---------------- audio ----------------
def read_wav(path):
    w = wave.open(path)
    d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).reshape(-1, 2)
    return d.astype(np.float32) / 32768


def write_wav(path, data):
    d = np.clip(data, -1, 1)
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((d * 32767).astype(np.int16).tobytes())
    w.close()


def build_sfx():
    total = int(EDL.TOTAL / FPS * SR) + SR
    mix = np.zeros((total, 2), np.float32)
    cache = {}
    spf = SR / FPS
    for clip in EDL.CLIPS:
        gain = clip.get('gain', 1.0)
        if not isinstance(gain, list) and gain <= 0:
            continue
        shot = clip['src'][0]
        if shot not in cache:
            p = os.path.join(OUT, shot, 'audio.wav')
            cache[shot] = read_wav(p) if os.path.exists(p) else None
        src = cache[shot]
        if src is None:
            continue
        pos = source_positions(clip)
        seg = np.zeros((int(clip['dur'] * spf), 2), np.float32)
        # read source audio sample by sample following the remap (tape-style: slow = lower pitch)
        out_t = np.arange(len(seg)) / spf
        frame_idx = np.minimum((out_t).astype(int), clip['dur'] - 1)
        frac = out_t - frame_idx
        p0 = np.array(pos)[frame_idx]
        p1 = np.array(pos + [pos[-1] + (pos[-1] - pos[-2] if len(pos) > 1 else 1)])[frame_idx + 1]
        src_t = (p0 + (p1 - p0) * frac) * spf
        frozen = (p1 - p0) < 1e-6
        idx = np.clip(src_t, 0, len(src) - 2)
        i0 = idx.astype(int)
        fr = (idx - i0)[:, None]
        seg = src[i0] * (1 - fr) + src[i0 + 1] * fr
        seg[frozen] = 0
        n = len(seg)
        fade = min(240, n // 2)
        env = np.ones(n, np.float32)
        env[:fade] = np.linspace(0, 1, fade)
        env[-fade:] = np.linspace(1, 0, fade)
        if isinstance(gain, list):
            per_frame = np.array([interp_keys(gain, t) for t in range(clip['dur'] + 1)], np.float32)
            env *= np.interp(np.arange(n) / spf, np.arange(clip['dur'] + 1), per_frame)
            gain = 1.0
        a = int(clip['at'] * spf)
        mix[a:a + n] += seg * env[:, None] * gain
    write_wav(os.path.join(OUT, 'sfx.wav'), mix)
    print('sfx written', mix.shape[0] / SR, 's peak', float(np.abs(mix).max()))


# ---------------- main ----------------
def main():
    mode = ARGS[0]
    if mode == 'audio':
        build_sfx()
        return
    if mode == 'stills':
        os.makedirs(os.path.join(OUT, 'stills'), exist_ok=True)
        for f in [int(x) for x in ARGS[1].split(',')]:
            Image.fromarray(render_frame(f)).save(os.path.join(OUT, 'stills', f't_{f:05d}.png'))
        return
    a = int(arg('--from', 0))
    b = int(arg('--to', EDL.TOTAL))
    name = arg('--name', 'promo_video_half' if HALF else 'promo_video')
    path = os.path.join(OUT, f'{name}.mp4')
    cmd = ['ffmpeg', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{OW}x{OH}',
           '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'medium' if HALF else 'slow',
           '-crf', '22' if HALF else '14', '-pix_fmt', 'yuv420p', '-tune', 'animation', path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    import time
    t0 = time.time()
    for f in range(a, b):
        proc.stdin.write(render_frame(f).tobytes())
        if f % 300 == 0:
            print(f'frame {f} {time.time() - t0:.0f}s', flush=True)
    proc.stdin.close()
    proc.wait()
    print('wrote', path)


if __name__ == '__main__':
    main()
