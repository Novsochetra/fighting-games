# The cut: 60 fps, 120 BPM (a beat is 30 frames, a bar 120), the beat grid counted from the logo hit.
# 'at' and 'dur' are timeline frames, 'src' is (shot, first source frame). speed: number or
# [(t, speed)] steps; zoom/center/offset/gain: [(t, v)]. MARK names the cue points the score follows.
TOTAL = 3600

C = []


def clip(src, at, dur, **kw):
    c = dict(src=src, at=at, dur=dur, **kw)
    C.append(c)
    return c


# the game flashes on its own big hits, so the cut's flash stays light
def hit(t, flash=0.6, shake=4, chroma=10, punch=0.06, dur=10):
    return [('flash', t, dur, flash * 0.55), ('shake', t, dur + 8, shake), ('chroma', t, 8, chroma),
            ('punch', t, 10, punch)]


DROP = [('flash', 0, 9, 0.85)]

L = 82  # the logo lands
S = 60  # everything after the Naga dash sits this much later than in the first cut
MARK = dict(logo=L, click=L + 105, select=L + 120, choose=L + 258, angkor_in=L + 300, drop1=L + 480,
            boss1=982, ndash=1012, nhit=1051, ncrush=1134, kill1=1278, breakdown=1342, finale=1402,
            drop2=1462, aw=1762, aw_ult=1852, seven=2124, montage=2182, guardian=2482, gdash=2542,
            ghit=2581, ult=2676, combo_zoom=3090, rise=3131, card=3158, windup=3184, black=3272,
            endcard=3288)
D = 158  # the title shot's frames run this far ahead of the timeline

# ---------- the title, straight into the dusk (0-562) ----------
clip(('title', 158), 0, L, zoom=[(0, 1.08), (L, 1.02)], center=[(0, (0.5, 0.47)), (L, (0.5, 0.46))],
     fx=[('fadein', 0, 18)], embers=[(0, 0.5), (40, 0.9)], gain=0)
clip(('title', 240), L, 120, zoom=[(0, 1.0), (100, 1.06)], center=(0.5, 0.47),
     fx=[('flash', 3, 16, 0.55), ('shake', 3, 22, 3), ('chroma', 3, 8, 12),
         ('punch', 104, 12, 0.08), ('flash', 104, 16, 0.95)],
     embers=1.0, gain=1.0)
STEPS = [12, 27, 42, 57, 80, 110]
clip(('title', 360), 360 - D, 120, zoom=1.42, center=(0.5, 0.56),
     fx=[('fadein', 0, 6)] + [('punch', s, 8, 0.025) for s in STEPS], gain=1.0)
clip(('title', 480), 480 - D, 60, speed=[(0, 1), (22, 0)],
     zoom=[(0, 1.42), (24, 2.1)], center=[(0, (0.5, 0.56)), (24, (0.405, 0.575))],
     fx=[('flash', 20, 10, 0.5), ('shadeleft', 18, 42), ('flash', 54, 6, 1.0)], gain=1.0)
clip(('title', 540), 540 - D, 174, zoom=[(0, 1.0), (80, 1.1), (174, 2.4)],
     center=[(0, (0.5, 0.5)), (80, (0.45, 0.52)), (174, (0.245, 0.7))],
     fx=[('flash', 0, 12, 0.75), ('fadeout', 164, 10)], gain=1.0)

# ---------- Angkor Wat (562-1342) ----------
clip(('angkorA', 2275), 562, 120, zoom=1.8, speed=[(0, 1), (27, 0.35), (47, 1)],
     fx=DROP + hit(0, 0.0, 5) + hit(27, 0.5, 4), gain=1.0)
clip(('angkorA', 2177), 682, 90, zoom=1.7, offset=(0, -30), speed=[(0, 1), (27, 0.4), (40, 1)],
     fx=hit(0, 0.4, 3) + hit(27, 0.4, 3), gain=1.0)
clip(('angkorB', 1056), 772, 90, zoom=1.6, speed=[(0, 1), (18, 0.5), (40, 1)],
     fx=hit(0, 0.4, 3) + hit(18, 0.6, 5, 14, 0.08) + [('bloom', 18, 40, 0.35)], gain=1.0)
clip(('angkorB', 430), 862, 120, zoom=[(0, 1.35), (120, 1.5)], speed=[(0, 1), (14, 0.5), (40, 1)],
     fx=hit(0, 0.3, 2, 6, 0.03) + hit(14, 0.5, 4) + [('bloom', 14, 30, 0.4)], gain=1.0)
# the Naga Raja walks in; Bokator dashes at it on the beat and opens with the Dash Elbow's lion
clip(('naga_dash', 2), 982, 180, speed=[(0, 1), (69, 0.4), (109, 1), (152, 0.4)],
     zoom=[(0, 1.02), (30, 1.08), (64, 1.2), (69, 1.4), (109, 1.3), (152, 1.45), (180, 1.4)],
     fx=[('flash', 0, 12, 0.8), ('shake', 0, 26, 4), ('chroma', 0, 10, 14), ('chroma', 30, 8, 8)]
     + hit(69, 0.6, 6, 16, 0.08) + [('bloom', 69, 40, 0.35)] + hit(152, 0.5, 5, 12, 0.06),
     gain=[(0, 1), (69, 1), (75, 0.6), (109, 1)])
clip(('naga', 340), 1162, 60, zoom=[(0, 1.2), (60, 1.4)], speed=[(0, 1), (32, 0.4)],
     fx=hit(0, 0.4, 3) + hit(32, 0.6, 5, 14, 0.07), gain=1.0)
clip(('naga', 596), 1222, 48, zoom=1.6, fx=hit(0, 0.5, 4) + [('bloom', 0, 48, 0.3)], gain=1.0)
clip(('naga', 1072), 1270, 72, zoom=[(0, 1.6), (72, 1.15)], speed=[(0, 1), (8, 0.3), (30, 1)],
     fx=hit(0, 0.4, 4) + hit(8, 0.9, 7, 16, 0.1), gain=1.0)

# ---------- on to the Bayon (1342-1462) ----------
clip(('naga', 1262), 1342, 120, zoom=[(0, 1.25), (120, 1.0)], gain=0.8)

# ---------- Bokator at the Bayon (1462-1762) ----------
clip(('bayonB', 955), 1462, 120, zoom=1.7, speed=[(0, 1), (26, 0.45), (60, 1)],
     fx=DROP + hit(0, 0.0, 6) + hit(26, 0.6, 5, 14, 0.08) + [('bloom', 26, 50, 0.35)], gain=1.0)
clip(('bayonB', 835), 1582, 90, zoom=1.75, speed=[(0, 1), (22, 0.5), (50, 1)],
     fx=hit(0, 0.4, 3) + hit(22, 0.5, 4), gain=1.0)
clip(('bayonA', 1008), 1672, 90, zoom=1.6, speed=[(0, 1), (11, 0.45), (45, 1)],
     fx=hit(0, 0.4, 3) + hit(11, 0.6, 5, 14, 0.08) + [('bloom', 11, 40, 0.35)], gain=1.0)

# ---------- the Angkor Warrior and the March of the Bayon (1762-2182) ----------
clip(('aw_bayon', 470), 1762, 90, zoom=1.7, speed=[(0, 1), (23, 0.5), (50, 1)],
     fx=DROP + hit(0, 0.0, 5) + hit(23, 0.6, 5, 14, 0.08) + [('bloom', 23, 40, 0.3)], gain=1.0)
AW_ULT = clip(('ult_angkor_bayon', 14), 1852, 330,
              speed=[(0, 1), (30, 0.6), (60, 1), (150, 0.5), (210, 1), (270, 0)],
              zoom=[(0, 1.0), (30, 1.0), (40, 1.15), (150, 1.1), (200, 1.3), (230, 1.1), (270, 1.0)],
              fx=[('flash', 0, 6, 0.5)] + hit(36, 0.5, 5, 12, 0.06) + hit(202, 0.0, 8, 4, 0.1)
              + [('bloom', 36, 150, 0.3), ('dim', 270, 60, 0.55)], gain=1.0)

# ---------- five Shades, five ultimates (2182-2482) ----------
MONTAGE = [('moss', 130), ('firefly', 148), ('antler', 141), ('blue', 156), ('ember', 196)]
for n, (hero, peak) in enumerate(MONTAGE):
    at = MARK['montage'] + n * 60
    clip((f'ult_{hero}', 10), at, 16, zoom=1.0, fx=[('flash', 0, 4, 0.4)], gain=0.9)
    clip((f'ult_{hero}', peak), at + 16, 44, zoom=1.35, fx=hit(0, 0.0, 5, 10, 0.06) + [('bloom', 0, 44, 0.25)],
         gain=0.9)

# ---------- the finale, one take: the Guardian walks in, Bokator dashes at him on the beat, opens with
# the Dash Elbow's lion and a string, answers with Pounding the Lion, and the Guardian rises (2482-3272)
FIN_ULT = 192  # the take's first frame of the ultimate, as the first cut's climax shot counted it
clip(('finale', 30), 2482, 194, speed=[(0, 1), (15, 0.6), (60, 1), (99, 0.4), (123, 1)],
     zoom=[(0, 1.0), (60, 1.12), (94, 1.2), (99, 1.45), (123, 1.32), (170, 1.28), (194, 1.0)],
     fx=[('flash', 0, 10, 0.9), ('shake', 0, 30, 5), ('chroma', 0, 12, 16), ('chroma', 60, 8, 8)]
     + hit(99, 0.6, 6, 16, 0.08) + [('bloom', 99, 30, 0.35)]
     + [('punch', 141 - 120 + 123, 8, 0.03), ('punch', 154 - 120 + 123, 8, 0.03), ('punch', 169 - 120 + 123, 8, 0.04)],
     gain=[(0, 1), (15, 1), (24, 0.4), (56, 0.4), (60, 1), (99, 1), (106, 0.6), (123, 1)])
ULT_SPEED = [(0, 1), (57, 0), (65, 0.6), (123, 0.5), (235, 0.7), (278, 0), (292, 0.5), (372, 0.6),
             (400, 1), (470, 0.8), (508, 0.235)]
clip(('finale', FIN_ULT), 2676, 596, speed=ULT_SPEED,
     zoom=[(0, 1.0), (50, 1.0), (57, 1.35), (120, 1.2), (235, 1.1), (278, 1.3), (292, 1.6), (320, 1.25),
           (372, 1.12), (400, 1.12), (414, 2.4), (450, 2.6), (466, 1.0), (530, 1.0), (596, 1.6)],
     center=[(0, (0.5, 0.5)), (50, (0.5, 0.5)), (57, (0.37, 0.62)), (120, (0.45, 0.6)), (235, (0.5, 0.6)),
             (278, (0.47, 0.64)), (292, (0.47, 0.66)), (372, (0.45, 0.6)), (400, (0.45, 0.6)),
             (414, (0.85, 0.27)), (450, (0.85, 0.27)), (466, (0.5, 0.5)), (530, (0.5, 0.5)), (596, (0.16, 0.6))],
     fx=hit(57, 0.7, 8, 22, 0.12, 10) + hit(292, 0.9, 10, 26, 0.18, 12) + [('dim', 278, 14, 0.25)]
     + [('bloom', 57, 300, 0.3), ('chroma', 404, 12, 18), ('chroma', 452, 14, 18), ('flash', 414, 8, 0.4),
        ('shake', 414, 14, 3), ('chroma', 584, 12, 10), ('shake', 560, 36, 3)]
     + [('punch', t, 6, 0.02) for t in range(130, 230, 14)],
     gain=[(0, 1), (296, 1), (310, 0.3), (400, 0.5), (500, 0.5), (508, 0.3)])

# ---------- the end card (3288-3600) ----------
clip(('endcard', 26), 3288, 312, zoom=[(0, 1.34), (312, 1.27)], center=(0.5, 0.6),
     fx=[('flash', 6, 18, 0.7), ('shake', 6, 20, 2), ('dim', 0, 312, 0.18)], embers=[(0, 0.4), (60, 1.0)], gain=0)

CLIPS = C

# (name, start, dur, (x, y), anim, scale, out_frames)
TEXTS = [
    ('text', 'ends_angkor', 4, 76, (0.5, 0.80), 'fade', 1.0),
    ('text', 'bokator', 498 - D, 44, (0.27, 0.42), 'slam', 0.85, 6),
    ('text', 'bokator_sub', 508 - D, 34, (0.27, 0.60), 'rise', 0.72, 6),
    ('text', 'strike', 747 - D, 50, (0.5, 0.5), 'slam', 1.0, 8),
    ('text', 'launch', 867 - D, 50, (0.5, 0.5), 'slam', 1.0, 8),
    ('text', 'pounce', 948 - D, 54, (0.5, 0.5), 'slam', 1.0, 8),
    ('text', 'every_road', 1104, 70, (0.5, 0.88), 'fade', 1.0),
    ('text', 'finale', 1500 - D + S, 60, (0.5, 0.80), 'rise', 1.0),
    ('text', 'angkor_warrior', 1766, 62, (0.5, 0.2), 'slam', 0.78, 8),
    ('text', 'angkor_sub', 1776, 52, (0.5, 0.36), 'rise', 0.8, 8),
    ('text', 'seven', MARK['seven'], 58, (0.5, 0.42), 'slam', 1.0, 4),
    ('text', 'seven_ult', MARK['seven'] + 22, 36, (0.5, 0.58), 'slam', 1.0, 4),
    ('text', 'final_boss', 2492, 64, (0.5, 0.88), 'fade', 1.0),
    ('text', 'tag1', 3328, 272, (0.5, 0.63), 'wipe', 1.0, 1),
    ('text', 'tag2', 3388, 212, (0.5, 0.73), 'slam', 1.0, 1),
    ('text', 'controls', 3438, 162, (0.5, 0.82), 'fade', 1.0, 1),
]

LETTERBOX = [(0, 0), (2668, 0), (2688, 96), (3076, 96), (3090, 0)]

GLOBAL_FX = [('fadeout', 3560, 40)]
