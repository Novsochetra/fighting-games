Steel & Dust promo: how it is made (re-render after the game changes)

Needs: the dev server (PROMO_BASE=http://localhost:PORT/ picks it; default 8766), Node 22,
Playwright (from the npx cache path in capture.mjs), Python 3 with numpy, scipy and Pillow, ffmpeg.

1. Record the shots (frames + game sound) into out/<shot>/:
     node capture.mjs <shot>      shots: title endcard angkorA angkorB bayonA bayonB naga guardian
                                  finale naga_dash aw_bayon ult_angkor_bayon ult_moss ult_firefly ult_antler ult_blue ult_ember ult_angkor
2. Render the text cards in the game's pixel font:   node titles.mjs
3. Edit the cut in edl.py, then:
     python3 compose.py stills 720,2400 --half   (check frames)
     python3 music.py                              (the score -> out/music.wav)
     python3 compose.py audio                      (game sound, remapped -> out/sfx.wav)
     python3 compose.py video                      (picture -> out/promo_video.mp4)
     python3 master.py                             (mix, -14 LUFS, mux -> out/steel-and-dust-promo.mp4)
