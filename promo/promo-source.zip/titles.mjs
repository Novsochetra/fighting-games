// Renders the promo's text cards as transparent PNGs, set in the game's own font and colors
import { chromium } from '/Users/sochetranov/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'titles');
fs.mkdirSync(outDir, { recursive: true });

// name, text (| = line break), style, px size, letter spacing (em)
const CARDS = [
  ['one_road', 'ONE ROAD. TWELVE MISSIONS.', 'white', 44, 0.18],
  ['ends_angkor', 'IT ENDS AT ANGKOR.', 'gold', 64, 0.14],
  ['bokator', 'BOKATOR', 'carved', 120, 0.08],
  ['bokator_sub', 'POUNDS THE LION, AS ANGKOR TAUGHT', 'white', 34, 0.16],
  ['strike', 'STRIKE.', 'gold', 150, 0.06],
  ['launch', 'LAUNCH.', 'gold', 150, 0.06],
  ['pounce', 'POUNCE.', 'gold', 150, 0.06],
  ['every_road', 'A BOSS AT THE END OF EVERY ROAD', 'white', 40, 0.16],
  ['finale', 'THE FINALE', 'carved', 64, 0.3],
  ['angkor_warrior', 'ANGKOR WARRIOR', 'carved', 96, 0.08],
  ['angkor_sub', 'STEPS OUT OF THE BAYON WALLS', 'white', 34, 0.16],
  ['seven', 'SEVEN HEROES.', 'gold', 110, 0.06],
  ['seven_ult', 'SEVEN ULTIMATES.', 'white', 110, 0.06],
  ['final_boss', 'THE LAST FACE OF THE BAYON', 'white', 40, 0.16],
  ['tag1', '7 HEROES  ·  12 MISSIONS  ·  19 KINDS OF RAIDERS', 'white', 34, 0.12],
  ['tag2', 'PLAY FREE IN YOUR BROWSER', 'gold', 52, 0.12],
  ['url', 'NOVSOCHETRA.GITHUB.IO/FIGHTING-GAMES', 'white', 36, 0.1],
  ['controls', 'KEYBOARD  ·  GAMEPAD  ·  TOUCH', 'white', 28, 0.2],
];

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1920, height: 1080 },
  deviceScaleFactor: 1,
});
const page = await context.newPage();
await page.goto(`${process.env.PROMO_BASE || 'http://localhost:8766/'}games/steel-and-dust/`, { waitUntil: 'load' });
await page.evaluate(() => document.fonts.ready);
await page.addStyleTag({
  content: `
  #app, #loader { display: none !important; }
  html, body { background: transparent !important; }
  #card { position: fixed; left: 0; top: 0; padding: 24px 40px; white-space: nowrap;
    font-family: var(--font-display); font-weight: 700; line-height: 1.1; text-align: center; }
  #card.gold { color: var(--color-gold); text-shadow: var(--text-shadow-logo); }
  #card.carved { margin: 0; color: var(--color-gold); text-shadow: var(--text-shadow-logo); --stone: 3; }
  #card.white { color: var(--color-text); text-shadow: 3px 3px 0 var(--color-shadow); }
`,
});
await page.evaluate(async () => {
  const card = document.createElement('div');
  card.id = 'card';
  document.body.appendChild(card);
  await document.fonts.load('700 40px Silkscreen');
});

for (const [name, text, style, size, spacing] of CARDS) {
  await page.evaluate(
    ([text, style, size, spacing]) => {
      const card = document.getElementById('card');
      card.className = style === 'carved' ? 'mtitle good carved' : style;
      card.style.fontSize = `${size}px`;
      card.style.letterSpacing = `${spacing}em`;
      card.innerHTML = text.split('|').join('<br>');
    },
    [text, style, size, spacing],
  );
  const shot = await page.locator('#card').screenshot({ omitBackground: true });
  fs.writeFileSync(path.join(outDir, `${name}.png`), shot);
}
console.log('rendered', CARDS.length, 'cards');
await browser.close();
