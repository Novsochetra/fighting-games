# The promo score, synthesized: temple drone and gongs, roneat (Khmer xylophone), sralai (Khmer
# oboe), skor drums and taiko, braams, risers. 120 BPM, A minor pentatonic. Cues follow edl.py.
#   python3 music.py  -> out/music.wav
import json, os, sys, wave
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import edl as EDL  # noqa: E402

SR = 48000
FPS = 60
LEN = int((EDL.TOTAL / FPS + 3) * SR)
rng = np.random.default_rng(11)

BUS = {k: np.zeros((LEN, 2), np.float32) for k in ('drums', 'music', 'fx', 'pad')}


def f2s(frame):
    return int(frame / FPS * SR)


def beat(b):  # beat number from the start (120 BPM)
    return b * 30


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def add(bus, at_frame, sig, pan=0.0, gain=1.0):
    a = f2s(at_frame) if not isinstance(at_frame, tuple) else at_frame[0]
    if sig.ndim == 1:
        l = np.sqrt(0.5 * (1 - pan))
        r = np.sqrt(0.5 * (1 + pan))
        sig = np.stack([sig * l, sig * r], 1)
    b = min(LEN, a + len(sig))
    if b > a:
        BUS[bus][a:b] += sig[: b - a] * gain


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def noise(n):
    return rng.standard_normal(n).astype(np.float32)


def bp(x, lo, hi, order=2):
    sos = butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return sosfilt(sos, x)


def lp(x, f, order=2):
    return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)


def hp(x, f, order=2):
    return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)


def sweep_filter(x, f0, f1, kind='band', width=1.0, block=512):
    """time-varying filter (exponential sweep), block by block"""
    out = np.zeros_like(x)
    n = len(x)
    zi = None
    for a in range(0, n, block):
        k = a / max(1, n - 1)
        f = f0 * (f1 / f0) ** k
        if kind == 'band':
            lo, hi = f / (1 + width), min(SR / 2 - 100, f * (1 + width))
            sos = butter(2, [lo, hi], btype='band', fs=SR, output='sos')
        else:
            sos = butter(2, min(f, SR / 2 - 100), btype='low', fs=SR, output='sos')
        if zi is None or zi.shape[0] != sos.shape[0]:
            zi = np.zeros((sos.shape[0], 2))
        out[a:a + block], zi = sosfilt(sos, x[a:a + block], zi=zi)
    return out


# ---------------- instruments ----------------
def kick(amp=1.0, low=1.0):
    t = tt(0.45)
    f = 46 * low + 140 * np.exp(-t / 0.025)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.22)
    click = hp(noise(len(t)), 2000) * np.exp(-t / 0.004) * 0.4
    return np.tanh(2.2 * (s + click)) * amp * 0.9


def taiko(amp=1.0, pitch=1.0, dur=1.1):
    t = tt(dur)
    f = 62 * pitch + 60 * pitch * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t / 0.32) + 0.3 * np.sin(2.3 * ph) * np.exp(-t / 0.12)
    skin = bp(noise(len(t)), 250, 1400) * np.exp(-t / 0.05) * 0.6
    return np.tanh(1.6 * (body + skin)) * amp * 0.8


def skor(amp=1.0, pitch=1.0):  # the higher, tighter barrel drum
    t = tt(0.35)
    f = 150 * pitch + 90 * np.exp(-t / 0.015)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.09)
    slap = bp(noise(len(t)), 900, 4000) * np.exp(-t / 0.012) * 0.5
    return (s + slap) * amp * 0.5


def snare(amp=1.0):
    t = tt(0.4)
    tone = np.sin(2 * np.pi * 185 * t) * np.exp(-t / 0.05)
    nz = bp(noise(len(t)), 1500, 7500) * np.exp(-t / 0.13)
    return np.tanh(1.4 * (0.5 * tone + nz)) * amp * 0.45


def hat(amp=1.0, open_=False):
    t = tt(0.3 if open_ else 0.06)
    s = hp(noise(len(t)), 7500) * np.exp(-t / (0.09 if open_ else 0.016))
    return s * amp * 0.16


def crash(amp=1.0, dur=2.6):
    t = tt(dur)
    s = hp(noise(len(t)), 3500) * np.exp(-t / 0.9)
    metal = sum(np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) for f in (3120, 4470, 5530, 6890)) * 0.05
    return (s + metal * np.exp(-t / 0.7)) * amp * 0.3


def sub_boom(amp=1.0, dur=2.4):
    t = tt(dur)
    f = 30 + 85 * np.exp(-t / 0.12)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.9)
    s = np.tanh(2.5 * s) * 0.8
    rumble = lp(noise(len(t)), 180) * np.exp(-t / 0.5) * 1.5
    return (s + rumble) * amp


def additive(freq_curve, dur, harmonics, amp_fn, env):
    """freq_curve: array of f0 per sample; amp_fn(k, f0, t) -> amplitude per sample"""
    t = tt(dur)
    ph = 2 * np.pi * np.cumsum(freq_curve) / SR
    out = np.zeros(len(t))
    for k in range(1, harmonics + 1):
        a = amp_fn(k, freq_curve, t)
        if np.max(np.abs(a)) < 1e-4:
            continue
        out += a * np.sin(k * ph)
    return out * env


def braam(root=33, amp=1.0, dur=2.2, dark=False):
    """the big low brass: detuned saws whose brightness swells and dies"""
    t = tt(dur)
    notes = [root, root + 7, root + 12] if not dark else [root, root + 1, root + 12]
    out = np.zeros(len(t))
    cutoff = 180 + 2600 * np.exp(-t / 0.35) * (1 - np.exp(-t / 0.02)) + 300 * np.exp(-t / 1.5)
    for m in notes:
        for det in (-0.004, 0.0, 0.005):
            f0 = mtof(m) * (1 + det) * np.ones(len(t))
            def amp_fn(k, f, tt_, c=cutoff):
                return (1 / k) / (1 + np.exp((k * f - c) / 120))
            out += additive(f0, dur, 40, amp_fn, 1)
    env = (1 - np.exp(-t / 0.015)) * np.exp(-t / 0.9)
    s = np.tanh(out * env * 0.35)
    return s * amp


def roneat(m, amp=1.0, dur=0.9):
    """a struck bar: the bar's own inharmonic partials, quick decay, mallet click"""
    t = tt(dur)
    f = mtof(m)
    s = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.42)
         + 0.32 * np.sin(2 * np.pi * f * 3.93 * t) * np.exp(-t / 0.09)
         + 0.1 * np.sin(2 * np.pi * f * 9.2 * t) * np.exp(-t / 0.03)
         + 0.25 * np.sin(2 * np.pi * f * 2 * t) * np.exp(-t / 0.2))
    click = bp(noise(len(t)), 2000, 8000) * np.exp(-t / 0.003) * 0.3
    return (s + click) * amp * 0.28


def gong(f0=82, amp=1.0, dur=6.0):
    t = tt(dur)
    ratios = [1, 1.47, 2.09, 2.56, 3.18, 4.21, 5.3]
    out = np.zeros(len(t))
    for i, r in enumerate(ratios):
        f = f0 * r * (1 + 0.012 * np.exp(-t / 0.3))
        ph = 2 * np.pi * np.cumsum(f) / SR
        decay = 3.6 / (1 + i * 0.5)
        beat_ = 1 + 0.15 * np.sin(2 * np.pi * (0.7 + i * 0.4) * t)
        out += np.sin(ph) * np.exp(-t / decay) * beat_ / (1 + i * 0.6)
    strike = lp(noise(len(t)), 1200) * np.exp(-t / 0.03) * 0.6
    swell = 1 - 0.5 * np.exp(-t / 0.08)
    return (out * swell + strike) * amp * 0.35


def sralai_phrase(notes, amp=1.0, glide=0.07):
    """notes: [(start_sec, dur_sec, midi)]; one breathing line with glides and vibrato"""
    total = max(s + d for s, d, _ in notes) + 0.3
    n = int(total * SR)
    t = np.arange(n) / SR
    f = np.zeros(n)
    gate = np.zeros(n)
    prev = None
    for s, d, m in notes:
        a, b = int(s * SR), int((s + d) * SR)
        target = mtof(m)
        if prev is None:
            f[a:b] = target
        else:
            g = min(int(glide * SR), b - a)
            f[a:a + g] = np.linspace(prev, target, g)
            f[a + g:b] = target
        gate[a:b] = 1
        prev = target
    # fill gaps with the last pitch so the phase runs on
    last = f[0] or mtof(notes[0][2])
    for i in range(n):
        if f[i] == 0:
            f[i] = last
        last = f[i]
    vib = 1 + 0.007 * np.sin(2 * np.pi * 5.6 * t) * np.clip((t % 10) * 3, 0, 1)
    f = f * vib
    env = lp(gate, 18)
    formants = [(720, 1.0, 180), (1250, 0.7, 220), (2650, 0.35, 300)]

    def amp_fn(k, f0, tt_):
        hf = k * f0
        g = sum(w * np.exp(-((hf - c) / bw) ** 2) for c, w, bw in formants) + 0.08 / k
        return g * (hf < 9000)
    s = additive(f, total, 28, amp_fn, env)
    s = np.tanh(s * 1.8) * 0.5
    return s * amp


def choir(midis, dur, amp=1.0, attack=0.8):
    t = tt(dur)
    out = np.zeros(len(t))
    formants = [(760, 1.0, 320), (1150, 0.5, 340), (2800, 0.12, 520)]
    morph = 1 + 0.09 * np.sin(2 * np.pi * 0.21 * t)
    for m in midis:
        for det in (-0.006, 0.0, 0.007):
            f0 = mtof(m) * (1 + det) * (1 + 0.004 * np.sin(2 * np.pi * 4.8 * t + det * 900))

            def amp_fn(k, f, tt_):
                hf = k * f
                return sum(w * np.exp(-((hf - c * morph) / bw) ** 2) for c, w, bw in formants) + 0.05 / k
            out += additive(f0, dur, 20, amp_fn, 1)
    env = (1 - np.exp(-t / attack)) * np.clip((dur - t) / 0.8, 0, 1)
    return lp(out, 3500) * env * amp * 0.05


def drone(root, dur, amp=1.0, bright=500):
    t = tt(dur)
    out = np.zeros(len(t))
    lfo = 1 + 0.4 * np.sin(2 * np.pi * 0.12 * t)
    for m in (root, root + 7, root + 12):
        for det in (-0.003, 0.004):
            f0 = mtof(m) * (1 + det) * np.ones(len(t))

            def amp_fn(k, f, tt_):
                return (1 / k) / (1 + np.exp((k * f - bright * lfo) / 90))
            out += additive(f0, dur, 24, amp_fn, 1)
    env = np.clip(t / 2.0, 0, 1) * np.clip((dur - t) / 1.5, 0, 1)
    return out * env * amp * 0.12


def bass_note(m, dur, amp=1.0):
    t = tt(dur)
    f0 = mtof(m) * np.ones(len(t))
    cutoff = 250 + 900 * np.exp(-t / 0.06)

    def amp_fn(k, f, tt_):
        return (1 / k) / (1 + np.exp((k * f - cutoff) / 60))
    s = additive(f0, dur, 18, amp_fn, 1)
    env = (1 - np.exp(-t / 0.004)) * np.exp(-t / 0.35) * np.clip((dur - t) / 0.01, 0, 1)
    return np.tanh(s * env * 1.5) * amp * 0.5


def riser(dur, amp=1.0, f0=300, f1=9000):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = sweep_filter(noise(n), f0, f1, 'band', 0.6)
    tone_f = 180 * (6 ** (t / dur))
    tone = np.sin(2 * np.pi * np.cumsum(tone_f) / SR) * 0.25
    env = (t / dur) ** 2.2
    return (s * 0.9 + tone) * env * amp * 0.5


def whoosh(dur=0.45, amp=1.0, up=True):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = sweep_filter(noise(n), 400 if up else 5000, 5000 if up else 400, 'band', 0.8)
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return s * env * amp * 0.6


def reverse_crash(dur=1.2, amp=1.0):
    return crash(amp, dur)[::-1].copy()


def heartbeat(amp=1.0):
    k1 = kick(amp, low=0.8)
    k2 = kick(amp * 0.7, low=0.8)
    out = np.zeros(int(0.7 * SR))
    out[: len(k1)] += k1[: len(out)]
    o = int(0.22 * SR)
    out[o:o + len(k2)] += k2[: len(out) - o]
    return lp(out, 220)


def wind(dur, amp=1.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = lp(noise(n), 700)
    mod = 0.6 + 0.4 * np.sin(2 * np.pi * 0.17 * t) * np.sin(2 * np.pi * 0.05 * t + 1)
    return s * mod * np.clip(t / 2, 0, 1) * np.clip((dur - t) / 1.5, 0, 1) * amp * 0.35


# ---------------- arrangement ----------------
def impact(frame, size=1.0, braam_root=None, dark=False, gong_=False):
    add('fx', frame, sub_boom(0.65 * size))
    add('drums', frame, taiko(1.0 * size, 0.9))
    add('drums', frame, crash(0.7 * size), pan=0.2)
    if braam_root is not None:
        add('music', frame, braam(braam_root, 0.8 * size, dark=dark))
    if gong_:
        add('music', frame, gong(73, 0.8 * size))


def groove(start, end, intensity=1.0, hats16=False):
    """the drop: taiko/skor pattern, kick, snare backbeat, hats, bass pumping on 8ths"""
    roots = [33, 33, 29, 31]  # A A F G (a bar each)
    b = 0
    for f in range(start, end, 15):  # every 8th note
        k = (f - start) // 15  # 8th index
        pos = k % 8
        bar = (f - start) // 120
        if pos in (0, 3, 5):
            add('drums', f, kick(0.9 * intensity))
        if pos in (2, 6):
            add('drums', f, snare(0.9 * intensity), pan=0.05)
        if pos in (0, 4):
            add('drums', f, taiko(0.55 * intensity, 1.0))
        if pos in (1, 3, 6, 7):
            add('drums', f, skor(0.5 * intensity, 1.0 + 0.15 * (pos % 2)), pan=-0.3)
        add('drums', f, hat(0.8 * intensity, open_=(pos % 2 == 1)), pan=0.35)
        if hats16:
            add('drums', f + 7.5, hat(0.5 * intensity), pan=0.4)
        root = roots[bar % 4]
        add('music', f, bass_note(root + (12 if pos in (3, 7) else 0), 0.24, 0.8 * intensity))
        b += 1


RIFF = [76, None, 69, 72, 74, None, 76, 79, 81, 79, 76, 74, 76, None, 72, 74]  # two bars of 8ths


def riff(start, end, amp=0.8, octave=0):
    for f in range(start, end, 15):
        k = ((f - start) // 15) % 16
        m = RIFF[k]
        if m is None:
            continue
        add('music', f, roneat(m + octave, amp), pan=-0.25)
        add('music', f, roneat(m + octave - 12, amp * 0.5), pan=0.25)


def tremolo(start, end, notes, amp=0.4):
    """the roneat's rolled tremolo on held notes"""
    i = 0
    for f in np.arange(start, end, 3.75):
        m = notes[int((f - start) // 60) % len(notes)]
        add('music', (f2s(f),), roneat(m + (12 if i % 2 else 0), amp * (0.8 + 0.2 * (i % 2)), 0.4), pan=0.1 * (-1) ** i)
        i += 1


def build():
    M = EDL.MARK
    L = M['logo']
    # the dusk: drone, wind and a few roneat notes, rising into the logo
    add('pad', 0, drone(33, 6.0, 0.45, 380))
    add('fx', 0, wind(5.5, 0.5))
    add('music', 1, gong(65, 0.5))
    for f, m in [(7, 74), (22, 72), (52, 69)]:
        add('music', f, roneat(m, 0.4), pan=-0.2)
    add('fx', 4, riser(1.3, 0.6))
    impact(L, 1.1, braam_root=33, gong_=True)
    for d in (30, 60, 75, 90, 97, 105):
        add('drums', L + d, taiko(0.6 if d < 90 else 0.8, 1.1))
    add('fx', M['click'], whoosh(0.3, 0.8))
    add('drums', M['click'], crash(0.5))
    # hero select
    sel = M['select']
    for f in range(sel, sel + 120, 30):
        add('drums', f, kick(0.8))
        add('drums', f + 15, hat(0.7, True), pan=0.3)
    for f in range(sel, sel + 120, 15):
        add('drums', f + 7, hat(0.5), pan=-0.3)
        add('music', f, bass_note(33, 0.2, 0.6))
    tremolo(sel, sel + 120, [69, 72, 74, 76], 0.25)
    impact(M['choose'], 0.9, braam_root=33)
    add('music', M['choose'], choir([57, 64, 69], 2.0, 1.0, 0.1))
    add('fx', M['choose'] + 36, whoosh(0.25, 0.9))
    # into Angkor Wat, a two-bar build
    a = M['angkor_in']
    add('music', a, gong(82, 0.5))
    add('pad', a, choir([57, 60, 64], 3.2, 0.8, 1.2))
    add('fx', a + 20, riser(2.55, 1.0))
    roll = [a + i * 30 for i in range(4)] + [a + 120 + i * 15 for i in range(4)] + [a + 150 + i * 7.5 for i in range(3)]
    for i, f in enumerate(roll):
        add('drums', (f2s(f),), snare(0.3 + 0.5 * i / len(roll)), pan=0.1)
        add('drums', (f2s(f),), taiko(0.3 + 0.4 * i / len(roll), 1.2))
    add('fx', a + 110, reverse_crash(1.05, 0.8))
    # the first drop: Angkor Wat
    d1 = M['drop1']
    impact(d1, 1.2, braam_root=33, gong_=True)
    groove(d1, M['breakdown'])
    riff(d1, M['breakdown'])
    add('pad', d1, choir([57, 64, 69], 12.0, 0.6, 0.5))
    for d in (27, 147, 228):  # STRIKE. LAUNCH. POUNCE.
        add('fx', d1 + d, sub_boom(0.7))
        add('drums', d1 + d, taiko(0.9, 0.8))
        add('fx', d1 + d - 6, whoosh(0.2, 0.6))
    for d in (120, 210, 300, 600, 660):
        add('drums', d1 + d, crash(0.4), pan=-0.3)
    impact(M['boss1'], 1.0, braam_root=34, dark=True)
    # Bokator dashes at the Naga Raja: a whoosh on the beat, a skor roll, the lion lands
    add('fx', M['ndash'] - 4, whoosh(0.6, 0.9))
    for f in np.arange(M['ndash'], M['nhit'], 7.5):
        add('drums', (f2s(f),), skor(0.45, 1.15), pan=-0.2)
    impact(M['nhit'], 0.9, braam_root=36)
    add('music', M['nhit'], roneat(81, 0.6))
    add('fx', M['ncrush'], sub_boom(0.6))
    add('drums', M['ncrush'], taiko(0.9, 0.8))
    impact(M['kill1'], 1.0)
    # the breakdown on to the Bayon
    bd = M['breakdown']
    add('music', bd, gong(62, 0.9))
    add('pad', bd, drone(29, 3.0, 1.2, 420))
    add('music', bd + 6, sralai_phrase([(0, 0.5, 69), (0.5, 0.25, 72), (0.75, 0.75, 74), (1.5, 0.25, 76), (1.75, 0.25, 74),
                                     (2.0, 0.6, 72), (2.6, 0.5, 69)], 0.7))
    impact(M['finale'], 0.5, gong_=True)
    add('fx', M['finale'] + 15, riser(0.75, 0.9))
    # the second drop: Bokator, then the Angkor Warrior, at the Bayon
    d2 = M['drop2']
    impact(d2, 1.2, braam_root=33, gong_=True)
    groove(d2, M['aw_ult'], 1.1, hats16=True)
    riff(d2, M['aw_ult'], 0.85, 12)
    add('pad', d2, choir([57, 64, 69, 72], 5.2, 0.8, 0.4))
    for d in (26, 120, 142, 210, 221):
        add('fx', d2 + d, sub_boom(0.6))
        add('drums', d2 + d, crash(0.4))
    impact(M['aw'], 1.1, braam_root=36)
    add('fx', M['aw'] + 23, sub_boom(0.6))
    add('music', M['aw'] + 4, gong(73, 0.6))
    # the March of the Bayon: a hush for the cut-in, the army steps out, the ground splits
    u = M['aw_ult']
    add('music', u, gong(92, 0.8))
    add('pad', u, choir([57, 64, 69, 76], 4.5, 0.9, 0.3))
    impact(u + 36, 1.0, braam_root=33)
    groove(u + 60, u + 270, 1.0)
    for d in range(40, 150, 20):
        add('drums', u + d, taiko(0.6, 0.9 + 0.05 * ((d // 20) % 3)))
    add('fx', u + 160, riser(0.7, 1.0))
    impact(u + 202, 1.3, braam_root=33, gong_=True)
    impact(M['seven'], 1.0, braam_root=33)
    impact(M['seven'] + 22, 0.8, braam_root=36)
    add('fx', M['seven'] + 30, riser(0.45, 1.0))
    # five Shades, a hit every two beats
    mo = M['montage']
    for n in range(5):
        f = mo + n * 60
        add('drums', f, taiko(1.0, 0.85))
        add('fx', f, sub_boom(0.5))
        add('music', f, braam([33, 36, 31, 34, 29][n], 0.5))
        add('drums', f, crash(0.35), pan=(-1) ** n * 0.4)
        add('drums', f + 16, taiko(0.6, 1.1))
    for f in np.arange(mo, mo + 300, 7.5):
        add('drums', (f2s(f),), skor(0.35, 1.1), pan=-0.3)
        add('drums', (f2s(f),), hat(0.4), pan=0.3)
    for f in range(mo, mo + 300, 15):
        add('music', f, bass_note(33, 0.2, 0.7))
    riff(mo, mo + 300, 0.6, 12)
    # the final boss and the ultimate
    g = M['guardian']
    impact(g, 1.3, braam_root=33, dark=True, gong_=True)
    add('pad', g, drone(33, 3.6, 1.3, 300))
    add('pad', g + 10, choir([45, 46, 57], 1.6, 0.7, 0.6))
    add('fx', g + 8, heartbeat(0.8))
    add('fx', g + 22, riser(0.65, 0.9))
    gd = M['gdash']
    add('drums', gd, crash(0.5))
    add('drums', gd, taiko(1.0, 0.85))
    add('fx', gd - 4, whoosh(0.6, 1.0))
    for f in np.arange(gd, M['ghit'], 7.5):
        add('drums', (f2s(f),), skor(0.5, 1.15), pan=-0.2)
        add('drums', (f2s(f),), hat(0.5), pan=0.3)
    impact(M['ghit'], 1.1, braam_root=36, gong_=True)
    for i, m in enumerate([69, 76, 81]):
        add('music', M['ghit'] + i * 4, roneat(m, 0.6), pan=-0.3 + 0.3 * i)
    # the jab, cross and hook into the ultimate
    for n, f in enumerate((2625, 2638, 2653)):
        add('drums', f, taiko(0.6 + 0.15 * n, 1.05 - 0.08 * n))
        add('drums', f, skor(0.5, 1.2), pan=0.2)
    add('drums', 2653, crash(0.4))
    add('fx', M['ult'] - 20, reverse_crash(0.35, 0.6))
    ult = ult_cues()
    add('music', ult['start'] + 4, gong(98, 0.7))
    add('pad', ult['start'], choir([57, 64, 69], 3.0, 1.0, 0.3))
    impact(ult['slam'], 1.4, braam_root=33, gong_=True)
    for i, f in enumerate(ult['rise']):
        add('music', f, roneat([69, 72, 74, 76, 79, 81, 84, 86][i], 0.9), pan=(-1) ** i * 0.3)
        add('drums', f, skor(0.6, 1.2))
    for f in ult['hits']:
        add('drums', f, taiko(0.45, 1.3), pan=rng.uniform(-0.4, 0.4))
    a, b = ult['bound']
    for f in range(a, b, 15):
        add('drums', f, kick(0.7))
        add('drums', f + 7, hat(0.6), pan=0.3)
    add('pad', a, choir([57, 64, 69, 76], (b - a) / FPS + 1, 0.9, 0.6))
    add('fx', ult['leap'][0], riser((ult['leap'][1] - ult['leap'][0]) / FPS, 1.1))
    impact(ult['pounce'], 1.6, braam_root=33, gong_=True)
    add('pad', ult['pounce'], choir([57, 64, 69, 72, 76], 2.2, 1.0, 0.2))
    for i in range(14):
        m = [93, 88, 91, 86, 88, 84, 86, 81][i % 8]
        add('music', ult['pounce'] + 10 + i * 5, roneat(m, 0.32 * (1 - i / 16)), pan=(-1) ** i * 0.4)
    # the camera rushes to the counter: LEGENDARY
    cz = M['combo_zoom']
    add('fx', cz - 14, whoosh(0.28, 1.1))
    add('fx', (f2s(cz) - int(0.4 * SR),), reverse_crash(0.4, 0.7))
    impact(cz, 1.15, braam_root=33)
    for i, m in enumerate([81, 84, 88, 93]):
        add('music', cz + i * 3, roneat(m, 0.75), pan=-0.3 + 0.2 * i)
    add('drums', cz + 30, taiko(0.6, 1.0))
    # and back out: the Guardian gets up as the result card slides in
    add('fx', M['rise'] - 6, whoosh(0.3, 0.8, up=False))
    add('pad', M['rise'], drone(33, 2.5, 1.0, 260))
    add('pad', M['rise'] + 10, choir([45, 46, 52], 2.2, 0.6, 0.6))
    add('fx', M['rise'], heartbeat(1.0))
    add('music', M['card'], roneat(88, 0.35), pan=0.4)
    add('music', M['card'] + 4, roneat(93, 0.28), pan=0.5)
    # his fists rise and glow; the screen goes black on the blow
    w = M['windup']
    for f in (w, w + 28, w + 50, w + 66, w + 78):
        add('fx', f, heartbeat(1.05))
    add('fx', w + 6, riser((M['black'] - w - 6) / FPS, 1.2, 200, 7000))
    add('fx', M['black'] - 9, whoosh(0.15, 0.9))
    impact(M['black'], 1.7, braam_root=33, dark=True, gong_=True)
    # the end card
    e = M['endcard']
    impact(e + 6, 0.8, braam_root=33)
    add('pad', e + 6, drone(33, 5.2, 0.6, 450))
    add('pad', e + 6, choir([57, 64, 69], 5.0, 0.5, 1.0))
    add('music', e + 40, sralai_phrase([(0, 0.75, 69), (0.75, 0.25, 72), (1.0, 1.0, 74), (2.0, 0.5, 76), (2.5, 1.2, 79)], 0.5))
    for f in range(e + 30, e + 270, 60):
        add('drums', f, taiko(0.35, 0.9))
    add('music', e + 40, roneat(81, 0.5))
    impact(e + 100, 0.55)
    add('music', e + 150, roneat(81, 0.45))
    add('music', e + 210, gong(55, 0.8, 4.0))


def timeline_of(clip, src_frame):
    """first timeline frame at which a clip shows a source frame"""
    pos = float(clip['src'][1])
    speed = clip.get('speed', 1.0)
    for t in range(clip['dur']):
        if pos >= src_frame:
            return clip['at'] + t
        s = speed
        if isinstance(speed, list):
            for k, v in speed:
                if t >= k:
                    s = v
        pos += s
    return None


def ult_cues():
    clip = [c for c in EDL.CLIPS if c['src'][0] == 'finale' and c['src'][1] == EDL.FIN_ULT][0]
    u = EDL.FIN_ULT
    # the lions' hits as the take counted them: every rise of the combo while the pride bounds
    frames = json.load(open(os.path.join(HERE, 'out', 'finale', 'frames.json')))
    hits = [f['i'] for prev, f in zip(frames, frames[1:])
            if f['combo'] > prev['combo'] and u + 90 <= f['i'] < u + 150]
    rise = [u + 60 + i * 4 for i in range(8)]
    return {
        'start': clip['at'],
        'slam': clip['at'] + 57,
        'rise': [timeline_of(clip, s) for s in rise],
        'hits': [timeline_of(clip, s) for s in hits],
        'bound': (timeline_of(clip, u + 92), timeline_of(clip, u + 148)),
        'leap': (timeline_of(clip, u + 148), clip['at'] + 292),
        'pounce': clip['at'] + 292,
    }


def reverb(x, seconds=2.4, mix=0.25):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    ir_l = noise(n) * np.exp(-t / (seconds / 5))
    ir_r = noise(n) * np.exp(-t / (seconds / 5))
    ir_l = lp(ir_l, 6000)
    ir_r = lp(ir_r, 6000)
    ir_l[: int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    ir_r[: int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    norm = np.sqrt(np.sum(ir_l ** 2))
    wl = fftconvolve(x[:, 0], ir_l / norm)[: len(x)]
    wr = fftconvolve(x[:, 1], ir_r / norm)[: len(x)]
    return x + np.stack([wl, wr], 1) * mix


def write(path, data):
    d = np.clip(data, -1, 1)
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((d * 32767).astype(np.int16).tobytes())
    w.close()


if __name__ == '__main__':
    build()
    drums = reverb(BUS['drums'], 1.6, 0.18)
    music = reverb(BUS['music'], 2.8, 0.35)
    pad = reverb(BUS['pad'], 3.5, 0.45)
    fx = reverb(BUS['fx'], 2.0, 0.2)
    mix = drums * 0.9 + music * 1.05 + pad * 0.8 + fx * 0.8
    mix = np.stack([hp(mix[:, 0], 30), hp(mix[:, 1], 30)], 1)
    peak = np.max(np.abs(mix))
    mix = np.tanh(mix / peak * 1.25) / np.tanh(1.25) * 0.92
    write(os.path.join(HERE, 'out', 'music.wav'), mix.astype(np.float32))
    print('music written', LEN / SR, 's, raw peak', round(float(peak), 2))
