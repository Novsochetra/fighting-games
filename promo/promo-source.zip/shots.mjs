export const BASE_URL = process.env.PROMO_BASE || 'http://localhost:8766/';

const SIM = '/games/steel-and-dust/src/sim';

// page-side: start a mission straight away as a hero
async function startMission(api, missionIndex, hero) {
  await api.eval(
    async ({ SIM, missionIndex, hero }) => {
      const flow = await import(`${SIM}/stage/flow.js`);
      const { game } = window.__steelAndDust;
      game.settings.hero = hero;
      flow.selectMission(game, missionIndex);
      flow.startPlay(game);
      window.__flow = flow;
      window.__spawn = (await import(`${SIM}/stage/spawn-enemy.js`)).spawnEnemy;
    },
    { SIM, missionIndex, hero },
  );
  await api.settle(2500);
  // ticks only run once the road and the hero's strips are in
  await api.stepUntil(() => window.__steelAndDust.game.tickCount > 2, 600);
}

const BOKATOR_COMBOS = [
  'L 9 L 9 L 9 L',
  'K 16 L 6 L',
  'K 16 K 18 L 6 L 16 jump 8 L 8 L 8 L 10 K 14 L',
  'K 16 K 16 K 22 L 6 L',
  'dash 4 L',
  'L 9 L 9 L 9 L 4 K:70',
];

async function spawnCrowd(api, kinds) {
  await api.eval((kinds) => {
    kinds.forEach(([kind, side]) => window.__spawn(window.__steelAndDust.game, kind, side));
  }, kinds);
}

const TITLE_CSS = `
  body.promo-hide #m-title .logo { display: none; }
  body.promo-hide2 #m-title .mlist { display: none; }
  #m-title .mnote, #m-title .rotate { display: none !important; }
  #m-title .mlist { animation: menu-in 420ms var(--easing-out) both; }
  body.promo-fill .loader.complete .naga-gold { clip-path: inset(0 calc(100% - var(--reach)) 0 0) !important; }
  body.promo-fill .loader.complete .naga-gold .naga-head { filter: none !important; }
  body.promo-fill .naga-gold, body.promo-fill .loader-runner { transition: none !important; }
  body.promo-hold .loader.done { opacity: 1 !important; visibility: visible !important; transition: none !important; }
`;

// the loading bar run from empty to full: Bokator crosses the naga, the stone turns gold behind
// him, the heads light up, then the loader fades into the title
async function stageLoader(api) {
  await api.eval(() => {
    document.body.classList.add('promo-fill', 'promo-hold');
    const loader = document.getElementById('loader');
    const label = loader.querySelector('.loader-percent');
    let k = 0;
    loader.style.setProperty('--progress', '0');
    label.textContent = '0%';
    window.__dir.hooks.push(() => {
      k++;
      if (k <= 110) {
        const p = Math.min(1, Math.max(0, (k - 8) / 102));
        const e = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
        loader.style.setProperty('--progress', String(e));
        label.textContent = `${Math.min(99, Math.floor(e * 100))}%`;
      }
      if (k === 111) {
        label.textContent = '100%';
        document.body.classList.remove('promo-fill');
        loader.classList.add('complete');
      }
      if (k === 140) document.body.classList.remove('promo-hold');
    });
  });
}

const ALIVE = "game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko' && !f.entering).length";

async function pilot(api, programs, extra = {}) {
  await api.eval(([programs, extra]) => window.__dir.autopilot({ programs, idleWalk: 1, ...extra }), [
    programs,
    extra,
  ]);
}

// a hero's ultimate on a crowd that has just walked in
function ultShot(hero, mission, crowd) {
  return {
    audioSeconds: 20,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, hero);
      await api.eval(() => {
        window.__dir.autopilot({ programs: ['L'] }).hold = true;
      });
      await api.fast(140);
      await spawnCrowd(api, crowd);
      await api.fast(150);
      await api.eval(() => {
        window.__steelAndDust.game.ultMeter = 100;
        window.__dir.queue('ult', 1);
      });
      await api.rec(20, 'canvas');
      await api.rec(340, 'canvas');
    },
  };
}

const CROWD_BAYON = [
  ['ghoul', 1], ['sentry', 1], ['tombguard', 1], ['juggernaut', 1],
  ['assassin', -1], ['monk', -1], ['ghoul', -1],
];
const CROWD_ANGKOR = [
  ['monk', 1], ['tombguard', 1], ['juggernaut', 1], ['witch', 1],
  ['assassin', -1], ['sentry', -1], ['monk', -1],
];

const SHOWCASE = [
  'L 9 L 9 L 9 L',
  'K 16 K 18 L 6 L 18 jump 6 L 8 L 8 L 10 K 14 L',
  'K 16 L 6 L',
  'L 9 L 9 L 9 L 16 K 16 K 16 K 22 L 6 L',
  'dash 4 L',
  'K:70',
  'L 9 L 9 L 9 L 16 K 16 K 18 L 6 L 18 jump 6 L 8 L 8 L 10 K 14 L',
];

const ANGKOR_SHOWCASE = [
  'K:70',
  'L 9 L 9 L 9 L',
  'K 16 K 16 K 22 L 6 L',
  'K 16 L 6 L',
  'K 16 K 16 K',
  'jump 10 L 8 K 14 L',
];

function arenaShot(mission, kinds, hero = 'bokator', programs = SHOWCASE) {
  return {
    audioSeconds: 50,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, hero);
      await pilot(api, programs, { reach: 22, idleWalk: 0 });
      await api.eval(() => {
        const { game } = window.__steelAndDust;
        game.crates = [];
        window.__dir.hooks.push(() => {
          game.pickups = [];
        });
      });
      await api.eval((kinds) => window.__dir.crowd({ kinds, min: 4 }), kinds);
      await api.fast(200);
      await api.rec(2400, 'canvas');
    },
  };
}

// the boss walks in; Bokator stands a beat, dashes at it, and opens with the Dash Elbow (a lion)
// and the Naga Knee launcher into an air string, then fights on
function bossDashShot(mission, bossKind, wait) {
  return {
    audioSeconds: 30,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(90000, `game.boss && game.boss.kind === '${bossKind}'`);
      await api.eval((wait) => {
        const dir = window.__dir;
        const game = window.__steelAndDust.game;
        dir.pilot.hold = true;
        let k = 0;
        let phase = 'wait';
        let cooldown = 0;
        dir.hooks.push(() => {
          k++;
          const boss = game.boss;
          if (phase === 'done' || !boss) return;
          const dx = boss.x - game.player.x;
          const side = dx < 0 ? 'left' : 'right';
          if (phase === 'wait') {
            if (k >= wait) phase = 'dash';
            return;
          }
          if (cooldown > 0) {
            cooldown--;
            return;
          }
          if (dir.events.length) return;
          if (phase === 'dash') {
            if (Math.abs(dx) > 58) {
              // one dash every 15 ticks, an eighth note of the score
              dir.queue(`${side}:14 2 dash`, 0);
              cooldown = 14;
              return;
            }
            dir.queue(`${side}:12 2 dash 4 L`, 0);
            phase = 'combo';
            cooldown = 30;
            return;
          }
          dir.queue('K 16 K 18 L 6 L 18 jump 6 L 8 L 8 L 10 K 14 L', 0);
          phase = 'done';
          dir.pilot.hold = false;
        });
      }, wait);
      await api.rec(420, 'canvas');
    },
  };
}

// one take for the finale: the Guardian walks in as a crowd gathers, Bokator dashes at him on the
// beat, opens with the Dash Elbow's lion, answers his wind-up with Pounding the Lion, then stands as
// the Guardian gets up and raises his fists again
function finaleShot(crowd) {
  return {
    audioSeconds: 40,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(90000, "game.boss && game.boss.kind === 'guardian'");
      await api.eval((crowd) => {
        const dir = window.__dir;
        const game = window.__steelAndDust.game;
        dir.pilot.hold = true;
        const marks = (window.__finale = {});
        let k = 0;
        let phase = 'wait';
        let cooldown = 0;
        dir.hooks.push(() => {
          k++;
          const boss = game.boss;
          const player = game.player;
          if (k === 2) crowd.forEach(([kind, side]) => window.__spawn(game, kind, side));
          if (!boss) return;
          // the Guardian holds his blows until Bokator's ultimate has played
          if (phase !== 'after') boss.ai.cooldown = Math.max(boss.ai.cooldown, 20);
          const dx = boss.x - player.x;
          const side = dx < 0 ? 'left' : 'right';
          if (cooldown > 0) {
            cooldown--;
            return;
          }
          if (dir.events.length) return;
          if (phase === 'wait') {
            if (k >= 70) phase = 'dash';
          } else if (phase === 'dash') {
            if (Math.abs(dx) > 58) {
              dir.queue(`${side}:14 2 dash`, 0);
              cooldown = 14;
            } else {
              dir.queue(`${side}:12 2 dash 4 L`, 0);
              phase = 'elbow';
              cooldown = 18;
            }
          } else if (phase === 'elbow' && player.state === 'idle') {
            const near = game.fighters.filter(
              (f) => f.side === 'enemy' && f !== boss && f.state !== 'ko' && Math.abs(f.x - player.x) < 150,
            ).length;
            if (near >= 4 || k >= 186) {
              game.ultMeter = 100;
              dir.queue('ult', 0);
              marks.ultQueued = k;
              marks.near = near;
              phase = 'ult';
            } else {
              const combos = ['L 9 L 9 L 9 L', 'K 16 L 6 L', 'K 16 K 18 L 6 L'];
              dir.queue(combos[(marks.combos = (marks.combos ?? -1) + 1) % combos.length], 0);
              cooldown = 4;
            }
          } else if (phase === 'ult' && player.state === 'ult') {
            marks.ultStart = k;
            phase = 'after';
          }
        });
      }, crowd);
      await api.rec(900, 'canvas');
      api.info = await api.eval(() => window.__finale);
    },
  };
}

export const SHOTS = {
  finale: finaleShot([
    ['ghoul', 1], ['sentry', 1], ['juggernaut', 1], ['ghoul', 1], ['monk', -1], ['assassin', -1],
  ]),
  naga_dash: bossDashShot(10, 'naga', 30),
  guardian_dash: bossDashShot(11, 'guardian', 70),
  angkorB: arenaShot(10, ['monk', 'assassin', 'monk', 'witch', 'juggernaut', 'assassin', 'spitter']),
  bayonB: arenaShot(11, ['ghoul', 'assassin', 'monk', 'ghoul', 'juggernaut', 'witch', 'assassin']),
  aw_bayon: arenaShot(
    11,
    ['ghoul', 'assassin', 'monk', 'ghoul', 'juggernaut', 'witch', 'assassin'],
    'angkor',
    ANGKOR_SHOWCASE,
  ),
  ult_angkor_bayon: ultShot('angkor', 11, CROWD_BAYON),
  ult_moss: ultShot('moss', 11, CROWD_BAYON),
  ult_firefly: ultShot('firefly', 10, CROWD_ANGKOR),
  ult_antler: ultShot('antler', 11, CROWD_BAYON),
  ult_blue: ultShot('blue', 10, CROWD_ANGKOR),
  ult_ember: ultShot('ember', 11, CROWD_BAYON),
  ult_angkor: ultShot('angkor', 10, CROWD_ANGKOR),
  ult_bokator_angkor: ultShot('bokator', 10, CROWD_ANGKOR),

  angkorA: {
    audioSeconds: 70,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 10, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(2000, `${ALIVE} >= 2`);
      await spawnCrowd(api, [['monk', 1], ['tombguard', -1], ['assassin', 1]]);
      await api.rec(3000, 'canvas');
    },
  },

  naga: {
    audioSeconds: 60,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 10, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      const n = await api.fast(60000, "game.boss && game.boss.kind === 'naga'");
      api.log('reached naga after', n, await api.state());
      await api.rec(900, 'canvas');
      api.mark('skip');
      const m = await api.fast(60000, 'game.boss && game.boss.hp < game.boss.maxHp * 0.25');
      api.log('boss low after', m, await api.state());
      await api.rec(1500, 'canvas');
    },
  },

  bayonA: {
    audioSeconds: 70,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(2000, `${ALIVE} >= 2`);
      await spawnCrowd(api, [['ghoul', 1], ['juggernaut', -1], ['assassin', 1]]);
      await api.rec(3000, 'canvas');
    },
  },

  climax: {
    audioSeconds: 40,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(90000, "game.boss && game.boss.kind === 'guardian'");
      await api.eval(() => {
        window.__dir.pilot.hold = true;
      });
      await api.fast(120);
      await spawnCrowd(api, [
        ['ghoul', 1], ['sentry', 1], ['juggernaut', 1], ['assassin', -1], ['monk', -1], ['tombguard', -1],
      ]);
      await api.fast(600, 'Math.abs(game.boss.x - game.player.x) < 70');
      await api.fast(40);
      api.log(await api.state());
      await api.rec(90, 'canvas');
      api.mark('ult');
      await api.eval(() => {
        window.__steelAndDust.game.ultMeter = 100;
        window.__dir.queue('ult', 0);
      });
      await api.rec(420, 'canvas');
      await api.eval(() => {
        window.__dir.pilot.hold = false;
      });
      await api.rec(300, 'canvas');
    },
  },

  endcard: {
    audioSeconds: 20,
    dsf: 2,
    settings: { hero: 'bokator' },
    css: TITLE_CSS,
    async run(api) {
      await api.eval(() => document.body.classList.add('promo-hide', 'promo-hide2'));
      await api.settle(1500);
      await api.step(200);
      await api.rec(30, 'screen');
      api.mark('logo');
      await api.eval(() => document.body.classList.remove('promo-hide'));
      await api.rec(400, 'screen');
    },
  },

  stinger: {
    audioSeconds: 30,
    settings: { numbers: false },
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await api.fast(90000, "game.boss && game.boss.kind === 'guardian'");
      await api.eval(() => {
        const pilot = window.__dir.pilot;
        pilot.hold = true;
        pilot.peaceful = false;
        const game = window.__steelAndDust.game;
        for (const f of game.fighters) if (f.side === 'enemy' && f !== game.boss) f.removed = true;
        game.fighters = game.fighters.filter((f) => !f.removed);
      });
      await api.fast(60);
      await api.rec(420, 'canvas');
    },
  },

  guardian: {
    audioSeconds: 60,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      const n = await api.fast(90000, "game.boss && game.boss.kind === 'guardian'");
      api.log('reached guardian after', n, await api.state());
      await api.rec(1200, 'canvas');
    },
  },
  title: {
    audioSeconds: 30,
    dsf: 2,
    settings: { hero: 'angkor' },
    css: TITLE_CSS,
    async run(api) {
      await api.eval(() => document.body.classList.add('promo-hide', 'promo-hide2'));
      api.unlockAudio();
      await api.settle(1500);
      await stageLoader(api);
      await api.rec(240, 'screen');
      api.mark('logo');
      await api.eval(() => document.body.classList.remove('promo-hide'));
      await api.rec(60, 'screen');
      api.mark('menu');
      await api.eval(() => document.body.classList.remove('promo-hide2'));
      await api.rec(20, 'screen');
      const box = await api.page.locator('#m-title [data-act=play]').boundingBox();
      await api.page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 4 });
      api.mark('hover');
      await api.rec(25, 'screen');
      await api.page.mouse.down();
      await api.page.mouse.up();
      api.mark('click');
      await api.eval(async () => {
        const flow = await import('/games/steel-and-dust/src/sim/stage/flow.js');
        flow.selectMission(window.__steelAndDust.game, 10);
      });
      await api.rec(15, 'screen');
      api.mark('select');
      const steps = [12, 15, 15, 15, 23, 30];
      for (const wait of steps) {
        await api.rec(wait, 'screen');
        await api.page.keyboard.press('ArrowRight');
        api.mark(`step${Object.keys(api).length}`);
      }
      api.mark('landed');
      await api.rec(40, 'screen');
      await api.page.keyboard.press('Enter');
      api.mark('choose');
      await api.rec(30, 'screen');
      await api.rec(300, 'canvas');
    },
  },
  ultTest: {
    audioSeconds: 30,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 11, 'bokator');
      await api.eval(() => {
        const pilot = window.__dir.autopilot({ programs: ['L 9 L 9 L 9 L'] });
        pilot.hold = true;
      });
      await api.fast(140);
      await spawnCrowd(api, [
        ['ghoul', 1], ['sentry', 1], ['tombguard', 1], ['assassin', -1], ['monk', -1], ['ghoul', -1],
      ]);
      await api.fast(150);
      await api.eval(() => {
        window.__steelAndDust.game.ultMeter = 100;
        window.__dir.queue('ult', 1);
      });
      await api.rec(330, 'canvas');
    },
  },
  angkor1: {
    audioSeconds: 60,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, 10, 'bokator');
      await api.eval((programs) => window.__dir.autopilot({ programs, idleWalk: 1 }), BOKATOR_COMBOS);
      await api.rec(1500, 'canvas');
    },
  },
  test: {
    async run(api) {
      api.unlockAudio();
      await api.settle(1200);
      await api.step(10);
      await api.rec(60, 'screen');
      await startMission(api, 10, 'bokator');
      await api.eval(() =>
        window.__dir.autopilot({ programs: ['L 9 L 9 L 9 L', 'K 16 K 18 L 6 L', 'K 14 K 14 K'] }),
      );
      await api.rec(360, 'canvas');
    },
  },
};
