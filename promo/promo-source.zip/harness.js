// Page-side harness, injected before the game loads.
// Virtual time: rAF, performance.now, setTimeout and CSS animations advance only when __step runs,
// so every captured frame is exactly 1/60 s apart. Audio goes to an OfflineAudioContext whose
// currentTime is the virtual clock, rendered at the end of a shot.
(() => {
  const cfg = window.__promoConfig || {};
  const TICK = 1000 / 60;
  let vt = 0;
  window.__vt = () => vt;

  // seeded random: retakes are identical
  let seed = (cfg.seed ?? 1234) >>> 0;
  Math.random = () => {
    seed = (seed + 0x6d2b79f5) >>> 0;
    let t = seed;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  performance.now = () => vt;
  let rafQueue = [];
  let rafId = 1;
  window.requestAnimationFrame = (cb) => {
    rafQueue.push(cb);
    return rafId++;
  };
  window.cancelAnimationFrame = () => {};

  let timers = [];
  let timerId = 1;
  const realSetTimeout = window.setTimeout.bind(window);
  window.__realSetTimeout = realSetTimeout;
  window.setTimeout = (fn, ms = 0, ...args) => {
    const id = timerId++;
    timers.push({ id, due: vt + (Number(ms) || 0), fn, args });
    return id;
  };
  window.clearTimeout = (id) => {
    timers = timers.filter((t) => t.id !== id);
  };

  // ---- audio ----
  const SR = 48000;
  const RealOffline = window.OfflineAudioContext;
  const seconds = cfg.audioSeconds ?? 40;
  class VirtualAudioContext extends RealOffline {
    constructor() {
      super({ numberOfChannels: 2, length: Math.ceil(seconds * SR), sampleRate: SR });
      window.__audioCtx = this;
    }
    get currentTime() {
      return vt / 1000;
    }
    get state() {
      return 'running';
    }
    resume() {
      return Promise.resolve();
    }
    suspend() {
      return Promise.resolve();
    }
    close() {
      return Promise.resolve();
    }
    get baseLatency() {
      return 0;
    }
  }
  window.AudioContext = VirtualAudioContext;
  window.webkitAudioContext = VirtualAudioContext;
  window.__OfflineAudioContext = RealOffline;

  function wavBase64(buffer, fromSec, toSec) {
    const ch = [buffer.getChannelData(0), buffer.getChannelData(1)];
    const a = Math.max(0, Math.floor(fromSec * SR));
    const b = Math.min(buffer.length, Math.floor(toSec * SR));
    const n = Math.max(0, b - a);
    const out = new DataView(new ArrayBuffer(44 + n * 4));
    const w = (o, s) => [...s].forEach((c, i) => out.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF');
    out.setUint32(4, 36 + n * 4, true);
    w(8, 'WAVE');
    w(12, 'fmt ');
    out.setUint32(16, 16, true);
    out.setUint16(20, 1, true);
    out.setUint16(22, 2, true);
    out.setUint32(24, SR, true);
    out.setUint32(28, SR * 4, true);
    out.setUint16(32, 4, true);
    out.setUint16(34, 16, true);
    w(36, 'data');
    out.setUint32(40, n * 4, true);
    for (let i = 0; i < n; i++) {
      for (let c = 0; c < 2; c++) {
        const v = Math.max(-1, Math.min(1, ch[c][a + i]));
        out.setInt16(44 + i * 4 + c * 2, v < 0 ? v * 32768 : v * 32767, true);
      }
    }
    const bytes = new Uint8Array(out.buffer);
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(s);
  }

  window.__renderAudio = async (fromSec, toSec) => {
    const ctx = window.__audioCtx;
    if (!ctx) return null;
    const buffer = await ctx.startRendering();
    return wavBase64(buffer, fromSec, toSec);
  };

  // ---- CSS animations follow virtual time ----
  function advanceAnimations(dt) {
    for (const anim of document.getAnimations()) {
      if (!anim.__virtual) {
        anim.__virtual = true;
        anim.pause();
        anim.currentTime = 0;
        continue;
      }
      anim.currentTime = (anim.currentTime || 0) + dt;
    }
  }

  // ---- input director ----
  const ACTION = { L: 'light', K: 'heavy' };
  const dir = { events: [], held: new Set(), hooks: [] };
  window.__dir = dir;

  function input() {
    return window.__steelAndDust?.game?.input;
  }
  dir.press = (key) => {
    const name = ACTION[key] ?? key;
    const inp = input();
    inp.pressed[name] = true;
    inp.held[name] = true;
    dir.held.add(name);
  };
  dir.release = (key) => {
    const name = ACTION[key] ?? key;
    input().held[name] = false;
    dir.held.delete(name);
  };
  // 'L 9 L 9 K:40 up+K jump' — numbers wait ticks, key:n holds n ticks
  dir.program = (source, startTick) => {
    let tick = startTick;
    const events = [];
    for (const token of source.trim().split(/\s+/)) {
      if (/^\d+$/.test(token)) {
        tick += Number(token);
        continue;
      }
      const m = /^(?:(up|down|left|right)\+)?(\w+)(?::(\d+))?$/.exec(token);
      const [, mod, key, hold] = m;
      const len = hold ? Number(hold) : key === 'K' ? 2 : 1;
      for (const k of mod ? [mod, key] : [key]) {
        events.push({ tick, type: 'press', key: k });
        events.push({ tick: tick + len, type: 'release', key: k });
      }
    }
    return events;
  };
  dir.queue = (source, delay = 1) => {
    dir.events.push(...dir.program(source, dir.frame + delay));
  };
  dir.frame = 0;
  dir.busy = () => dir.events.length > 0;
  function runDirector() {
    const due = dir.events.filter((e) => e.tick <= dir.frame);
    dir.events = dir.events.filter((e) => e.tick > dir.frame);
    for (const e of due) (e.type === 'press' ? dir.press : dir.release)(e.key);
    for (const hook of dir.hooks) hook(dir.frame);
  }

  // fights like the test bot, but with a chosen list of showcase combos, and never dies
  dir.autopilot = (opts = {}) => {
    const state = { index: 0, walking: 0, on: true, ...opts };
    const programs = opts.programs || ['L 9 L 9 L 9 L'];
    const reach = opts.reach ?? 26;
    const walk = (d) => {
      if (state.walking === d) return;
      if (state.walking) dir.release(state.walking < 0 ? 'left' : 'right');
      if (d) {
        const name = d < 0 ? 'left' : 'right';
        input().held[name] = true;
        input().pressed[name] = true;
      }
      state.walking = d;
    };
    let lastX = 0;
    let stuck = 0;
    dir.hooks.push(() => {
      const game = window.__steelAndDust.game;
      const player = game.player;
      if (opts.immortal !== false) {
        player.hp = player.maxHp;
        player.hpLag = player.maxHp;
      }
      if (state.peaceful !== false) game.attackTokens = 0;
      if (!state.on || game.mode !== 'play') return;
      if (dir.events.length) return;
      if (state.hold) {
        walk(0);
        return;
      }
      if (state.walking && !player.airborne) {
        stuck = Math.abs(player.x - lastX) < 0.2 ? stuck + 1 : 0;
        if (stuck > 8) {
          dir.queue('jump', 0);
          stuck = 0;
        }
      }
      lastX = player.x;
      let best = null;
      for (const f of game.fighters) {
        if (f.side !== 'enemy' || f.state === 'ko' || f.entering) continue;
        if (!best || Math.abs(f.x - player.x) < Math.abs(best.x - player.x)) best = f;
      }
      if (!best) {
        walk(state.idleWalk ?? 0);
        return;
      }
      const dx = best.x - player.x;
      if (Math.abs(dx) > reach) {
        walk(Math.sign(dx));
        return;
      }
      walk(0);
      const program = programs[state.index % programs.length];
      state.index++;
      if (Math.sign(dx) !== player.facing && dx !== 0) {
        dir.queue(`${dx < 0 ? 'left' : 'right'} 2 ${program}`, 0);
      } else {
        dir.queue(program, 0);
      }
    });
    dir.pilot = state;
    return state;
  };

  // keeps a crowd on the field: when fewer than min raiders stand, the next kind walks in
  dir.crowd = ({ kinds, min = 3 }) => {
    let next = 0;
    let wait = 0;
    dir.hooks.push(() => {
      const game = window.__steelAndDust.game;
      if (game.mode !== 'play' || game.player.state === 'ult') return;
      const standing = game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko').length;
      if (wait > 0) {
        wait--;
        return;
      }
      if (standing < min) {
        const kind = kinds[next % kinds.length];
        window.__spawn(game, kind, next % 3 === 2 ? -1 : 1);
        next++;
        wait = 14;
      }
    });
  };

  window.__step = (count = 1) => {
    for (let k = 0; k < count; k++) {
      vt += TICK + 1e-7;
      dir.frame++;
      const due = timers.filter((t) => t.due <= vt);
      timers = timers.filter((t) => t.due > vt);
      for (const t of due) {
        try {
          t.fn(...t.args);
        } catch (error) {
          console.error(error);
        }
      }
      if (window.__steelAndDust) runDirector();
      const queue = rafQueue;
      rafQueue = [];
      for (const cb of queue) cb(vt);
      advanceAnimations(TICK);
    }
    return vt;
  };

  window.__frame = () => document.getElementById('game').toDataURL('image/png');

  // runs the simulation without drawing or sound, to reach a later moment quickly
  window.__fast = async (count, until) => {
    const { tick } = await import('/games/steel-and-dust/src/sim/tick.js');
    const game = window.__steelAndDust.game;
    const muted = game.muted;
    game.muted = true;
    let i = 0;
    for (; i < count; i++) {
      dir.frame++;
      runDirector();
      tick(game);
      if (until && until(game)) break;
    }
    game.muted = muted;
    return i;
  };

  window.__state = () => {
    const game = window.__steelAndDust.game;
    const p = game.player;
    const alive = game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko').length;
    return {
      t: game.tickCount,
      mode: game.mode,
      mission: game.missionIndex,
      zone: game.stage?.zoneIndex,
      wave: game.stage?.waveIndex,
      x: Math.round(p.x),
      cam: Math.round(game.camera.x),
      st: p.state,
      mv: p.move ? p.move.name || p.move.id || '?' : null,
      combo: game.combo?.count ?? 0,
      ult: game.ultMeter,
      enemies: alive,
      boss: game.boss ? `${game.boss.kind || game.boss.def?.name}:${Math.round(game.boss.hp)}` : null,
      banner: game.banner?.text ?? null,
      clear: game.clearTime,
      hx: +(p.x - game.camera.x).toFixed(1),
      hy: +p.y.toFixed(1),
      bx: game.boss ? +(game.boss.x - game.camera.x).toFixed(1) : null,
      bst: game.boss ? game.boss.state : null,
      ex: (() => {
        const xs = game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko').map((f) => f.x - game.camera.x);
        return xs.length ? +(xs.reduce((a, b) => a + b, 0) / xs.length).toFixed(1) : null;
      })(),
      zoom: game.camera.zoom?.time > 0 ? 1 : 0,
    };
  };
})();
