import { startMission, pilot, spawnCrowd, clearField, ALIVE, HUD_OFF, lineUp, quiet } from './lib.mjs';

export const BASE_URL = process.env.PROMO_BASE || 'http://localhost:8811/';

const BOKATOR_COMBOS = ['L 9 L 9 L 9 L', 'K 16 L 6 L', 'K 16 K 18 L 6 L', 'dash 4 L'];

// the arcade's home page: Morodok Angkor in the middle, the carousel slides to Steel & Dust, Play,
// and the card flies open over its painting (the game page itself is held back, so it never loads)
const homeShot = {
  page: true,
  path: '',
  dsf: 2,
  css: '.coffee-fab, .coffee-note, .consent, .consent-badge, .install, .privacy-choices, .support-callout { display: none !important; }',
  async run(api) {
    await api.page.route('**/games/steel-and-dust/**', () => {});
    await api.settle(2500);
    await api.step(30);
    api.mark('idle');
    await api.rec(50);
    await api.page.keyboard.press('ArrowRight');
    api.mark('slide');
    await api.rec(66);
    const box = await api.page.locator('#play-label').boundingBox();
    api.log('play box', box);
    await api.page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 3 });
    api.mark('hover');
    await api.rec(10);
    await api.page.mouse.down();
    api.mark('press');
    await api.rec(7);
    await api.page.mouse.up();
    api.mark('launch');
    await api.rec(80);
  },
};

const TITLE_CSS = `
  body.promo-hide #m-title .logo { display: none; }
  body.promo-hide2 #m-title .mlist { display: none; }
  #m-title .mnote, #m-title .rotate { display: none !important; }
  #m-title .mlist { animation: menu-in 420ms var(--easing-out) both; }
  .loader { display: none !important; }
`;

// the title as the game opens on it: the dusk alone, the logo, the menu, Play, and the hero select
// stepping from the Angkor Warrior round to Bokator
const titleShot = {
  audioSeconds: 30,
  dsf: 2,
  settings: { hero: 'angkor' },
  css: TITLE_CSS,
  async run(api) {
    await api.eval(() => document.body.classList.add('promo-hide', 'promo-hide2'));
    api.unlockAudio();
    await api.settle(2500);
    await api.step(160);
    api.mark('dusk');
    await api.rec(110, 'screen');
    api.mark('logo');
    await api.eval(() => document.body.classList.remove('promo-hide'));
    await api.rec(60, 'screen');
    api.mark('menu');
    await api.eval(() => document.body.classList.remove('promo-hide2'));
    await api.rec(20, 'screen');
    const box = await api.page.locator('#m-title [data-act=play]').boundingBox();
    await api.page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 4 });
    api.mark('hover');
    await api.rec(25, 'screen');
    await api.page.mouse.down();
    await api.page.mouse.up();
    api.mark('click');
    await api.eval(async () => {
      const flow = await import('/games/steel-and-dust/src/sim/stage/flow.js');
      flow.selectMission(window.__steelAndDust.game, 10);
    });
    await api.rec(15, 'screen');
    api.mark('select');
    for (const [n, wait] of [12, 15, 15, 15, 23, 30].entries()) {
      await api.rec(wait, 'screen');
      await api.page.keyboard.press('ArrowRight');
      api.mark(`step${n}`);
    }
    api.mark('landed');
    await api.rec(60, 'screen');
  },
};

// Bokator sprints right through one mission's road, a dash on every eighth note, the HUD and tips off
function roadShot(mission, frames = 170) {
  return {
    audioSeconds: 12,
    settings: { numbers: false },
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, 'bokator');
      await api.eval(() => {
        window.__hud = { drawPlayerPanel: false, drawClock: false, drawScore: false, drawPurse: false, drawCombo: false, drawBossBar: false, drawGoArrow: false, drawOffscreenArrows: false, drawBanner: false, drawMissionSummary: false };
        const { game } = window.__steelAndDust;
        const dir = window.__dir;
        let k = 0;
        dir.hooks.push(() => {
          game.hint = null;
          game.player.hp = game.player.maxHp;
          game.attackTokens = 0;
          k++;
          if (dir.events.length) return;
          const ahead = game.fighters.find((f) => f.side === 'enemy' && f.state !== 'ko' && f.x > game.player.x && f.x - game.player.x < 34);
          if (ahead && k % 30 === 0) {
            dir.queue('L 9 L 9 L 9 L', 0);
            return;
          }
          if (k % 15 === 0) dir.queue('right:13 1 dash', 0);
          else if (!dir.held.has('right')) { game.input.held.right = true; }
        });
      });
      await api.rec(frames, 'canvas');
    },
  };
}

const CROWD10 = [['monk', 12], ['assassin', 16], ['monk', 20], ['assassin', 25], ['sentry', 30], ['monk', 35], ['assassin', 40], ['monk', 46], ['assassin', 52], ['monk', 58]];
// the Angkor Warrior's: a string whose Spin Kick calls a carved soldier, the Churning of the Sea, the
// Meteor Fist's two soldiers, and a charged Tiger Rush that calls three
const CROWD_BAYON8 = [['ghoul', 12], ['assassin', 16], ['monk', 20], ['ghoul', 25], ['assassin', 30], ['monk', 35], ['ghoul', 40], ['assassin', 46]];
const AW_COMBO = ['L', 'L', 'L', 'L', 'K', 'K', 'L', 'K', 'K', 'K', 'L', 'K:70'];
const LOOP = ['L', 'L', 'L', 'K', 'jump', 'L', 'L', 'L', 'K', 'L', 'L', 'L', 'L'];
const SHOWCASE_COMBO = [...LOOP, 'L', 'L', 'L', 'L', 'L', 'K', 'K', 'K', 'L', 'K:70'];

// the showcase: ten raiders stand around Bokator, he launches, juggles, bounces off a Falling
// Elbow, launches again, and lets a charged Tiger Rush go for the knockouts
function comboShot(mission, crowd, steps, frames = 640, shift = 110, counter = true, hero = 'bokator') {
  return {
    audioSeconds: 25,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, hero);
      await api.eval(() => {
        window.__dir.autopilot({ programs: ['L'] }).hold = true;
      });
      await quiet(api, { ...HUD_OFF, drawCombo: counter });
      await api.fast(150);
      await api.eval((shift) => {
        const { game } = window.__steelAndDust;
        game.fighters = game.fighters.filter((f) => f.side !== 'enemy');
        game.player.x += shift;
      }, shift);
      await api.fast(90);
      await lineUp(api, crowd);
      await api.rec(36, 'canvas');
      api.mark('go');
      await api.eval((steps) => {
        const dir = window.__dir;
        const game = window.__steelAndDust.game;
        const driven = dir.driver(steps);
        let finished = false;
        dir.hooks.push(() => {
          if (!finished && !driven.steps.length && game.player.state === 'charge') {
            finished = true;
            for (const f of game.fighters) if (f.side === 'enemy' && f.state !== 'ko') f.hp = Math.min(f.hp, 8);
          }
        });
      }, steps);
      await api.rec(frames, 'canvas');
      api.info = await api.eval(() => window.__dir.driven.log);
    },
  };
}

// a few raiders of the mission's own kinds, so every one is drawn from its sheet
async function missionCrowd(api, count, spread = [14, 22, 30, 38, -16, -24]) {
  return api.eval(async ({ count, spread }) => {
    const { missionEnemyKinds } = await import('/games/steel-and-dust/src/data/missions/mission-enemies.js');
    const { ENEMY_TYPES } = await import('/games/steel-and-dust/src/data/enemies/enemy-types.js');
    const { game } = window.__steelAndDust;
    const kinds = [...missionEnemyKinds(game.missionIndex)].filter((k) => !ENEMY_TYPES[k].boss && !ENEMY_TYPES[k].ranged);
    return spread.slice(0, count).map((dx, i) => [kinds[i % kinds.length], dx]);
  }, { count, spread });
}

// a hero's ultimate on a crowd standing around them, in a mission that suits the hero
function ultShot(hero, mission, frames = 330) {
  return {
    audioSeconds: 16,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, hero);
      await api.eval(() => {
        window.__dir.autopilot({ programs: ['L'] }).hold = true;
      });
      await quiet(api, HUD_OFF);
      await api.fast(150);
      await api.eval(() => {
        const { game } = window.__steelAndDust;
        game.fighters = game.fighters.filter((f) => f.side !== 'enemy');
        game.player.x += 120;
      });
      await api.fast(90);
      const crowd = await missionCrowd(api, 6);
      api.log(hero, crowd);
      await lineUp(api, crowd, 60);
      await api.rec(24, 'canvas');
      api.mark('ult');
      await api.eval(() => {
        window.__steelAndDust.game.ultMeter = 100;
        window.__dir.queue('ult', 0);
      });
      await api.rec(frames, 'canvas');
    },
  };
}

// Bokator reaches Angkor Wat: the mission card comes up as he walks on
const arriveShot = {
  audioSeconds: 10,
  settings: { numbers: false },
  async run(api) {
    api.unlockAudio();
    await api.settle(800);
    await api.eval(async () => {
      const flow = await import('/games/steel-and-dust/src/sim/stage/flow.js');
      const { game } = window.__steelAndDust;
      game.settings.hero = 'bokator';
      flow.selectMission(game, 10);
      flow.startPlay(game);
      window.__spawn = (await import('/games/steel-and-dust/src/sim/stage/spawn-enemy.js')).spawnEnemy;
    });
    await api.settle(2500);
    await quiet(api, { ...HUD_OFF, drawBanner: true });
    await api.eval(() => {
      const { game } = window.__steelAndDust;
      window.__dir.hooks.push(() => {
        game.input.held.right = true;
        game.attackTokens = 0;
      });
    });
    await api.rec(260, 'canvas');
  },
};

// a mission boss walks on with its name card; Bokator runs at it and opens with the Dash Elbow's
// lion while the card is still up, then a string and the Meteor Fist
function bossShot(mission, kind, frames = 300) {
  return {
    audioSeconds: 16,
    async run(api) {
      api.unlockAudio();
      await api.settle(800);
      await startMission(api, mission, 'bokator');
      await pilot(api, BOKATOR_COMBOS);
      await quiet(api, { ...HUD_OFF, drawBanner: true, drawBossBar: true });
      await api.fast(90000, `game.boss && game.boss.kind === '${kind}'`);
      await api.eval(() => {
        const dir = window.__dir;
        const { game } = window.__steelAndDust;
        dir.pilot.hold = true;
        for (const f of game.fighters) if (f.side === 'enemy' && f !== game.boss) f.removed = true;
        game.fighters = game.fighters.filter((f) => !f.removed);
        let phase = 'approach';
        let k = 0;
        dir.hooks.push(() => {
          k++;
          const boss = game.boss;
          if (!boss) return;
          boss.ai.cooldown = Math.max(boss.ai.cooldown, 30);
          const p = game.player;
          const dx = boss.x - p.x;
          const side = dx < 0 ? 'left' : 'right';
          if (phase === 'approach') {
            game.input.held.left = side === 'left';
            game.input.held.right = side === 'right';
            if (Math.abs(dx) < 78 && k > 20) {
              game.input.held.left = false;
              game.input.held.right = false;
              p.facing = dx < 0 ? -1 : 1;
              dir.driver([`${side}+dash`, 'L', 'wait:4', 'L', 'L', 'L', 'L', 'wait:4', 'K', 'K', 'K', 'L']);
              phase = 'fight';
            }
          }
        });
      });
      await api.rec(frames, 'canvas');
    },
  };
}

// a quiet walk under the Bayon's faces at night, nobody about
const bayonWalk = {
  audioSeconds: 12,
  settings: { numbers: false },
  async run(api) {
    api.unlockAudio();
    await api.settle(800);
    await startMission(api, 11, 'bokator');
    await quiet(api, HUD_OFF);
    await api.eval(() => {
      const { game } = window.__steelAndDust;
      window.__dir.hooks.push(() => {
        game.fighters = game.fighters.filter((f) => f.side !== 'enemy');
        game.input.held.right = true;
      });
    });
    await api.rec(360, 'canvas');
  },
};

// the last fight: the Guardian of the Bayon walks on, Bokator opens up, then his ultimate brings
// the Guardian down
const finaleShot = {
  audioSeconds: 40,
  async run(api) {
    api.unlockAudio();
    await api.settle(800);
    await startMission(api, 11, 'bokator');
    await pilot(api, BOKATOR_COMBOS);
    await quiet(api, { ...HUD_OFF, drawBanner: true, drawBossBar: true, drawCombo: true });
    await api.fast(90000, "game.boss && game.boss.kind === 'guardian'");
    await api.eval(() => {
      const dir = window.__dir;
      const { game } = window.__steelAndDust;
      dir.pilot.hold = true;
      for (const f of game.fighters) if (f.side === 'enemy' && f !== game.boss) f.removed = true;
      game.fighters = game.fighters.filter((f) => !f.removed);
      const marks = (window.__finale = {});
      let k = 0;
      let phase = 'wait';
      dir.hooks.push(() => {
        k++;
        const boss = game.boss;
        if (!boss) return;
        if (phase !== 'after') boss.ai.cooldown = Math.max(boss.ai.cooldown, 30);
        if (phase === 'wait' && k >= 80) {
          dir.driver(['dash', 'L', 'wait:6', 'L', 'L', 'L', 'L', 'wait:4', 'K', 'K', 'K', 'L']);
          phase = 'combo';
        } else if (phase === 'combo' && !dir.driven.steps.length && game.player.state === 'idle' && !dir.events.length) {
          boss.hp = Math.min(boss.hp, Math.ceil(boss.maxHp * 0.06));
          game.ultMeter = 100;
          dir.driven.on = false;
          dir.queue('ult', 0);
          marks.ult = k;
          phase = 'after';
        }
      });
    });
    await api.rec(1000, 'canvas');
    api.info = await api.eval(() => window.__finale);
  },
};

// the title again for the end card: the logo over the dusk, no menu
const endcardShot = {
  audioSeconds: 20,
  dsf: 2,
  settings: { hero: 'bokator' },
  css: TITLE_CSS,
  async run(api) {
    await api.eval(() => document.body.classList.add('promo-hide', 'promo-hide2'));
    await api.settle(2500);
    await api.step(200);
    await api.rec(20, 'screen');
    api.mark('logo');
    await api.eval(() => document.body.classList.remove('promo-hide'));
    await api.rec(420, 'screen');
  },
};

export const SHOTS = {
  arrive: arriveShot,
  boss_naga: bossShot(10, 'naga'),
  boss_furnace: bossShot(7, 'furnace'),
  boss_pharaoh: bossShot(8, 'pharaoh'),
  boss_warden: bossShot(9, 'brute'),
  boss_djinn: bossShot(6, 'djinn'),
  bayon_walk: bayonWalk,
  finale: finaleShot,
  endcard: endcardShot,
  ult_moss: ultShot('moss', 1),
  ult_firefly: ultShot('firefly', 5),
  ult_antler: ultShot('antler', 6),
  ult_blue: ultShot('blue', 0),
  ult_ember: ultShot('ember', 4),
  ult_angkor: ultShot('angkor', 11),
  ult_bokator: ultShot('bokator', 8),
  combo: comboShot(10, CROWD10, SHOWCASE_COMBO),
  combo_clean: comboShot(10, CROWD10, SHOWCASE_COMBO, 640, 110, false),
  aw_combo: comboShot(11, CROWD_BAYON8, AW_COMBO, 440, 110, false, 'angkor'),
  title: titleShot,
  road_pine: roadShot(0),
  road_grove: roadShot(1),
  road_bamboo: roadShot(2),
  road_ember: roadShot(4),
  road_firefly: roadShot(5),
  road_sand: roadShot(6),
  road_iron: roadShot(7),
  road_mirage: roadShot(8),
  road_warden: roadShot(9),
  road_angkor: roadShot(10),
  home: homeShot,
  // one frame of each mission's road, a few seconds in, to choose the worlds
  probe: {
    audioSeconds: 5,
    async run(api) {
      for (const m of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) {
        await startMission(api, m, 'bokator');
        await api.eval(() => {
          window.__dir.hooks.length = 0;
        });
        await pilot(api, BOKATOR_COMBOS);
        await api.fast(240);
        await api.rec(1, 'canvas');
        await api.fast(600);
        await api.rec(1, 'canvas');
      }
    },
  },
};
