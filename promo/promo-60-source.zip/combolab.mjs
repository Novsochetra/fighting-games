import { startMission } from './lib.mjs';
export const BASE_URL = 'http://localhost:8811/';

// lines up a crowd around Bokator, plays one input program, and reports the combo it built
const CANDIDATES = JSON.parse(process.env.PROGRAMS);
const CROWD = JSON.parse(process.env.CROWD || '[["monk",30],["assassin",42],["monk",54],["assassin",22],["sentry",66],["monk",-26],["assassin",-38]]');
export const SHOTS = { lab: { audioSeconds: 5, async run(api) {
  await startMission(api, Number(process.env.MISSION || 10), process.env.HERO || 'bokator');
  await api.eval(() => {
    const dir = window.__dir;
    dir.autopilot({ programs: ['L'] }).hold = true;
  });
  await api.eval((v) => { window.__shift = v; }, Number(process.env.SHIFT || 0));
  await api.fast(120);
  for (const program of CANDIDATES) {
    const result = await api.eval(async ({ program, crowd }) => {
      const { groundAt } = await import('/games/steel-and-dust/src/sim/stage/terrain.js');
      const { game } = window.__steelAndDust;
      const dir = window.__dir;
      game.fighters = game.fighters.filter((f) => f.side !== 'enemy');
      game.boss = null;
      const p = game.player;
      p.facing = 1;
      if (!window.__shifted) { p.x += Number(window.__shift || 0); window.__shifted = true; }
      for (const [kind, dx] of crowd) {
        window.__spawn(game, kind, 1);
        const e = game.fighters[game.fighters.length - 1];
        e.x = p.x + dx; e.y = groundAt(game.terrain, e.x); e.entering = false; e.state = 'idle'; e.facing = dx > 0 ? -1 : 1;
        e.hp = e.maxHp = 400;
      }
      window.__holdEnemies = true;
      game.combo.count = 0; game.combo.timer = 0;
      await window.__fast(10);
      const info = { hero: [Math.round(p.x), Math.round(p.y), p.state, p.facing], foes: game.fighters.filter((f) => f.side === 'enemy').map((f) => [f.kind, Math.round(f.x), Math.round(f.y), f.state, f.entering, f.facing, f.invuln ?? f.invulnerable ?? null]) };
      console.log(JSON.stringify(info));
      const driven = dir.driver(program);
      const lab = { counts: [], max: 0, i: 0, lastHit: 0, moves: [], mv: null };
      let before = 0;
      const hook = () => {
        lab.i++;
        game.ultMeter = Math.max(game.ultMeter, 60);
        const mv = game.player.move ? (game.player.move.name || game.player.move.id) : game.player.state;
        if (mv !== lab.mv) { lab.moves.push(`${lab.i}:${mv}`); lab.mv = mv; }
        const c = game.combo.count;
        if (c > before) { lab.counts.push(`${lab.i}:${c}`); lab.lastHit = lab.i; }
        before = c;
        lab.max = Math.max(lab.max, c);
      };
      dir.hooks.push(hook);
      await window.__fast(1400, () => !driven.steps.length && !dir.events.length && lab.i - lab.lastHit > 120);
      driven.on = false;
      dir.hooks.splice(dir.hooks.indexOf(hook), 1);
      const max = lab.max;
      const counts = lab.counts;
      const alive = game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko').length;
      return { inputs: driven.log.join(' '), moves: lab.moves.join(' '), max, alive, counts: counts.join(' ') };
    }, { program, crowd: CROWD });
    api.log(JSON.stringify(program), '=>', result.max, 'hits; alive', result.alive, '\n   ', result.counts, '\n   ', result.moves, '\n   ', result.inputs);
  }
}}};
