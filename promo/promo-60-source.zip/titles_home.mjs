// Renders the end card's words in the arcade home page's own type, as transparent PNGs
import { chromium } from '/Users/sochetranov/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'titles');
const CARDS = [
  ['home_url', 'khmerarcade.games', 72, 700, '-0.02em', '#ffffff'],
  ['home_free', 'Free to play in your browser', 34, 500, '0em', 'rgba(255,255,255,0.86)'],
];
const browser = await chromium.launch({ headless: true });
const page = await (await browser.newContext({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 2 })).newPage();
await page.goto(process.env.PROMO_BASE || 'http://localhost:8811/', { waitUntil: 'networkidle' });
await page.evaluate(() => document.fonts.ready);
await page.addStyleTag({ content: `
  body > *:not(#card) { display: none !important; }
  html, body { background: transparent !important; }
  #card { position: fixed; left: 0; top: 0; padding: 20px 36px; white-space: nowrap; font-family: var(--font-system);
    text-shadow: 0 2px 18px rgba(0,0,0,0.55); }
` });
await page.evaluate(() => {
  const card = document.createElement('div');
  card.id = 'card';
  document.body.appendChild(card);
});
for (const [name, text, size, weight, spacing, color] of CARDS) {
  await page.evaluate(([text, size, weight, spacing, color]) => {
    const card = document.getElementById('card');
    Object.assign(card.style, { fontSize: `${size}px`, fontWeight: String(weight), letterSpacing: spacing, color });
    card.textContent = text;
  }, [text, size, weight, spacing, color]);
  const shot = await page.locator('#card').screenshot({ omitBackground: true });
  fs.writeFileSync(path.join(outDir, `${name}.png`), shot);
}
console.log('rendered', CARDS.length);
await browser.close();
