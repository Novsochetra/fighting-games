// Renders the combo counter's glyphs in the game's pixel font and HUD colors, as transparent PNGs
import { chromium } from '/Users/sochetranov/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'titles', 'counter');
fs.mkdirSync(outDir, { recursive: true });
const TIERS = { butter: '#ffe08a', amber: '#f2a33a', salmon: '#ff7a5a' };
const CARDS = [];
for (const [tier, color] of Object.entries(TIERS)) {
  for (let d = 0; d <= 9; d++) CARDS.push([`${tier}_${d}`, String(d), color, 168]);
}
CARDS.push(['hits', 'HITS', '#f1e7d6', 54]);
CARDS.push(['NICE', 'NICE', TIERS.butter, 66]);
CARDS.push(['GREAT', 'GREAT', TIERS.amber, 66]);
CARDS.push(['BRUTAL', 'BRUTAL', TIERS.salmon, 66]);
CARDS.push(['LEGENDARY', 'LEGENDARY', TIERS.salmon, 66]);
const browser = await chromium.launch({ headless: true });
const page = await (await browser.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
await page.goto(`${process.env.PROMO_BASE || 'http://localhost:8811/'}games/steel-and-dust/`, { waitUntil: 'load' });
await page.evaluate(() => document.fonts.ready);
await page.addStyleTag({ content: `
  #app, #loader { display: none !important; }
  html, body { background: transparent !important; }
  #card { position: fixed; left: 0; top: 0; padding: 10px 18px 18px 10px; white-space: nowrap; line-height: 1;
    font-family: var(--font-display); font-weight: 700; letter-spacing: 0.04em; }
` });
await page.evaluate(async () => {
  const card = document.createElement('div');
  card.id = 'card';
  document.body.appendChild(card);
  await document.fonts.load('700 40px Silkscreen');
});
for (const [name, text, color, size] of CARDS) {
  await page.evaluate(([text, color, size]) => {
    const card = document.getElementById('card');
    const step = Math.max(3, Math.round(size / 22));
    Object.assign(card.style, {
      fontSize: `${size}px`,
      color,
      textShadow: `${step}px ${step}px 0 #0c0910, ${-step}px ${step}px 0 #0c0910, ${step}px ${-step}px 0 #0c0910, ${-step}px ${-step}px 0 #0c0910, ${2 * step}px ${2 * step}px 0 #0c0910`,
    });
    card.textContent = text;
  }, [text, color, size]);
  const shot = await page.locator('#card').screenshot({ omitBackground: true });
  fs.writeFileSync(path.join(outDir, `${name}.png`), shot);
}
console.log('rendered', CARDS.length);
await browser.close();
