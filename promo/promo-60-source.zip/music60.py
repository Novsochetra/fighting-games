# The 60 s promo's score, with the first promo's instruments and themes: temple drone and gongs,
# roneat, sralai, skor and taiko, braams and risers. 120 BPM from the logo hit; cues follow edl60.py.
#   python3 music60.py  -> out/music60.wav
import os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import edl60 as EDL  # noqa: E402
from instr import (SR, braam, bass_note, choir, crash, drone, gong, hat, heartbeat, hp, kick, lp,  # noqa: E402
                   reverb, reverse_crash, riser, roneat, skor, snare, sralai_phrase, sub_boom, taiko,
                   whoosh, wind, write)

FPS = 60
LEN = int((EDL.TOTAL / FPS + 3) * SR)
BUS = {k: np.zeros((LEN, 2), np.float32) for k in ('drums', 'music', 'fx', 'pad')}
M = EDL.MARK
B = EDL.B


def f2s(frame):
    return int(frame / FPS * SR)


def add(bus, at_frame, sig, pan=0.0, gain=1.0):
    a = at_frame[0] if isinstance(at_frame, tuple) else f2s(at_frame)
    if sig.ndim == 1:
        sig = np.stack([sig * np.sqrt(0.5 * (1 - pan)), sig * np.sqrt(0.5 * (1 + pan))], 1)
    b = min(LEN, a + len(sig))
    if b > a:
        BUS[bus][a:b] += sig[: b - a] * gain


def add_sweep(bus, at_frame, sig, p0, p1, gain=1.0):
    """a mono sound that travels across the stereo field, as the camera or the hero moves"""
    pan = np.linspace(p0, p1, len(sig))
    st = np.stack([sig * np.sqrt(0.5 * (1 - pan)), sig * np.sqrt(0.5 * (1 + pan))], 1)
    add(bus, at_frame, st, gain=gain)


def at(frame):
    return (f2s(frame),)


def impact(frame, size=1.0, braam_root=None, dark=False, gong_=False):
    add('fx', frame, sub_boom(0.65 * size))
    add('drums', frame, taiko(1.0 * size, 0.9))
    add('drums', frame, crash(0.7 * size), pan=0.2)
    if braam_root is not None:
        add('music', frame, braam(braam_root, 0.8 * size, dark=dark))
    if gong_:
        add('music', frame, gong(73, 0.8 * size))


def groove(start, end, intensity=1.0, hats16=False, half=False):
    roots = [33, 33, 29, 31]
    for f in range(start, end, 15):
        pos = ((f - start) // 15) % 8
        bar = (f - start) // 120
        if half:
            if pos == 0:
                add('drums', f, kick(0.95 * intensity))
                add('drums', f, taiko(0.6 * intensity, 0.85))
            if pos == 4:
                add('drums', f, snare(0.9 * intensity), pan=0.05)
            if pos in (3, 7):
                add('drums', f, skor(0.45 * intensity, 1.05), pan=-0.3)
            add('drums', f, hat(0.6 * intensity, open_=(pos == 6)), pan=0.35)
            if pos in (0, 3, 6):
                add('music', f, bass_note(roots[bar % 4], 0.3, 0.75 * intensity))
            continue
        if pos in (0, 3, 5):
            add('drums', f, kick(0.9 * intensity))
        if pos in (2, 6):
            add('drums', f, snare(0.9 * intensity), pan=0.05)
        if pos in (0, 4):
            add('drums', f, taiko(0.55 * intensity, 1.0))
        if pos in (1, 3, 6, 7):
            add('drums', f, skor(0.5 * intensity, 1.0 + 0.15 * (pos % 2)), pan=-0.3)
        add('drums', f, hat(0.8 * intensity, open_=(pos % 2 == 1)), pan=0.35)
        if hats16:
            add('drums', at(f + 7.5), hat(0.5 * intensity), pan=0.4)
        root = roots[bar % 4]
        add('music', f, bass_note(root + (12 if pos in (3, 7) else 0), 0.24, 0.8 * intensity))


RIFF = [76, None, 69, 72, 74, None, 76, 79, 81, 79, 76, 74, 76, None, 72, 74]


def riff(start, end, amp=0.8, octave=0):
    for f in range(start, end, 15):
        m = RIFF[((f - start) // 15) % 16]
        if m is None:
            continue
        add('music', f, roneat(m + octave, amp), pan=-0.25)
        add('music', f, roneat(m + octave - 12, amp * 0.5), pan=0.25)


def tremolo(start, end, notes, amp=0.4):
    i = 0
    for f in np.arange(start, end, 3.75):
        m = notes[int((f - start) // 60) % len(notes)]
        add('music', at(f), roneat(m + (12 if i % 2 else 0), amp * (0.8 + 0.2 * (i % 2)), 0.4), pan=0.1 * (-1) ** i)
        i += 1


def roll(start, end, amp0=0.3, amp1=0.8):
    """a snare and taiko roll that tightens from quarters to sixteenths"""
    span = end - start
    f = float(start)
    while f < end:
        k = (f - start) / span
        add('drums', at(f), snare(amp0 + (amp1 - amp0) * k), pan=0.1)
        add('drums', at(f), taiko((amp0 + (amp1 - amp0) * k) * 0.8, 1.2))
        f += 30 if k < 0.4 else 15 if k < 0.75 else 7.5


# ---------------- A. the arcade ----------------
def arcade():
    add('pad', 0, drone(33, 8.0, 0.4, 360))
    add('fx', 0, wind(6.0, 0.45))
    add('music', 4, roneat(69, 0.3), pan=-0.2)
    add('music', 24, roneat(76, 0.42), pan=0.2)
    add('fx', 20, whoosh(0.3, 0.45))
    add('music', 100, roneat(81, 0.45), pan=0.1)
    add('music', 104, roneat(88, 0.25), pan=0.3)
    add_sweep('fx', 104, whoosh(0.5, 0.8), 0.3, -0.3)
    add('fx', 130, riser(1.15, 0.75, 400, 9000))
    add('fx', at(f2s(196) - int(0.9 * SR)), reverse_crash(0.9, 0.6))
    add('fx', 192, sub_boom(0.35, 2.0))


# ---------------- B. the title: the first promo's opening, as it was ----------------
def title():
    o = 216
    add('music', o + 1, gong(65, 0.5))
    for f, m in [(7, 74), (22, 72), (52, 69)]:
        add('music', o + f, roneat(m, 0.4), pan=-0.2)
    add('fx', o + 4, riser(1.3, 0.6))
    L = M['logo']
    impact(L, 1.1, braam_root=33, gong_=True)
    for d in (30, 60, 75, 90, 97, 105):
        add('drums', L + d, taiko(0.6 if d < 90 else 0.8, 1.1))
    add('fx', M['click'], whoosh(0.3, 0.8))
    add('drums', M['click'], crash(0.5))
    sel = M['select']
    for f in range(sel, sel + 120, 30):
        add('drums', f, kick(0.8))
        add('drums', f + 15, hat(0.7, True), pan=0.3)
    for f in range(sel, sel + 120, 15):
        add('drums', f + 7, hat(0.5), pan=-0.3)
        add('music', f, bass_note(33, 0.2, 0.6))
    tremolo(sel, sel + 120, [69, 72, 74, 76], 0.25)
    impact(M['choose'], 0.9, braam_root=33)
    add('music', M['choose'], choir([57, 64, 69], 2.0, 1.0, 0.1))
    add('fx', M['choose'] + 36, whoosh(0.25, 0.9))


# ---------------- C. one road ----------------
def road():
    r = M['road']
    impact(r, 0.9, braam_root=33)
    add('music', r, gong(82, 0.5))
    groove(r, M['arrive'], 0.8)
    add('pad', r, choir([57, 64, 69], 6.0, 0.55, 0.6))
    cuts = [r + 30 * i for i in range(5)] + [B(15), B(15.5)]
    notes = [69, 72, 74, 76, 79, 81, 84]
    for n, (f, m) in enumerate(zip(cuts, notes)):
        add('music', f, roneat(m, 0.62), pan=-0.3 + 0.1 * n)
        add('music', f, roneat(m + 12, 0.22), pan=0.3)
        add_sweep('fx', f - 4, whoosh(0.16 if n < 5 else 0.11, 0.6), -0.6, 0.6)
    add('drums', B(12), taiko(0.9, 0.85))
    add('fx', B(12), sub_boom(0.4))
    add('fx', B(14), riser(2.0, 0.9))
    roll(B(15), M['arrive'], 0.25, 0.7)
    # the mosaic: the beat stops, the mission card's letters land, a breath, then three hits
    a = M['arrive']
    impact(a, 0.8, braam_root=34, dark=True)
    add('pad', a, drone(33, 2.2, 0.8, 420))
    add('fx', at(f2s(M['drop1']) - int(0.95 * SR)), reverse_crash(0.95, 0.85))
    add('fx', M['combo'], heartbeat(0.7))
    for f, p in ((852, 1.0), (866, 1.08), (881, 1.16)):
        add('drums', f, taiko(0.55, p))
        add('drums', f, skor(0.4, 1.2), pan=-0.2)


# ---------------- D. the drop and the combo ----------------
def combo():
    d = M['drop1']
    impact(d, 1.3, braam_root=33, gong_=True)
    stop = B(31)
    groove(d, stop, 1.0)
    riff(d, stop, 0.8)
    add('pad', d, choir([57, 64, 69], 11.0, 0.6, 0.5))
    bounce = M['combo'] + 141
    add('fx', bounce, sub_boom(0.6))
    add('drums', bounce, crash(0.4), pan=-0.3)
    for f in (B(24), B(28)):
        add('drums', f, crash(0.35), pan=0.3)
    leg = M['legendary']
    impact(leg, 0.9, braam_root=36)
    for i, m in enumerate([81, 84, 88, 93]):
        add('music', leg + i * 3, roneat(m, 0.6), pan=-0.3 + 0.2 * i)
    # the charge: the band drops out, a heart and a riser climb to the release on the downbeat
    rel = B(34)
    add('pad', stop, drone(33, 2.0, 1.1, 300))
    add('pad', stop, choir([57, 64, 69, 76], 1.8, 0.8, 0.9))
    for f in (stop, stop + 30, stop + 52, stop + 68, stop + 79, stop + 85):
        add('fx', f, heartbeat(0.9))
    add('fx', stop + 4, riser((rel - stop - 4) / FPS, 1.2, 200, 8000))
    add('fx', at(f2s(rel) - int(0.5 * SR)), reverse_crash(0.5, 0.8))
    impact(rel, 1.6, braam_root=33, gong_=True)
    add('pad', rel, choir([57, 64, 69, 72, 76], 2.4, 1.0, 0.2))
    groove(rel, B(36), 1.05, hats16=True)
    riff(rel, B(36), 0.85, 12)
    # the camera runs to the counter: LEGENDARY
    cz = M['counter'] + 18
    add('fx', M['counter'] - 2, whoosh(0.3, 1.0))
    impact(cz, 1.0, braam_root=33)
    for i, m in enumerate([81, 84, 88, 93, 96]):
        add('music', cz + i * 3, roneat(m, 0.7 * (1 - i * 0.1)), pan=-0.3 + 0.15 * i)
    add('drums', B(36.5), taiko(0.6, 1.0))


# ---------------- E. the bosses ----------------
def bosses():
    e = M['bosses']
    end = M['breakdown']
    groove(e, end - 8, 0.95, half=True)
    for n, root in enumerate((34, 31, 29)):
        f = e + 60 * n
        impact(f, 0.95, braam_root=root, dark=True)
        add('drums', f + 30, taiko(0.95, 0.8))
        add('fx', f + 30, sub_boom(0.55))
        if n:
            add_sweep('fx', f - 9, whoosh(0.3, 0.85), -0.8, 0.8)
    add('drums', e + 194, taiko(0.8, 0.9))
    add('drums', e + 203, taiko(1.0, 0.75))
    add('fx', e + 203, sub_boom(0.8))
    add('drums', e + 203, crash(0.6))


# ---------------- F. the breakdown ----------------
def breakdown():
    f = M['breakdown']
    add('music', f, gong(62, 1.0, 6.0))
    add('fx', f, wind(4.2, 0.55))
    add('pad', f, drone(29, 4.4, 1.1, 420))
    add('pad', f + 20, choir([45, 52, 57, 64], 3.8, 0.7, 1.2))
    add('music', f + 30, sralai_phrase([(0, 0.75, 76), (0.75, 0.25, 74), (1.0, 0.75, 72), (1.75, 0.25, 74),
                                        (2.0, 1.0, 69), (3.0, 0.25, 72), (3.25, 0.25, 74)], 0.65))
    add('music', B(48), roneat(81, 0.4), pan=0.3)
    add('music', B(48) + 4, roneat(88, 0.25), pan=0.4)
    tremolo(B(50), M['heroes'], [69, 72, 74, 76], 0.24)
    add('fx', B(49), riser(1.5, 1.0))
    add('fx', at(f2s(M['heroes']) - int(0.6 * SR)), reverse_crash(0.6, 0.8))
    add('drums', B(51), taiko(0.6, 1.1))
    add('drums', B(51.5), taiko(0.7, 1.05))
    add('drums', B(51.75), taiko(0.8, 1.0))


# ---------------- G. the Shades, then the Angkor Warrior ----------------
def heroes():
    g = M['heroes']
    aw = M['aw']
    impact(g, 1.25, braam_root=33, gong_=True)
    groove(g, aw + 210, 1.1, hats16=True)
    riff(g, aw, 0.8, 12)
    add('pad', g, choir([57, 64, 69, 72], 5.2, 0.75, 0.4))
    for n, root in enumerate((33, 36, 31, 34, 29)):
        f = g + 60 * n
        if n:
            add('music', f, braam(root, 0.5))
            add('drums', f, taiko(0.9, 0.9))
            add('drums', f, crash(0.35), pan=(-1) ** n * 0.4)
        add('fx', f + 30, sub_boom(0.55))
        add('drums', f + 30, taiko(1.0, 0.8))


def angkor_warrior():
    aw = M['aw']
    # he steps out: a temple gong and the low brass under his name, the riff an octave down
    impact(aw, 1.2, braam_root=33, gong_=True)
    add('music', aw + 2, gong(65, 0.6))
    add('pad', aw, choir([45, 52, 57, 64], 3.6, 0.8, 0.3))
    riff(aw, aw + 210, 0.85, 0)
    for f in (aw + 13, aw + 28):
        add('drums', f, skor(0.45, 1.2), pan=-0.2)
    for f, size, root in ((aw + 60, 0.9, 36), (aw + 90, 0.75, None), (aw + 152, 0.9, 31), (aw + 187, 1.1, 33)):
        impact(f, size, braam_root=root)
    for f in (aw + 99, aw + 108, aw + 170):
        add('drums', f, taiko(0.6, 1.05))
    for f in (aw + 75, aw + 135, aw + 180):
        add_sweep('fx', f - 6, whoosh(0.18, 0.6), -0.5, 0.5)
    # Thousand Cuts: the band holds its breath for the cut-in, the slash lands on the beat
    add('music', aw + 210, gong(98, 0.7))
    add('fx', aw + 212, riser(0.25, 0.8, 800, 9000))
    impact(aw + 228, 1.3, braam_root=33, gong_=True)
    for i, m in enumerate([81, 84, 88]):
        add('music', aw + 228 + i * 3, roneat(m, 0.55), pan=-0.3 + 0.3 * i)


# ---------------- H. the final boss ----------------
def finale():
    h = M['finale']
    impact(h, 1.4, braam_root=33, dark=True, gong_=True)
    add('pad', h, drone(33, 3.4, 1.3, 280))
    add('pad', h + 10, choir([45, 46, 57], 2.4, 0.7, 0.6))
    fight = M['fight']
    for f in (h + 18, h + 46, h + 68, h + 82):
        add('fx', f, heartbeat(0.85))
    add('fx', h + 20, riser((fight - h - 20) / FPS, 0.9))
    impact(fight, 0.9, braam_root=36)
    groove(fight, M['ult'], 1.0)
    for f in (fight + 89, fight + 99, fight + 133):
        add('fx', f, sub_boom(0.45))
    # the ultimate: the cut-in hushes the band, the lions come in on a slam, the Guardian falls slowly
    u = M['ult']
    add('music', u + 2, gong(98, 0.8))
    add('pad', u, choir([57, 64, 69], 2.0, 1.0, 0.25))
    add('fx', at(f2s(u + 55) - int(0.45 * SR)), reverse_crash(0.45, 0.7))
    impact(u + 55, 1.3, braam_root=33, gong_=True)
    for i, f in enumerate(range(u + 55, M['ko'] - 20, 15)):
        add('drums', f, kick(0.75))
        add('drums', at(f + 7.5), hat(0.55), pan=0.3)
        if i % 2 == 0:
            add('drums', f, taiko(0.5, 1.0 + 0.04 * (i % 4)))
    add('pad', u + 60, choir([57, 64, 69, 76], (M['ko'] - u - 60) / FPS, 0.85, 0.8))
    add('fx', M['ko'] - 70, riser(70 / FPS, 1.2, 200, 8000))
    ko = M['ko']
    impact(ko, 1.8, braam_root=33, dark=True, gong_=True)
    add('fx', ko, sub_boom(0.9, 3.5))
    add('pad', ko + 20, drone(33, 3.0, 0.9, 300))
    add('pad', ko + 86, choir([57, 64, 69, 72, 76], 3.2, 1.0, 0.4))
    add('music', ko + 86, braam(33, 0.55))
    for i in range(14):
        m = [93, 88, 91, 86, 88, 84, 86, 81][i % 8]
        add('music', ko + 110 + i * 5, roneat(m, 0.3 * (1 - i / 16)), pan=(-1) ** i * 0.4)
    add('fx', M['endcard'] - 30, whoosh(0.5, 0.7))


# ---------------- I. the end card and the arcade ----------------
def endcard():
    e = M['endcard']
    impact(e, 0.95, braam_root=33, gong_=True)
    add('pad', e, drone(33, 9.0, 0.6, 450))
    add('pad', e, choir([57, 64, 69], 6.0, 0.5, 1.0))
    add('music', e + 30, sralai_phrase([(0, 0.75, 69), (0.75, 0.25, 72), (1.0, 1.0, 74), (2.0, 0.5, 76),
                                        (2.5, 1.5, 81)], 0.5))
    for f in range(e + 60, EDL.TOTAL - 60, 60):
        add('drums', f, taiko(0.32, 0.9))
    add('fx', e + 48, whoosh(0.3, 0.5))
    add('drums', e + 90, taiko(0.85, 0.85))
    add('fx', e + 90, sub_boom(0.45))
    h = M['home_end']
    add('fx', h - 10, whoosh(0.7, 0.6, up=False))
    add('music', h + 190, roneat(81, 0.5))
    add('music', h + 194, roneat(88, 0.3), pan=0.3)
    add('music', h + 206, roneat(76, 0.35), pan=-0.3)
    add('music', h + 190, gong(55, 0.8, 4.5))


def build():
    arcade()
    title()
    road()
    combo()
    bosses()
    breakdown()
    heroes()
    angkor_warrior()
    finale()
    endcard()


if __name__ == '__main__':
    build()
    drums = reverb(BUS['drums'], 1.6, 0.18)
    music = reverb(BUS['music'], 2.8, 0.35)
    pad = reverb(BUS['pad'], 3.5, 0.45)
    fx = reverb(BUS['fx'], 2.0, 0.2)
    mix = drums * 0.9 + music * 1.05 + pad * 0.8 + fx * 0.8
    mix = np.stack([hp(mix[:, 0], 30), hp(mix[:, 1], 30)], 1)
    peak = np.max(np.abs(mix))
    mix = np.tanh(mix / peak * 1.25) / np.tanh(1.25) * 0.92
    write(os.path.join(HERE, 'out', 'music60.wav'), mix.astype(np.float32))
    print('music written', LEN / SR, 's, raw peak', round(float(peak), 2))
