// node capture.mjs <shot> [--preview]
// Runs one shot from shots.mjs in headless Chromium with virtual time, writes
// out/<shot>/f_00000.(png|jpg), out/<shot>/audio.wav and out/<shot>/meta.json
import { chromium } from '/Users/sochetranov/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const shotName = process.argv[2];
const preview = process.argv.includes('--preview');
const { SHOTS, BASE_URL } = await import(process.env.SHOTS || './shots60.mjs');
const shot = SHOTS[shotName];
if (!shot) {
  console.error('no shot', shotName, Object.keys(SHOTS));
  process.exit(1);
}
const outDir = path.join(here, 'out', shotName);
fs.rmSync(outDir, { recursive: true, force: true });
fs.mkdirSync(outDir, { recursive: true });

const browser = await chromium.launch({
  headless: true,
  args: ['--autoplay-policy=no-user-gesture-required', '--disable-background-timer-throttling'],
});
const viewport = shot.viewport ?? { width: 1920, height: 1080 };
const context = await browser.newContext({ viewport, deviceScaleFactor: shot.dsf ?? 1, colorScheme: shot.colorScheme ?? 'dark' });
const settings = {
  music: 0,
  sfx: 80,
  shake: 2,
  numbers: true,
  flash: true,
  training: true,
  hero: 'bokator',
  difficulty: 1,
  ...(shot.settings || {}),
};
const hints = { move: 1, crate: 1, weapon: 1, ult: 1, launch: 1, dash: 1, shield: 1, sling: 1 };
const config = { seed: shot.seed ?? 7, audioSeconds: shot.audioSeconds ?? 40 };
await context.addInitScript(
  ({ settings, hints, config }) => {
    try {
      localStorage.setItem('sd_settings', JSON.stringify(settings));
      localStorage.setItem('sd_hints', JSON.stringify(hints));
      localStorage.setItem('sd_best', String(config.best ?? 0));
    } catch {}
    window.__promoConfig = config;
  },
  { settings, hints, config },
);
await context.addInitScript({ path: path.join(here, 'harness.js') });
if (shot.css) {
  await context.addInitScript((css) => {
    document.addEventListener('DOMContentLoaded', () => {
      const style = document.createElement('style');
      style.textContent = css;
      document.head.appendChild(style);
    });
  }, shot.css);
}
const page = await context.newPage();
page.on('console', (msg) => {
  if (msg.type() === 'error' || process.env.PAGELOG) console.log('[page]', msg.text());
});
page.on('pageerror', (err) => console.log('[pageerror]', err.message));
// the HUD's parts can be switched off one by one (window.__hud.drawScore = false), in the
// recording browser only: the request for draw-hud.js is answered with a gated copy
await page.route('**/render/hud/draw-hud.js*', async (route) => {
  const response = await route.fetch();
  const body = (await response.text()).replace(
    /^  (draw\w+)\(/gm,
    (whole, fn) => `  if ((window.__hud || {}).${fn} !== false) ${fn}(`,
  );
  await route.fulfill({ response, body });
});
// raiders can be told to hold their ground (window.__holdEnemies), facing the hero, so a crowd
// lined up for a combo stays where it was put; bosses still think for themselves
await page.route('**/brains/enemy/think-enemy.js*', async (route) => {
  const response = await route.fetch();
  const body = (await response.text()).replace(
    '  if (fighter.def.boss) {\n    thinkBoss',
    '  if (window.__holdEnemies && !fighter.def.boss) {\n    standStill(fighter);\n    return;\n  }\n  if (fighter.def.boss) {\n    thinkBoss',
  );
  if (!body.includes('__holdEnemies')) console.error('think-enemy patch did not apply');
  await route.fulfill({ response, body });
});
await page.goto(`${BASE_URL}${shot.path ?? 'games/steel-and-dust/'}`, { waitUntil: 'load' });
if (shot.page) {
  await page.evaluate(() => document.fonts.ready);
  const cdpPage = await context.newCDPSession(page);
  const pageFrames = [];
  let pageIndex = 0;
  let pageAudioStart = null;
  const pageApi = {
    page,
    eval: (fn, arg) => page.evaluate(fn, arg),
    settle: (ms = 1500) => new Promise((r) => setTimeout(r, ms)),
    step: (n = 1) => page.evaluate((n) => window.__step(n), n),
    marks: {},
    mark(name) {
      this.marks[name] = pageIndex;
    },
    log: (...args) => console.log(...args),
    async rec(n) {
      for (let i = 0; i < n; i++) {
        const vt = await page.evaluate(() => window.__step(1));
        if (pageAudioStart === null) pageAudioStart = vt / 1000;
        const data = await page.screenshot({ type: 'jpeg', quality: 95, scale: 'device' });
        fs.writeFileSync(path.join(outDir, `f_${String(pageIndex).padStart(5, '0')}.jpg`), data);
        pageFrames.push({ i: pageIndex, vt });
        pageIndex++;
      }
    },
  };
  await shot.run(pageApi);
  const endSec = pageFrames.length ? pageFrames[pageFrames.length - 1].vt / 1000 + 1 / 60 : 0;
  const wav = await page.evaluate(([a, b]) => window.__renderAudio(a, b), [pageAudioStart, endSec + 2]);
  if (wav) fs.writeFileSync(path.join(outDir, 'audio.wav'), Buffer.from(wav, 'base64'));
  fs.writeFileSync(path.join(outDir, 'meta.json'), JSON.stringify({ shot: shotName, frames: pageFrames.length, marks: pageApi.marks }, null, 2));
  fs.writeFileSync(path.join(outDir, 'frames.json'), JSON.stringify(pageFrames));
  console.log(`done ${shotName}: ${pageFrames.length} frames`);
  await cdpPage.detach();
  await browser.close();
  process.exit(0);
}
await page.waitForFunction(() => !!window.__steelAndDust);
await page.evaluate(() => document.fonts.ready);
// a recording without the pixel font is useless: stop if Silkscreen (the logo's bold) is not in
const fontOk = await page.evaluate(async () => {
  try {
    await document.fonts.load('700 16px Silkscreen');
  } catch {}
  return [...document.fonts].some(
    (f) => f.family.replace(/["']/g, '') === 'Silkscreen' && f.status === 'loaded' && String(f.weight) === '700',
  );
});
if (!fontOk) {
  console.error('pixel font did not load; check the network and record again');
  await browser.close();
  process.exit(2);
}
const cdp = await context.newCDPSession(page);

const frames = [];
let audioStart = null;
let index = 0;

async function grab(mode, stepped) {
  const { vt, s } = stepped;
  if (audioStart === null) audioStart = vt / 1000;
  const name = `f_${String(index).padStart(5, '0')}`;
  if (!preview) {
    if (mode === 'screen' && shot.dsf) {
      const data = await page.screenshot({ type: 'jpeg', quality: 94, scale: 'device' });
      fs.writeFileSync(path.join(outDir, `${name}.jpg`), data);
    } else if (mode === 'screen') {
      const shotData = await cdp.send('Page.captureScreenshot', {
        format: 'jpeg',
        quality: 95,
        optimizeForSpeed: true,
        ...(shot.dsf ? { clip: { x: 0, y: 0, width: viewport.width, height: viewport.height, scale: 1 } } : {}),
      });
      fs.writeFileSync(path.join(outDir, `${name}.jpg`), Buffer.from(shotData.data, 'base64'));
    } else {
      const url = await page.evaluate(() => window.__frame());
      fs.writeFileSync(path.join(outDir, `${name}.png`), Buffer.from(url.split(',')[1], 'base64'));
    }
  }
  frames.push({ i: index, vt, mode, ...s });
  index++;
}

const stepOne = () =>
  page.evaluate(() => {
    window.__step(1);
    return { vt: window.__vt(), s: window.__state() };
  });
const marks = {};
const api = {
  page,
  preview,
  eval: (fn, arg) => page.evaluate(fn, arg),
  wait: (ms) => new Promise((r) => setTimeout(r, ms)),
  step: (n = 1) => page.evaluate((n) => window.__step(n), n),
  mark: (name) => {
    marks[name] = index;
  },
  async rec(n, mode = 'canvas', each) {
    for (let i = 0; i < n; i++) {
      if (each) await each(i);
      await grab(mode, await stepOne());
    }
  },
  // record until cond (page fn) is true or max frames
  async recUntil(cond, max, mode = 'canvas') {
    for (let i = 0; i < max; i++) {
      await grab(mode, await stepOne());
      if (await page.evaluate(cond)) return i;
    }
    return max;
  },
  async stepUntil(cond, max) {
    for (let i = 0; i < max; i += 1) {
      await page.evaluate(() => window.__step(1));
      if (await page.evaluate(cond)) return i;
    }
    return max;
  },
  unlockAudio: () =>
    page.evaluate(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'F13' }))),
  // real wall-clock wait for images to load, stepping nothing
  async settle(ms = 1500) {
    await new Promise((r) => setTimeout(r, ms));
  },
  log: (...args) => console.log(...args),
  fast: (n, until) =>
    page.evaluate(
      ([n, until]) => window.__fast(n, until ? new Function('game', `return (${until})`) : null),
      [n, until],
    ),
  state: () => page.evaluate(() => window.__state()),
};

const started = Date.now();
await shot.run(api);
const meta = { shot: shotName, frames: frames.length, audioStart, marks, info: api.info ?? null };
if (!preview && audioStart !== null) {
  const endSec = frames.length ? frames[frames.length - 1].vt / 1000 + 1 / 60 : 0;
  const wav = await page.evaluate(([a, b]) => window.__renderAudio(a, b), [audioStart, endSec + 2]);
  if (wav) fs.writeFileSync(path.join(outDir, 'audio.wav'), Buffer.from(wav, 'base64'));
}
fs.writeFileSync(path.join(outDir, 'meta.json'), JSON.stringify(meta, null, 2));
fs.writeFileSync(path.join(outDir, 'frames.json'), JSON.stringify(frames));
fs.writeFileSync(
  path.join(outDir, 'log.txt'),
  frames
    .map((f) => `${f.i}\t${f.mode}\tt${f.t}\t${f.st}\t${f.mv}\tc${f.combo}\tu${f.ult}\te${f.enemies}\tx${f.x}\t${f.boss}\t${f.banner}\tz${f.zone}w${f.wave}\thx${f.hx}\thy${f.hy}\tex${f.ex}`)
    .join('\n'),
);
console.log(`done ${shotName}: ${frames.length} frames in ${((Date.now() - started) / 1000).toFixed(1)}s`);
await browser.close();
