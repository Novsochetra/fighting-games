# The promo score's instruments, synthesized: temple drone and gongs, roneat (Khmer xylophone),
# sralai (Khmer oboe), skor drums and taiko, braams, risers, whooshes
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
import wave

SR = 48000
rng = np.random.default_rng(11)


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def noise(n):
    return rng.standard_normal(n).astype(np.float32)


def bp(x, lo, hi, order=2):
    sos = butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return sosfilt(sos, x)


def lp(x, f, order=2):
    return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)


def hp(x, f, order=2):
    return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)


def sweep_filter(x, f0, f1, kind='band', width=1.0, block=512):
    """time-varying filter (exponential sweep), block by block"""
    out = np.zeros_like(x)
    n = len(x)
    zi = None
    for a in range(0, n, block):
        k = a / max(1, n - 1)
        f = f0 * (f1 / f0) ** k
        if kind == 'band':
            lo, hi = f / (1 + width), min(SR / 2 - 100, f * (1 + width))
            sos = butter(2, [lo, hi], btype='band', fs=SR, output='sos')
        else:
            sos = butter(2, min(f, SR / 2 - 100), btype='low', fs=SR, output='sos')
        if zi is None or zi.shape[0] != sos.shape[0]:
            zi = np.zeros((sos.shape[0], 2))
        out[a:a + block], zi = sosfilt(sos, x[a:a + block], zi=zi)
    return out


# ---------------- instruments ----------------
def kick(amp=1.0, low=1.0):
    t = tt(0.45)
    f = 46 * low + 140 * np.exp(-t / 0.025)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.22)
    click = hp(noise(len(t)), 2000) * np.exp(-t / 0.004) * 0.4
    return np.tanh(2.2 * (s + click)) * amp * 0.9


def taiko(amp=1.0, pitch=1.0, dur=1.1):
    t = tt(dur)
    f = 62 * pitch + 60 * pitch * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t / 0.32) + 0.3 * np.sin(2.3 * ph) * np.exp(-t / 0.12)
    skin = bp(noise(len(t)), 250, 1400) * np.exp(-t / 0.05) * 0.6
    return np.tanh(1.6 * (body + skin)) * amp * 0.8


def skor(amp=1.0, pitch=1.0):  # the higher, tighter barrel drum
    t = tt(0.35)
    f = 150 * pitch + 90 * np.exp(-t / 0.015)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.09)
    slap = bp(noise(len(t)), 900, 4000) * np.exp(-t / 0.012) * 0.5
    return (s + slap) * amp * 0.5


def snare(amp=1.0):
    t = tt(0.4)
    tone = np.sin(2 * np.pi * 185 * t) * np.exp(-t / 0.05)
    nz = bp(noise(len(t)), 1500, 7500) * np.exp(-t / 0.13)
    return np.tanh(1.4 * (0.5 * tone + nz)) * amp * 0.45


def hat(amp=1.0, open_=False):
    t = tt(0.3 if open_ else 0.06)
    s = hp(noise(len(t)), 7500) * np.exp(-t / (0.09 if open_ else 0.016))
    return s * amp * 0.16


def crash(amp=1.0, dur=2.6):
    t = tt(dur)
    s = hp(noise(len(t)), 3500) * np.exp(-t / 0.9)
    metal = sum(np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) for f in (3120, 4470, 5530, 6890)) * 0.05
    return (s + metal * np.exp(-t / 0.7)) * amp * 0.3


def sub_boom(amp=1.0, dur=2.4):
    t = tt(dur)
    f = 30 + 85 * np.exp(-t / 0.12)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.9)
    s = np.tanh(2.5 * s) * 0.8
    rumble = lp(noise(len(t)), 180) * np.exp(-t / 0.5) * 1.5
    return (s + rumble) * amp


def additive(freq_curve, dur, harmonics, amp_fn, env):
    """freq_curve: array of f0 per sample; amp_fn(k, f0, t) -> amplitude per sample"""
    t = tt(dur)
    ph = 2 * np.pi * np.cumsum(freq_curve) / SR
    out = np.zeros(len(t))
    for k in range(1, harmonics + 1):
        a = amp_fn(k, freq_curve, t)
        if np.max(np.abs(a)) < 1e-4:
            continue
        out += a * np.sin(k * ph)
    return out * env


def braam(root=33, amp=1.0, dur=2.2, dark=False):
    """the big low brass: detuned saws whose brightness swells and dies"""
    t = tt(dur)
    notes = [root, root + 7, root + 12] if not dark else [root, root + 1, root + 12]
    out = np.zeros(len(t))
    cutoff = 180 + 2600 * np.exp(-t / 0.35) * (1 - np.exp(-t / 0.02)) + 300 * np.exp(-t / 1.5)
    for m in notes:
        for det in (-0.004, 0.0, 0.005):
            f0 = mtof(m) * (1 + det) * np.ones(len(t))
            def amp_fn(k, f, tt_, c=cutoff):
                return (1 / k) / (1 + np.exp((k * f - c) / 120))
            out += additive(f0, dur, 40, amp_fn, 1)
    env = (1 - np.exp(-t / 0.015)) * np.exp(-t / 0.9)
    s = np.tanh(out * env * 0.35)
    return s * amp


def roneat(m, amp=1.0, dur=0.9):
    """a struck bar: the bar's own inharmonic partials, quick decay, mallet click"""
    t = tt(dur)
    f = mtof(m)
    s = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.42)
         + 0.32 * np.sin(2 * np.pi * f * 3.93 * t) * np.exp(-t / 0.09)
         + 0.1 * np.sin(2 * np.pi * f * 9.2 * t) * np.exp(-t / 0.03)
         + 0.25 * np.sin(2 * np.pi * f * 2 * t) * np.exp(-t / 0.2))
    click = bp(noise(len(t)), 2000, 8000) * np.exp(-t / 0.003) * 0.3
    return (s + click) * amp * 0.28


def gong(f0=82, amp=1.0, dur=6.0):
    t = tt(dur)
    ratios = [1, 1.47, 2.09, 2.56, 3.18, 4.21, 5.3]
    out = np.zeros(len(t))
    for i, r in enumerate(ratios):
        f = f0 * r * (1 + 0.012 * np.exp(-t / 0.3))
        ph = 2 * np.pi * np.cumsum(f) / SR
        decay = 3.6 / (1 + i * 0.5)
        beat_ = 1 + 0.15 * np.sin(2 * np.pi * (0.7 + i * 0.4) * t)
        out += np.sin(ph) * np.exp(-t / decay) * beat_ / (1 + i * 0.6)
    strike = lp(noise(len(t)), 1200) * np.exp(-t / 0.03) * 0.6
    swell = 1 - 0.5 * np.exp(-t / 0.08)
    return (out * swell + strike) * amp * 0.35


def sralai_phrase(notes, amp=1.0, glide=0.07):
    """notes: [(start_sec, dur_sec, midi)]; one breathing line with glides and vibrato"""
    total = max(s + d for s, d, _ in notes) + 0.3
    n = int(total * SR)
    t = np.arange(n) / SR
    f = np.zeros(n)
    gate = np.zeros(n)
    prev = None
    for s, d, m in notes:
        a, b = int(s * SR), int((s + d) * SR)
        target = mtof(m)
        if prev is None:
            f[a:b] = target
        else:
            g = min(int(glide * SR), b - a)
            f[a:a + g] = np.linspace(prev, target, g)
            f[a + g:b] = target
        gate[a:b] = 1
        prev = target
    # fill gaps with the last pitch so the phase runs on
    last = f[0] or mtof(notes[0][2])
    for i in range(n):
        if f[i] == 0:
            f[i] = last
        last = f[i]
    vib = 1 + 0.007 * np.sin(2 * np.pi * 5.6 * t) * np.clip((t % 10) * 3, 0, 1)
    f = f * vib
    env = lp(gate, 18)
    formants = [(720, 1.0, 180), (1250, 0.7, 220), (2650, 0.35, 300)]

    def amp_fn(k, f0, tt_):
        hf = k * f0
        g = sum(w * np.exp(-((hf - c) / bw) ** 2) for c, w, bw in formants) + 0.08 / k
        return g * (hf < 9000)
    s = additive(f, total, 28, amp_fn, env)
    s = np.tanh(s * 1.8) * 0.5
    return s * amp


def choir(midis, dur, amp=1.0, attack=0.8):
    t = tt(dur)
    out = np.zeros(len(t))
    formants = [(760, 1.0, 320), (1150, 0.5, 340), (2800, 0.12, 520)]
    morph = 1 + 0.09 * np.sin(2 * np.pi * 0.21 * t)
    for m in midis:
        for det in (-0.006, 0.0, 0.007):
            f0 = mtof(m) * (1 + det) * (1 + 0.004 * np.sin(2 * np.pi * 4.8 * t + det * 900))

            def amp_fn(k, f, tt_):
                hf = k * f
                return sum(w * np.exp(-((hf - c * morph) / bw) ** 2) for c, w, bw in formants) + 0.05 / k
            out += additive(f0, dur, 20, amp_fn, 1)
    env = (1 - np.exp(-t / attack)) * np.clip((dur - t) / 0.8, 0, 1)
    return lp(out, 3500) * env * amp * 0.05


def drone(root, dur, amp=1.0, bright=500):
    t = tt(dur)
    out = np.zeros(len(t))
    lfo = 1 + 0.4 * np.sin(2 * np.pi * 0.12 * t)
    for m in (root, root + 7, root + 12):
        for det in (-0.003, 0.004):
            f0 = mtof(m) * (1 + det) * np.ones(len(t))

            def amp_fn(k, f, tt_):
                return (1 / k) / (1 + np.exp((k * f - bright * lfo) / 90))
            out += additive(f0, dur, 24, amp_fn, 1)
    env = np.clip(t / 2.0, 0, 1) * np.clip((dur - t) / 1.5, 0, 1)
    return out * env * amp * 0.12


def bass_note(m, dur, amp=1.0):
    t = tt(dur)
    f0 = mtof(m) * np.ones(len(t))
    cutoff = 250 + 900 * np.exp(-t / 0.06)

    def amp_fn(k, f, tt_):
        return (1 / k) / (1 + np.exp((k * f - cutoff) / 60))
    s = additive(f0, dur, 18, amp_fn, 1)
    env = (1 - np.exp(-t / 0.004)) * np.exp(-t / 0.35) * np.clip((dur - t) / 0.01, 0, 1)
    return np.tanh(s * env * 1.5) * amp * 0.5


def riser(dur, amp=1.0, f0=300, f1=9000):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = sweep_filter(noise(n), f0, f1, 'band', 0.6)
    tone_f = 180 * (6 ** (t / dur))
    tone = np.sin(2 * np.pi * np.cumsum(tone_f) / SR) * 0.25
    env = (t / dur) ** 2.2
    return (s * 0.9 + tone) * env * amp * 0.5


def whoosh(dur=0.45, amp=1.0, up=True):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = sweep_filter(noise(n), 400 if up else 5000, 5000 if up else 400, 'band', 0.8)
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return s * env * amp * 0.6


def reverse_crash(dur=1.2, amp=1.0):
    return crash(amp, dur)[::-1].copy()


def heartbeat(amp=1.0):
    k1 = kick(amp, low=0.8)
    k2 = kick(amp * 0.7, low=0.8)
    out = np.zeros(int(0.7 * SR))
    out[: len(k1)] += k1[: len(out)]
    o = int(0.22 * SR)
    out[o:o + len(k2)] += k2[: len(out) - o]
    return lp(out, 220)


def wind(dur, amp=1.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = lp(noise(n), 700)
    mod = 0.6 + 0.4 * np.sin(2 * np.pi * 0.17 * t) * np.sin(2 * np.pi * 0.05 * t + 1)
    return s * mod * np.clip(t / 2, 0, 1) * np.clip((dur - t) / 1.5, 0, 1) * amp * 0.35


def reverb(x, seconds=2.4, mix=0.25):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    ir_l = noise(n) * np.exp(-t / (seconds / 5))
    ir_r = noise(n) * np.exp(-t / (seconds / 5))
    ir_l = lp(ir_l, 6000)
    ir_r = lp(ir_r, 6000)
    ir_l[: int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    ir_r[: int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    norm = np.sqrt(np.sum(ir_l ** 2))
    wl = fftconvolve(x[:, 0], ir_l / norm)[: len(x)]
    wr = fftconvolve(x[:, 1], ir_r / norm)[: len(x)]
    return x + np.stack([wl, wr], 1) * mix


def write(path, data):
    d = np.clip(data, -1, 1)
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((d * 32767).astype(np.int16).tobytes())
    w.close()


