# python3 sheet.py shot first last step cols out.png [crop x,y,w,h]
import sys, os
from PIL import Image, ImageDraw
shot, a, b, step, cols, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
crop = tuple(int(v) for v in sys.argv[7].split(',')) if len(sys.argv) > 7 else None
frames = []
for i in range(a, b + 1, step):
    for ext in ('png', 'jpg'):
        p = f'out/{shot}/f_{i:05d}.{ext}'
        if os.path.exists(p):
            im = Image.open(p).convert('RGB')
            if crop: im = im.crop((crop[0], crop[1], crop[0] + crop[2], crop[1] + crop[3]))
            im = im.resize((384, int(384 * im.height / im.width)))
            ImageDraw.Draw(im).text((4, 4), str(i), fill=(255, 255, 0))
            frames.append(im)
            break
rows = (len(frames) + cols - 1) // cols
w, h = frames[0].size
sheet = Image.new('RGB', (w * cols, h * rows))
for n, im in enumerate(frames):
    sheet.paste(im, ((n % cols) * w, (n // cols) * h))
sheet.save(out)
