// Renders the promo's text cards as transparent PNGs, set in the game's own font and colors
import { chromium } from '/Users/sochetranov/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'titles');
fs.mkdirSync(outDir, { recursive: true });

// name, text (| = line break), style, px size, letter spacing (em)
const CARDS = [
  ['ends_angkor', 'IT ENDS AT ANGKOR.', 'gold', 64, 0.14],
  ['bokator', 'BOKATOR', 'carved', 120, 0.08],
  ['bokator_sub', 'POUNDS THE LION, AS ANGKOR TAUGHT', 'white', 34, 0.16],
  ['one_road', 'ONE ROAD.', 'gold', 120, 0.06],
  ['twelve', 'TWELVE MISSIONS.', 'white', 84, 0.06],
  ['moss', 'MOSS SHADE', 'carved', 84, 0.08],
  ['moss_sub', 'PATIENT BLADE OF THE OLD GROVE', 'white', 30, 0.16],
  ['firefly', 'FIREFLY SHADE', 'carved', 84, 0.08],
  ['firefly_sub', 'FIGHTS IN A SWARM OF SPARKS', 'white', 30, 0.16],
  ['antler', 'ANTLER SPIRIT SHADE', 'carved', 84, 0.08],
  ['antler_sub', 'HORNED GHOST OF THE DUNES', 'white', 30, 0.16],
  ['blue', 'BLUE SHADE', 'carved', 84, 0.08],
  ['blue_sub', 'COLD STEEL, NO SHADOW', 'white', 30, 0.16],
  ['ember', 'EMBER SHADE', 'carved', 84, 0.08],
  ['ember_sub', 'WALKED OUT OF THE BURNING WOODS', 'white', 30, 0.16],
  ['angkor', 'ANGKOR WARRIOR', 'carved', 84, 0.08],
  ['angkor_sub', 'STEPS OUT OF THE BAYON WALLS', 'white', 30, 0.16],
  ['choose', 'CHOOSE YOUR HERO.', 'gold', 96, 0.06],
  ['tags', '7 HEROES  ·  12 MISSIONS  ·  12 BOSSES', 'white', 34, 0.12],
  ['free', 'FREE TO PLAY IN YOUR BROWSER', 'gold', 52, 0.1],
  ['url', 'KHMERARCADE.GAMES', 'white', 46, 0.12],
  ['controls', 'KEYBOARD  ·  GAMEPAD  ·  TOUCH', 'white', 26, 0.2],
];

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1920, height: 1080 },
  deviceScaleFactor: 1,
});
const page = await context.newPage();
await page.goto(`${process.env.PROMO_BASE || 'http://localhost:8811/'}games/steel-and-dust/`, { waitUntil: 'load' });
await page.evaluate(() => document.fonts.ready);
await page.addStyleTag({
  content: `
  #app, #loader { display: none !important; }
  html, body { background: transparent !important; }
  #card { position: fixed; left: 0; top: 0; padding: 24px 40px; white-space: nowrap;
    font-family: var(--font-display); font-weight: 700; line-height: 1.1; text-align: center; }
  #card.gold { color: var(--color-gold); text-shadow: var(--text-shadow-logo); }
  #card.carved { margin: 0; color: var(--color-gold); text-shadow: var(--text-shadow-logo); --stone: 3; }
  #card.white { color: var(--color-text); text-shadow: 3px 3px 0 var(--color-shadow); }
`,
});
await page.evaluate(async () => {
  const card = document.createElement('div');
  card.id = 'card';
  document.body.appendChild(card);
  await document.fonts.load('700 40px Silkscreen');
});

for (const [name, text, style, size, spacing] of CARDS) {
  await page.evaluate(
    ([text, style, size, spacing]) => {
      const card = document.getElementById('card');
      card.className = style === 'carved' ? 'mtitle good carved' : style;
      card.style.fontSize = `${size}px`;
      card.style.letterSpacing = `${spacing}em`;
      card.innerHTML = text.split('|').join('<br>');
    },
    [text, style, size, spacing],
  );
  const shot = await page.locator('#card').screenshot({ omitBackground: true });
  fs.writeFileSync(path.join(outDir, `${name}.png`), shot);
}
console.log('rendered', CARDS.length, 'cards');
await browser.close();
