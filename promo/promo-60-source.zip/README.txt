Steel & Dust 60 s promo: how it is made (re-render after the game or the arcade changes)

Needs: the dev server (PROMO_BASE=http://localhost:PORT/ picks it; default 8811), Node 22,
Playwright (from the npx cache path in capture.mjs), Python 3 with numpy, scipy and Pillow, ffmpeg.

1. Record the shots (frames + the page's own sound) into out/<shot>/:
     node capture.mjs <shot>
   shots: home title road_pine road_grove road_bamboo road_ember road_firefly road_sand road_warden
          arrive combo_clean boss_naga boss_furnace boss_warden bayon_walk
          ult_moss ult_firefly ult_antler ult_blue ult_ember ult_angkor finale endcard
   (combolab.mjs tries combos without recording: PROGRAMS='[["L","L","K"]]' SHOTS=./combolab.mjs node capture.mjs lab --preview)
2. Render the words:   node titles60.mjs && node titles_home.mjs && node counter_glyphs.mjs
3. Edit the cut in edl60.py, then:
     python3 compose60.py stills 900,1200 --half   (check frames)
     python3 music60.py                            (the score -> out/music60.wav)
     python3 compose60.py audio                    (the game's sound, remapped -> out/sfx60.wav)
     python3 compose60.py parallel --jobs 9        (picture -> out/promo60_video.mp4)
     python3 master60.py                           (mix, -14 LUFS, mux -> out/steel-and-dust-promo-60.mp4)

The recording browser alone gets two patched game files (capture.mjs): the HUD's parts can be
switched off one by one, and raiders can be told to hold their ground. Nothing in the repo changes.
