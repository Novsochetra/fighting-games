# prints the frames where the combo count rises (hits), and state changes, for a shot
import json, sys
shot = sys.argv[1]
fr = json.load(open(f'out/{shot}/frames.json'))
prev = None
hits = []
states = []
for f in fr:
    c = f.get('combo', 0)
    if prev is not None and c > prev:
        hits.append(f"{f['i']}:{c}")
    prev = c
    key = (f.get('st'), f.get('mv'))
    if not states or states[-1][1] != key:
        states.append((f['i'], key))
print('hits', ' '.join(hits))
print('moves', ' '.join(f"{i}:{k[1] or k[0]}" for i, k in states))
