# Renders the 60 s promo from edl60.py.
#   python3 compose60.py video [--half] [--from F] [--to F] [--name N]   -> out/<name>.mp4 (no audio)
#   python3 compose60.py parallel [--half] [--jobs 8]                   -> out/promo60_video.mp4
#   python3 compose60.py stills F1,F2,... [--half]                     -> out/stills/t_F.png
#   python3 compose60.py audio                                         -> out/sfx60.wav (game sound, remapped)
import json, math, os, subprocess, sys, wave
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
FPS = 60
SR = 48000
sys.path.insert(0, HERE)
import edl60 as EDL  # noqa: E402

ARGS = sys.argv[1:]
HALF = '--half' in ARGS
OW, OH = (960, 540) if HALF else (1920, 1080)
SS = 2


def arg(name, default=None):
    if name in ARGS:
        return ARGS[ARGS.index(name) + 1]
    return default


# ---------------- sources ----------------
@lru_cache(maxsize=16)
def frames_meta(shot):
    p = os.path.join(OUT, shot, 'frames.json')
    return json.load(open(p)) if os.path.exists(p) else None


@lru_cache(maxsize=40)
def load_frame(shot, i):
    for ext in ('png', 'jpg'):
        p = os.path.join(OUT, shot, f'f_{i:05d}.{ext}')
        if os.path.exists(p):
            return Image.open(p).convert('RGB')
    meta = frames_meta(shot)
    if meta and i >= len(meta):
        return load_frame(shot, len(meta) - 1)
    raise FileNotFoundError(f'{shot} {i}')


@lru_cache(maxsize=64)
def load_title(name):
    return Image.open(os.path.join(HERE, 'titles', f'{name}.png')).convert('RGBA')


def ease_out(x):
    x = min(max(x, 0.0), 1.0)
    return 1 - (1 - x) ** 3


def ease_in(x):
    x = min(max(x, 0.0), 1.0)
    return x ** 3


def ease_in_out(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


def interp_keys(keys, t, ease=ease_in_out):
    if not isinstance(keys, list):
        return keys
    if t <= keys[0][0]:
        return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            k = ease((t - t0) / max(1e-9, t1 - t0))
            if isinstance(v0, (list, tuple)):
                return tuple(a + (b - a) * k for a, b in zip(v0, v1))
            return v0 + (v1 - v0) * k
    return keys[-1][1]


def step_value(keys, t):
    v = keys[0][1]
    for k, val in keys:
        if t >= k:
            v = val
    return v


def source_positions(clip):
    dur = clip['dur']
    speed = clip.get('speed', 1.0)
    pos = float(clip['src'][1])
    out = []
    for t in range(dur):
        out.append(pos)
        pos += speed if not isinstance(speed, list) else step_value(speed, t)
    return out


# ---------------- camera ----------------
def hero_track(shot, smooth=0.1):
    meta = frames_meta(shot)
    if not meta or 'hx' not in meta[0]:
        return None
    xs, ys = [], []
    sx = sy = None
    for f in meta:
        hx, hy = f.get('hx'), f.get('hy')
        if hx is None:
            hx, hy = 192, 184
        tx, ty = hx * 2, hy * 2
        if sx is None:
            sx, sy = tx, ty
        sx += (tx - sx) * smooth
        sy += (ty - sy) * smooth * 0.5
        xs.append(sx)
        ys.append(sy)
    return xs, ys


def shake_offset(t, amp, seed, unit):
    if amp <= 0:
        return 0.0, 0.0
    rng = np.random.default_rng(t * 7919 + seed)
    return rng.uniform(-1, 1) * amp * unit, rng.uniform(-1, 1) * amp * unit


def view(img, zoom, cx, cy, smooth=False):
    """the OW x OH view of a source at a zoom around (cx, cy) in source pixels"""
    sw, sh = img.size
    zoom = max(zoom, 1.0)
    hw, hh = sw / (2 * zoom), sh / (2 * zoom)
    cx = min(max(cx, hw), sw - hw)
    cy = min(max(cy, hh), sh - hh)
    box = (cx - hw, cy - hh, cx + hw, cy + hh)
    if smooth:
        return img.resize((OW, OH), Image.LANCZOS, box=box)
    return img.resize((OW * SS, OH * SS), Image.NEAREST, box=box).reduce(SS)


def fx_sum(clip, kind, t, shape=lambda k: (1 - k)):
    total = 0.0
    for fx in clip.get('fx', []):
        if fx[0] == kind:
            t0, d, amt = fx[1], fx[2], fx[3]
            if t0 <= t < t0 + d:
                total = max(total, amt * shape((t - t0) / d))
    return total


def render_source(clip, t, srcpos, track):
    shot = clip['src'][0]
    i = int(math.floor(srcpos + 1e-6))
    img = load_frame(shot, i)
    sw, sh = img.size
    zoom = interp_keys(clip.get('zoom', 1.0), t)
    zoom *= 1 + fx_sum(clip, 'punch', t, lambda k: (1 - k) ** 2)
    zoom *= 1 + fx_sum(clip, 'pushin', t, lambda k: ease_in(k))
    center = clip.get('center', 'hero')
    if center == 'hero' and track:
        k = min(i, len(track[0]) - 1)
        off = interp_keys(clip.get('offset', (0, 0)), t)
        cx, cy = track[0][k] + off[0], track[1][k] + off[1]
    elif center == 'hero':
        cx, cy = sw / 2, sh / 2
    else:
        c = interp_keys(center, t)
        cx, cy = c[0] * sw, c[1] * sh
    for fx in clip.get('fx', []):
        if fx[0] == 'whipout':
            # the camera rushes off by (dx, dy) view sizes, faster and faster
            _, t0, d, dx, dy = fx
            if t >= t0:
                k = ease_in(min(1.0, (t - t0) / d))
                cx += dx * sw / zoom * k
                cy += dy * sh / zoom * k
        elif fx[0] == 'whipin':
            # the camera arrives from (dx, dy) view sizes away and settles
            _, t0, d, dx, dy = fx
            if t < t0 + d:
                k = 1 - ease_out(max(0.0, (t - t0) / d))
                cx += dx * sw / zoom * k
                cy += dy * sh / zoom * k
        elif fx[0] == 'rush':
            # the camera flies to a point and grows: (t0, d, (x, y), zoom)
            _, t0, d, (tx, ty), z1 = fx
            if t >= t0:
                k = ease_in_out(min(1.0, (t - t0) / d))
                cx += (tx * sw - cx) * k
                cy += (ty * sh - cy) * k
                zoom *= (z1 / zoom) ** k
    amp = fx_sum(clip, 'shake', t)
    unit = sw / 768
    sx, sy = shake_offset(t + clip['at'], amp, 13, unit)
    return view(img, zoom, cx + sx, cy + sy, smooth=clip.get('smooth', False))


# ---------------- effects ----------------
VIGNETTE = None


def vignette():
    global VIGNETTE
    if VIGNETTE is None:
        y, x = np.mgrid[0:OH, 0:OW]
        d = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        VIGNETTE = (1 - 0.3 * np.clip((d - 0.55) / 0.85, 0, 1) ** 1.6)[..., None].astype(np.float32)
    return VIGNETTE


def motion_blur(arr, px, vertical=False):
    n = max(2, min(14, int(abs(px) / 6) + 2))
    acc = np.zeros_like(arr)
    for j in range(n):
        s = int(round(px * (j / (n - 1) - 0.5)))
        acc += np.roll(arr, s, axis=0 if vertical else 1)
    return acc / n


def zoom_blur(arr, amount):
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    acc = arr.copy()
    n = 6
    for j in range(1, n):
        s = 1 + amount * j / n
        w, h = int(OW * s), int(OH * s)
        big = img.resize((w, h), Image.BILINEAR).crop(((w - OW) // 2, (h - OH) // 2, (w - OW) // 2 + OW, (h - OH) // 2 + OH))
        acc += np.asarray(big).astype(np.float32)
    return acc / n


def bloom(arr, amount):
    small = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).resize((OW // 8, OH // 8), Image.BILINEAR)
    s = np.asarray(small).astype(np.float32)
    s = np.clip(s - 150, 0, 255) * 1.6
    b = Image.fromarray(np.clip(s, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(4))
    b = np.asarray(b.resize((OW, OH), Image.BILINEAR)).astype(np.float32)
    return 255 - (255 - arr) * (255 - b * amount) / 255


def gaussian(arr, radius):
    if radius < 0.3:
        return arr
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    return np.asarray(img.filter(ImageFilter.GaussianBlur(radius * OW / 1920))).astype(np.float32)


def apply_frame_fx(arr, clip, t):
    for fx in clip.get('fx', []):
        kind = fx[0]
        if kind == 'flash':
            _, t0, d, strength = fx[:4]
            color = np.array(fx[4] if len(fx) > 4 else (255, 250, 235), np.float32)
            if t0 <= t < t0 + d:
                a = strength * (1 - (t - t0) / d) ** 1.5
                arr = arr * (1 - a) + color * a
        elif kind == 'fadein':
            _, t0, d = fx[:3]
            if t < t0 + d:
                arr = arr * ease_in_out((t - t0) / d)
        elif kind == 'fadeout':
            _, t0, d = fx[:3]
            if t >= t0:
                arr = arr * (1 - ease_in_out((t - t0) / d))
        elif kind == 'shadeleft':
            _, t0, d = fx
            if t0 <= t < t0 + d:
                k = ease_out((t - t0) / 10)
                ramp = np.clip(np.linspace(0, 1, OW) / 0.6, 0, 1).astype(np.float32)
                arr = arr * (1 - 0.62 * k * (1 - ramp) ** 1.3)[None, :, None]
        elif kind == 'dim':
            _, t0, d, amount = fx
            if t0 <= t < t0 + d:
                arr = arr * (1 - amount)
        elif kind == 'chroma':
            _, t0, d, px = fx
            if t0 <= t < t0 + d:
                s = int(round(px * (1 - (t - t0) / d) * OW / 1920))
                if s:
                    arr[..., 0] = np.roll(arr[..., 0], s, axis=1)
                    arr[..., 2] = np.roll(arr[..., 2], -s, axis=1)
        elif kind == 'bloom':
            _, t0, d, amt = fx
            if t0 <= t < t0 + d:
                arr = bloom(arr, amt)
        elif kind == 'mblur':
            # horizontal motion blur, px at 1920 wide, keyed: ('mblur', [(t, px), ...])
            px = interp_keys(fx[1], t) * OW / 1920
            if abs(px) >= 2:
                arr = motion_blur(arr, px, vertical=len(fx) > 2 and fx[2] == 'v')
        elif kind == 'zblur':
            amt = interp_keys(fx[1], t)
            if amt > 0.004:
                arr = zoom_blur(arr, amt)
        elif kind == 'blur':
            arr = gaussian(arr, interp_keys(fx[1], t))
        elif kind == 'tint':
            # ('tint', [(t, amount)], (r, g, b)): a wash of one color, keyed, e.g. a white-out
            amount = interp_keys(fx[1], t)
            if amount > 0:
                arr = arr * (1 - amount) + np.array(fx[2], np.float32) * amount
        elif kind == 'darken':
            amount = interp_keys(fx[1], t)
            if amount > 0:
                arr = arr * (1 - amount)
        elif kind == 'bottomdim':
            # a dark band rises under the bottom of the frame, for words to sit on
            _, t0, d, amount = fx
            if t >= t0:
                k = ease_in_out((t - t0) / d) * amount
                ramp = np.clip((np.linspace(0, 1, OH) - 0.735) / 0.1, 0, 1).astype(np.float32) ** 1.2
                arr = arr * (1 - k * ramp)[:, None, None]
        elif kind == 'grade':
            # ('grade', sat, contrast, (r, g, b) multipliers)
            _, sat, contrast = fx[:3]
            g = arr.mean(axis=2, keepdims=True)
            arr = g + (arr - g) * sat
            arr = (arr - 128) * contrast + 128
            if len(fx) > 3:
                arr = arr * np.array(fx[3], np.float32)
    return arr


def letterbox(arr, h):
    if h <= 0:
        return arr
    px = int(round(h * OH / 1080))
    arr[:px] = 0
    arr[OH - px:] = 0
    return arr


# ---------------- text ----------------
def place_text(base, spec, t):
    _, name, t0, d, pos = spec[:5]
    anim = spec[5] if len(spec) > 5 else 'fade'
    scale = spec[6] if len(spec) > 6 else 1.0
    if not (t0 <= t < t0 + d):
        return base
    k = t - t0
    img = load_title(name)
    alpha = 1.0
    s = scale
    dx = dy = 0
    if anim == 'slam':
        a = ease_out(k / 7)
        s = scale * (1.9 - 0.9 * a)
        alpha = min(1, k / 3)
    elif anim == 'fade':
        alpha = min(1, k / 14)
        dy = (1 - ease_out(k / 30)) * 18
    elif anim == 'rise':
        alpha = min(1, k / 10)
        dy = (1 - ease_out(k / 18)) * 40
    elif anim == 'drift':
        alpha = min(1, k / 18)
        s = scale * (1 + 0.04 * k / d)
    elif anim == 'slide':
        alpha = min(1, k / 6)
        dx = (1 - ease_out(k / 14)) * -160
    out_len = spec[7] if len(spec) > 7 else 10
    if k > d - out_len:
        alpha *= max(0, (d - k) / out_len)
    if alpha <= 0:
        return base
    f = OW / 1920 * s
    w, h = max(1, int(img.width * f)), max(1, int(img.height * f))
    im = img.resize((w, h), Image.NEAREST if s >= 1 else Image.BILINEAR)
    if anim == 'wipe':
        reveal = ease_out(k / 22)
        cut = int(w * reveal)
        mask = np.zeros((h, w), np.float32)
        mask[:, :cut] = 1
        a = np.asarray(im.split()[3]).astype(np.float32) * mask
        im.putalpha(Image.fromarray(a.astype(np.uint8)))
    if alpha < 1:
        a = np.asarray(im.split()[3]).astype(np.float32) * alpha
        im.putalpha(Image.fromarray(a.astype(np.uint8)))
    x = int(pos[0] * OW - w / 2 + dx * OW / 1920)
    y = int(pos[1] * OH - h / 2 + dy * OH / 1080)
    base.alpha_composite(im, (x, y))
    return base


# ---------------- the combo counter, drawn over the shot from the take's own count ----------------
RANKS = [(35, 'LEGENDARY'), (20, 'BRUTAL'), (10, 'GREAT'), (5, 'NICE')]


def rank_of(count):
    return next((name for minimum, name in RANKS if count >= minimum), '')


def tier_of(count):
    return 'salmon' if count >= 20 else 'amber' if count >= 10 else 'butter'


@lru_cache(maxsize=64)
def glyph(name):
    im = Image.open(os.path.join(HERE, 'titles', 'counter', f'{name}.png')).convert('RGBA')
    return im.crop(im.getbbox())


def count_events(shot):
    """for each source frame: the count, the frame of the last rise, the frame the rank last changed"""
    meta = frames_meta(shot)
    out = []
    last_rise = last_rank = -99
    prev = 0
    for f in meta:
        c = f.get('combo', 0)
        if c > prev:
            last_rise = f['i']
            if rank_of(c) != rank_of(prev):
                last_rank = f['i']
        prev = c
        out.append((c, last_rise, last_rank))
    return out


COUNTS = {}


def paste_scaled(base, im, scale, anchor_xy, align='right'):
    w, h = max(1, int(im.width * scale)), max(1, int(im.height * scale))
    im = im.resize((w, h), Image.NEAREST)
    x, y = anchor_xy
    x = x - w if align == 'right' else x - w // 2 if align == 'center' else x
    base.alpha_composite(im, (int(x), int(y - h / 2)))


def draw_counter(base, frame):
    spec = getattr(EDL, 'COUNTER', None)
    if not spec or not (spec['start'] <= frame < spec['end']):
        return base
    clip = spec['clip']
    cid = id(clip)
    if cid not in POSITIONS:
        POSITIONS[cid] = source_positions(clip)
    t = frame - clip['at']
    src = POSITIONS[cid][min(t, clip['dur'] - 1)]
    i = int(math.floor(src + 1e-6))
    shot = clip['src'][0]
    if shot not in COUNTS:
        COUNTS[shot] = count_events(shot)
    count, rise, rank_at = COUNTS[shot][min(i, len(COUNTS[shot]) - 1)]
    if count < 2:
        return base
    u = OW / 1920
    # the finale: the counter flies to the middle and grows as the shot dims
    fk = 0.0
    if 'finale' in spec and frame >= spec['finale'][0]:
        fk = ease_in_out((frame - spec['finale'][0]) / spec['finale'][1])
    bump = 1 + 0.32 * max(0.0, 1 - (src - rise) / 7)
    scale = spec.get('scale', 0.62) * (1 + 1.25 * fk)
    rx = spec['pos'][0] + (spec['center'][0] - spec['pos'][0]) * fk
    ty = spec['pos'][1] + (spec['center'][1] - spec['pos'][1]) * fk
    layer = Image.new('RGBA', (OW, OH), (0, 0, 0, 0))
    tier = tier_of(count)
    digits = [glyph(f'{tier}_{d}') for d in str(count)]
    gap = int(14 * scale * u)
    ds = scale * bump * u
    total = sum(int(g.width * ds) for g in digits) + gap * (len(digits) - 1)
    align = 'center' if fk > 0.5 else 'right'
    x = rx * u - (total / 2 if align == 'center' else total)
    top = ty * u
    dh = digits[0].height * ds
    for g in digits:
        paste_scaled(layer, g, ds, (x, top + dh / 2), 'left')
        x += int(g.width * ds) + gap
    below = top + digits[0].height * scale * u + 14 * scale * u
    hits = glyph('hits')
    paste_scaled(layer, hits, scale * u, (rx * u, below + hits.height * scale * u / 2), align)
    rank = rank_of(count)
    if rank:
        age = src - rank_at
        rs = scale * (1 + 0.9 * max(0.0, 1 - age / 8))
        g = glyph(rank)
        ry = below + hits.height * scale * u + 18 * scale * u + g.height * scale * u / 2
        paste_scaled(layer, g, rs * u, (rx * u, ry), align)
    a = spec.get('fade_in', 6)
    alpha = min(1.0, (frame - spec['start']) / a)
    if alpha < 1:
        arr = np.asarray(layer).astype(np.float32)
        arr[..., 3] *= alpha
        layer = Image.fromarray(arr.astype(np.uint8))
    base.alpha_composite(layer)
    return base


# ---------------- particles ----------------
def embers(base, t, count=70, seed=3, strength=1.0, color=(255, 190, 110)):
    if strength <= 0:
        return base
    rng = np.random.default_rng(seed)
    layer = Image.new('RGBA', (OW, OH), (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer)
    u = OW / 1920
    for n in range(count):
        x0, y0 = rng.uniform(0, 1), rng.uniform(0, 1)
        sp = rng.uniform(0.6, 1.8)
        size = rng.choice([3, 4, 5, 6]) * u
        ph = rng.uniform(0, 6.28)
        y = (y0 - t * 0.0016 * sp) % 1.1 - 0.05
        x = x0 + 0.02 * math.sin(t * 0.03 * sp + ph)
        a = int(200 * strength * (0.5 + 0.5 * math.sin(t * 0.08 * sp + ph)))
        X, Y = x * OW, y * OH
        dr.rectangle([X, Y, X + size, Y + size], fill=(*color, a))
    glow = layer.filter(ImageFilter.GaussianBlur(3 * u))
    base.alpha_composite(glow)
    base.alpha_composite(layer)
    return base


# ---------------- the home page's card flying open into the game ----------------
def render_focuspull(clip, t):
    """the launch screen's card bursts toward the camera and fades while its blurred painting
    sharpens into the game's own dusk; spec in clip['pull']"""
    p = clip['pull']
    d = clip['dur']
    k = t / max(1, d - 1)
    home = load_frame(*p['home'])
    title_i = p['title'][1] + int(t * p.get('title_speed', 1.0))
    title = load_frame(p['title'][0], title_i)
    # the game's dusk, framed first like the arcade's backdrop, then as the title frames it
    kz = ease_in_out(min(1.0, max(0.0, (k - p.get('settle_from', 0.25)) / (1 - p.get('settle_from', 0.25)))))
    z0, c0 = p['align']
    z1, c1 = p['end']
    zoom = z0 + (z1 - z0) * kz
    cx = c0[0] + (c1[0] - c0[0]) * kz
    cy = c0[1] + (c1[1] - c0[1]) * kz
    sw, sh = title.size
    base = np.asarray(view(title, zoom, cx * sw, cy * sh, smooth=True)).astype(np.float32)
    radius = p['blur'] * (1 - ease_in_out(min(1.0, k / p.get('focus_by', 0.85))))
    base = gaussian(base, radius)
    base = base * (1 - p.get('dark', 0.25) * (1 - ease_in_out(min(1.0, k / 0.6))))
    # the launch screen itself fades over the first frames
    fade = 1 - ease_in_out(min(1.0, t / p.get('home_fade', 10)))
    if fade > 0:
        h = np.asarray(view(home, 1.0 * p.get('home_zoom', 1.0), home.width / 2, home.height / 2, smooth=True)).astype(np.float32)
        base = base * (1 - fade) + h * fade
    # the card flies at the camera
    ck = ease_in(min(1.0, t / p['card_time']))
    if ck < 1:
        x0, y0, x1, y1 = p['card']
        sx = home.width / 1920
        card = home.crop((int(x0 * sx), int(y0 * sx), int(x1 * sx), int(y1 * sx)))
        s = 1 + 1.6 * ck
        w = int((x1 - x0) * s * OW / 1920)
        hgt = int((y1 - y0) * s * OW / 1920)
        card = card.resize((w, hgt), Image.LANCZOS).convert('RGBA')
        alpha = (1 - ck) ** 1.4
        a = np.full((hgt, w), 255 * alpha, np.float32)
        card.putalpha(Image.fromarray(a.astype(np.uint8)))
        img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8)).convert('RGBA')
        mx = ((x0 + x1) / 2) * OW / 1920
        my = ((y0 + y1) / 2) * OW / 1920
        img.alpha_composite(card, (int(mx - w / 2), int(my - hgt / 2)))
        base = np.asarray(img.convert('RGB')).astype(np.float32)
    return base


# ---------------- frame ----------------
TRACKS = {}
POSITIONS = {}


def clips_at(frame):
    return [c for c in EDL.CLIPS if c['at'] <= frame < c['at'] + c['dur']]


def render_clip(clip, frame):
    t = frame - clip['at']
    if 'pull' in clip:
        arr = render_focuspull(clip, t)
    else:
        cid = id(clip)
        if cid not in POSITIONS:
            POSITIONS[cid] = source_positions(clip)
        shot = clip['src'][0]
        if shot not in TRACKS:
            TRACKS[shot] = hero_track(shot)
        img = render_source(clip, t, POSITIONS[cid][t], TRACKS[shot])
        arr = np.asarray(img).astype(np.float32)
    arr = apply_frame_fx(arr, clip, t)
    return arr


def render_frame(frame):
    found = clips_at(frame)
    if not found:
        arr = np.zeros((OH, OW, 3), np.float32)
        clip = None
    else:
        clip = found[-1]
        arr = render_clip(clip, frame)
        xf = clip.get('xfade')
        if xf and len(found) > 1 and frame - clip['at'] < xf:
            k = ease_in_out((frame - clip['at']) / xf)
            under = render_clip(found[-2], frame)
            arr = under * (1 - k) + arr * k
    arr = arr * vignette()
    base = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).convert('RGBA')
    if clip is not None and clip.get('embers'):
        base = embers(base, frame, strength=interp_keys(clip['embers'], frame - clip['at']))
    base = draw_counter(base, frame)
    for spec in EDL.TEXTS:
        base = place_text(base, spec, frame)
    arr = np.asarray(base.convert('RGB')).astype(np.float32)
    arr = apply_frame_fx(arr, {'fx': EDL.GLOBAL_FX}, frame)
    arr = letterbox(arr, interp_keys(EDL.LETTERBOX, frame))
    return np.clip(arr, 0, 255).astype(np.uint8)


# ---------------- audio ----------------
def read_wav(path):
    w = wave.open(path)
    d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).reshape(-1, 2)
    return d.astype(np.float32) / 32768


def write_wav(path, data):
    d = np.clip(data, -1, 1)
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((d * 32767).astype(np.int16).tobytes())
    w.close()


def build_sfx():
    total = int(EDL.TOTAL / FPS * SR) + SR
    mix = np.zeros((total, 2), np.float32)
    cache = {}
    spf = SR / FPS
    for clip in EDL.CLIPS:
        if 'pull' in clip:
            continue
        gain = clip.get('gain', 1.0)
        if not isinstance(gain, list) and gain <= 0:
            continue
        shot = clip['src'][0]
        if shot not in cache:
            p = os.path.join(OUT, shot, 'audio.wav')
            cache[shot] = read_wav(p) if os.path.exists(p) else None
        src = cache[shot]
        if src is None:
            continue
        pos = source_positions(clip)
        n = int(clip['dur'] * spf)
        out_t = np.arange(n) / spf
        frame_idx = np.minimum(out_t.astype(int), clip['dur'] - 1)
        frac = out_t - frame_idx
        nxt = pos + [pos[-1] + (pos[-1] - pos[-2] if len(pos) > 1 else 1)]
        p0 = np.array(pos)[frame_idx]
        p1 = np.array(nxt)[frame_idx + 1]
        src_t = (p0 + (p1 - p0) * frac) * spf
        frozen = (p1 - p0) < 1e-6
        idx = np.clip(src_t, 0, len(src) - 2)
        i0 = idx.astype(int)
        fr = (idx - i0)[:, None]
        seg = src[i0] * (1 - fr) + src[i0 + 1] * fr
        seg[frozen] = 0
        fade_in = clip.get('afade', (120, 240))
        env = np.ones(n, np.float32)
        a_in, a_out = min(fade_in[0], n // 2), min(fade_in[1], n // 2)
        if a_in:
            env[:a_in] = np.linspace(0, 1, a_in)
        if a_out:
            env[-a_out:] = np.linspace(1, 0, a_out)
        if isinstance(gain, list):
            per_frame = np.array([interp_keys(gain, t) for t in range(clip['dur'] + 1)], np.float32)
            env *= np.interp(np.arange(n) / spf, np.arange(clip['dur'] + 1), per_frame)
            gain = 1.0
        a = int(clip['at'] * spf)
        mix[a:a + n] += seg * env[:, None] * gain
    write_wav(os.path.join(OUT, 'sfx60.wav'), mix)
    print('sfx written', mix.shape[0] / SR, 's peak', float(np.abs(mix).max()))


# ---------------- main ----------------
def encode(a, b, path):
    cmd = ['ffmpeg', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{OW}x{OH}',
           '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'medium' if HALF else 'slow',
           '-crf', '20' if HALF else '13', '-pix_fmt', 'yuv420p', '-tune', 'animation', path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for f in range(a, b):
        proc.stdin.write(render_frame(f).tobytes())
    proc.stdin.close()
    proc.wait()


def main():
    mode = ARGS[0]
    if mode == 'audio':
        build_sfx()
        return
    if mode == 'stills':
        os.makedirs(os.path.join(OUT, 'stills'), exist_ok=True)
        for f in [int(x) for x in ARGS[1].split(',')]:
            Image.fromarray(render_frame(f)).save(os.path.join(OUT, 'stills', f't_{f:05d}.png'))
        return
    a = int(arg('--from', 0))
    b = int(arg('--to', EDL.TOTAL))
    name = arg('--name', 'promo60_half' if HALF else 'promo60_video')
    if mode == 'parallel':
        jobs = int(arg('--jobs', 8))
        bounds = np.linspace(a, b, jobs + 1).astype(int)
        parts = []
        procs = []
        for j in range(jobs):
            part = os.path.join(OUT, f'{name}_part{j}.mp4')
            parts.append(part)
            cmd = [sys.executable, __file__, 'video', '--from', str(bounds[j]), '--to', str(bounds[j + 1]),
                   '--name', f'{name}_part{j}'] + (['--half'] if HALF else [])
            procs.append(subprocess.Popen(cmd))
        for p in procs:
            p.wait()
        lst = os.path.join(OUT, f'{name}_list.txt')
        open(lst, 'w').write(''.join(f"file '{p}'\n" for p in parts))
        subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy',
                        os.path.join(OUT, f'{name}.mp4')], check=True)
        print('wrote', os.path.join(OUT, f'{name}.mp4'))
        return
    encode(a, b, os.path.join(OUT, f'{name}.mp4'))
    print('wrote', name, a, b)


if __name__ == '__main__':
    main()
