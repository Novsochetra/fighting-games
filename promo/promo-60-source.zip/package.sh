#!/bin/sh
# Copies the finished promo, a lighter copy for sharing, and the source into the repo's promo/ folder
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
DEST=/Users/sochetranov/Documents/workspace/personal/fighting-games/promo
cp "$HERE/out/steel-and-dust-promo-60.mp4" "$DEST/steel-and-dust-promo-60.mp4"
ffmpeg -v error -y -i "$HERE/out/steel-and-dust-promo-60.mp4" -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
  -tune animation -c:a copy -movflags +faststart "$DEST/steel-and-dust-promo-60-share.mp4"
cd "$HERE"
rm -f "$DEST/promo-60-source.zip"
zip -q -r "$DEST/promo-60-source.zip" README.txt harness.js capture.mjs lib.mjs shots60.mjs combolab.mjs \
  titles60.mjs titles_home.mjs counter_glyphs.mjs instr.py music60.py edl60.py compose60.py master60.py \
  hits.py sheet.py package.sh
ls -la "$DEST" | grep -- "-60"
