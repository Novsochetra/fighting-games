// Page-side helpers the shots share: start a mission, fight with the autopilot, call raiders in
export const SIM = '/games/steel-and-dust/src/sim';

export async function startMission(api, missionIndex, hero) {
  await api.eval(
    async ({ SIM, missionIndex, hero }) => {
      const flow = await import(`${SIM}/stage/flow.js`);
      const { game } = window.__steelAndDust;
      game.settings.hero = hero;
      flow.selectMission(game, missionIndex);
      flow.startPlay(game);
      window.__flow = flow;
      window.__spawn = (await import(`${SIM}/stage/spawn-enemy.js`)).spawnEnemy;
    },
    { SIM, missionIndex, hero },
  );
  await api.settle(2500);
  await api.stepUntil(() => window.__steelAndDust.game.tickCount > 2, 600);
  // the loading screen fades by drawn frames; the canvas stays dark until it has
  await api.step(40);
}

export async function pilot(api, programs, extra = {}) {
  await api.eval(([programs, extra]) => window.__dir.autopilot({ programs, idleWalk: 1, ...extra }), [
    programs,
    extra,
  ]);
}

export async function spawnCrowd(api, kinds) {
  await api.eval((kinds) => {
    kinds.forEach(([kind, side]) => window.__spawn(window.__steelAndDust.game, kind, side));
  }, kinds);
}

export async function clearField(api) {
  await api.eval(() => {
    const { game } = window.__steelAndDust;
    game.crates = [];
    window.__dir.hooks.push(() => {
      game.pickups = [];
    });
  });
}

export const ALIVE = "game.fighters.filter((f) => f.side === 'enemy' && f.state !== 'ko' && !f.entering).length";

export const HUD_OFF = {
  drawPlayerPanel: false, drawClock: false, drawScore: false, drawPurse: false, drawCombo: false,
  drawBossBar: false, drawGoArrow: false, drawOffscreenArrows: false, drawBanner: false, drawMissionSummary: false,
};

// clears the road and stands a crowd around the hero at the given offsets, holding their ground
export async function lineUp(api, crowd, hp = 400) {
  await api.eval(async ({ crowd, hp }) => {
    const { groundAt } = await import('/games/steel-and-dust/src/sim/stage/terrain.js');
    const { game } = window.__steelAndDust;
    game.fighters = game.fighters.filter((f) => f.side !== 'enemy');
    game.pickups = [];
    game.crates = [];
    const p = game.player;
    p.facing = 1;
    for (const [kind, dx] of crowd) {
      window.__spawn(game, kind, 1);
      const e = game.fighters[game.fighters.length - 1];
      e.x = p.x + dx;
      e.y = groundAt(game.terrain, e.x);
      e.entering = false;
      e.state = 'idle';
      e.facing = dx > 0 ? -1 : 1;
      e.hp = e.maxHp = hp;
    }
    window.__holdEnemies = true;
  }, { crowd, hp });
}

export async function quiet(api, hud) {
  await api.eval((hud) => {
    window.__hud = hud;
    const { game } = window.__steelAndDust;
    window.__dir.hooks.push(() => {
      game.hint = null;
    });
  }, hud);
}
