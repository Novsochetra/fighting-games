# The 60 s cut: 60 fps, 120 BPM (a beat is 30 frames, a bar 120), beats counted from the logo hit.
# 'at' and 'dur' are timeline frames, 'src' is (shot, first source frame). speed: number or
# [(t, speed)] steps; zoom/center/offset: [(t, v)] eased keys. MARK names the cues the score follows.
TOTAL = 3600
L = 298  # the logo lands: beat 0


def B(n):
    return int(round(L + 30 * n))


C = []


def clip(src, at, dur, **kw):
    c = dict(src=src, at=at, dur=dur, **kw)
    C.append(c)
    return c


def hit(t, flash=0.5, shake=4, chroma=10, punch=0.06, dur=10):
    return [('flash', t, dur, flash * 0.55), ('shake', t, dur + 8, shake), ('chroma', t, 8, chroma),
            ('punch', t, 10, punch)]


def cut_in(flash=0.3, chroma=8):
    return [('flash', 0, 6, flash), ('chroma', 0, 5, chroma)]


# ---------- A. the arcade: Morodok Angkor, the carousel slides to Steel & Dust, Play, the card flies
# open and the camera dives into it (0-216)
clip(('home', 26), 0, 196, smooth=True, speed=[(0, 1), (140, 0.6)],
     zoom=[(0, 1.0), (100, 1.05)], center=[(0, (0.5, 0.40)), (100, (0.5, 0.42)), (132, (0.5, 0.454))],
     fx=[('fadein', 0, 14), ('punch', 100, 10, 0.012), ('pushin', 132, 64, 1.95),
         ('blur', [(0, 0), (150, 0), (196, 22)]), ('zblur', [(0, 0), (158, 0), (196, 0.07)])],
     gain=1.0)
clip(('title', 0), 172, 44, smooth=True, speed=0.64, xfade=24,
     zoom=[(0, 1.45), (44, 1.08)], center=(0.5, 0.47), fx=[('blur', [(0, 22), (40, 0)])], gain=0)

# ---------- B. the title, as it always opened: the dusk, the logo, Play, the hero select (216-598)
clip(('title', 28), 216, 82, smooth=True, zoom=[(0, 1.08), (82, 1.02)],
     center=[(0, (0.5, 0.47)), (82, (0.5, 0.46))], embers=[(0, 0.5), (40, 0.9)], gain=0)
clip(('title', 110), L, 120, smooth=True, zoom=[(0, 1.0), (100, 1.06)], center=(0.5, 0.47),
     fx=[('flash', 3, 16, 0.55), ('shake', 3, 22, 3), ('chroma', 3, 8, 12),
         ('punch', 104, 12, 0.08), ('flash', 104, 16, 0.95)], embers=1.0, gain=1.0)
STEPS = [12, 27, 42, 57, 80, 110]
clip(('title', 230), L + 120, 120, smooth=True, zoom=1.42, center=(0.5, 0.56),
     fx=[('fadein', 0, 6)] + [('punch', s, 8, 0.025) for s in STEPS], gain=1.0)
clip(('title', 350), L + 240, 60, smooth=True, speed=[(0, 1), (22, 0)],
     zoom=[(0, 1.42), (24, 2.1)], center=[(0, (0.5, 0.56)), (24, (0.44, 0.55))],
     fx=[('flash', 20, 10, 0.5), ('shadeleft', 18, 42), ('flash', 54, 6, 1.0)], gain=1.0)

# ---------- C. one road: Bokator sprints on, the world behind him changes on every beat, then
# half-beats, and the mosaic opens on Angkor Wat (598-838)
ROAD = [('road_pine', 30), ('road_grove', 30), ('road_bamboo', 30), ('road_ember', 30), ('road_firefly', 30),
        ('road_sand', 15), ('road_warden', 15)]
at = B(10)
for n, (shot, dur) in enumerate(ROAD):
    z0 = 1.42 + 0.04 * (n % 2)
    clip((shot, 45), at, dur, zoom=[(0, z0), (dur, z0 + 0.06)], offset=(64, -95),
         fx=[('flash', 0, 6, 0.32 if dur == 30 else 0.22), ('chroma', 0, 5, 8)] + ([('shake', 0, 8, 2)] if n == 0 else []),
         gain=0.9)
    at += dur
ARRIVE = at
clip(('arrive', 14), ARRIVE, B(18) - ARRIVE, zoom=[(0, 1.18), (60, 1.1)], center=(0.5, 0.44), gain=1.0)

# ---------- D. the drop: ten raiders at Angkor Wat, and one combo (838-1408): jab, cross, hook on the
# eighths before the drop, the Rising Knee launches on it, an air string, a Falling Elbow bounce,
# LEGENDARY at 35, a charged Tiger Rush lets go on the downbeat, and the camera runs to the counter
D0 = B(18)
COMBO_SPEED = [(0, 1), (60, 0), (64, 1), (387, 0.8), (473, 1), (494, 0.5), (514, 1)]
COMBO = clip(('combo_clean', 27), D0, B(37) - D0, speed=COMBO_SPEED,
             zoom=[(0, 1.62), (56, 1.5), (62, 1.38), (380, 1.45), (472, 2.05), (480, 1.32), (518, 1.32), (570, 1.55)],
             offset=[(0, (70, -66)), (380, (80, -70)), (472, (12, -36)), (480, (120, -80)), (570, (110, -70))],
             fx=hit(14, 0.15, 2, 4, 0.02) + hit(28, 0.15, 2, 4, 0.02) + hit(43, 0.2, 3, 6, 0.03)
             + hit(60, 0.6, 7, 16, 0.1, 12) + [('bloom', 60, 40, 0.35)]
             + hit(141, 0.4, 5, 10, 0.05)
             + hit(329, 0.5, 5, 12, 0.07) + [('bloom', 329, 30, 0.3)]
             + [('darken', [(380, 0), (400, 0.14), (472, 0.18), (479, 0)])]
             + hit(479, 0.7, 10, 22, 0.14, 14) + [('bloom', 479, 60, 0.4)]
             + hit(500, 0.3, 4, 8, 0.03) + [('darken', [(514, 0), (536, 0.5), (570, 0.5)])],
             gain=[(0, 1), (387, 1), (395, 0.85), (473, 1)])
COUNTER = dict(clip=COMBO, start=D0 + 14, end=B(37), pos=(1836, 64), center=(960, 300), scale=0.62,
               finale=(D0 + 518, 20))

# ---------- E. a boss at the end of each mission: their name cards, a lion on each (1408-1618)
E0 = B(37)
WHIP_OUT = [('whipout', 52, 8, 0.55, 0), ('mblur', [(52, 0), (60, 110)])]
WHIP_IN = [('whipin', 0, 9, -0.55, 0), ('mblur', [(0, 110), (9, 0)]), ('chroma', 0, 6, 8)]
BOSS_VIEW = dict(zoom=[(0, 1.36), (60, 1.3)], center=(0.384, 0.55))
clip(('boss_naga', 76), E0, 60, fx=cut_in(0.35) + hit(30, 0.5, 5, 12, 0.06) + WHIP_OUT, gain=1.0, **BOSS_VIEW)
clip(('boss_furnace', 63), E0 + 60, 60, fx=WHIP_IN + hit(30, 0.5, 5, 12, 0.06) + WHIP_OUT, gain=1.0, **BOSS_VIEW)
clip(('boss_warden', 63), E0 + 120, B(44) - E0 - 120, speed=[(0, 1), (83, 0)],
     fx=WHIP_IN + hit(30, 0.5, 5, 12, 0.06) + hit(74, 0.4, 4, 10, 0.05) + hit(83, 0.7, 7, 16, 0.08),
     gain=[(0, 1), (83, 1), (86, 0)], **BOSS_VIEW)

# ---------- F. the breakdown: a slow walk under the Bayon's faces at night (1618-1858)
F0 = B(44)
clip(('bayon_walk', 40), F0, B(52) - F0, speed=0.5, zoom=[(0, 1.28), (240, 1.58)], offset=(110, -118),
     fx=[('fadein', 0, 36), ('grade', 0.92, 1.0, (0.96, 0.98, 1.06))], gain=0.6)

# ---------- G. the five Shades, an ultimate each: the cut-in, then the blow on the beat
G0 = B(52)
HEROES = [('moss', 146), ('firefly', 163), ('antler', 172), ('blue', 169), ('ember', 189)]
for n, (hero, peak) in enumerate(HEROES):
    at = G0 + 60 * n
    clip((f'ult_{hero}', 36), at, 14, zoom=1.0, center=(0.5, 0.5), fx=cut_in(0.45, 10), gain=0.9)
    clip((f'ult_{hero}', peak - 16), at + 14, 46, zoom=[(0, 1.22), (46, 1.34)], offset=(50, -70),
         fx=hit(16, 0.28, 6, 14, 0.07) + [('bloom', 16, 30, 0.25)], gain=0.95)

# ---------- G2. the Angkor Warrior steps out of the Bayon walls: a string, the Churning of the Sea,
# the Meteor Fist's soldiers, a Tiger Rush of three, and Thousand Cuts (2158-2398)
AW0 = B(62)
AW_VIEW = dict(zoom=[(0, 1.62), (75, 1.5)], offset=(70, -66))
clip(('aw_combo', 42), AW0, 75, fx=[('flash', 0, 10, 0.5), ('shake', 0, 16, 4), ('chroma', 0, 8, 12)]
     + hit(13, 0.15, 2, 4, 0.02) + hit(28, 0.15, 2, 4, 0.02) + hit(60, 0.5, 6, 14, 0.07) + [('bloom', 60, 15, 0.3)],
     gain=1.0, **AW_VIEW)
clip(('aw_combo', 143), AW0 + 75, 60, zoom=[(0, 1.75), (60, 1.6)], offset=(80, -70),
     fx=cut_in(0.25) + hit(15, 0.4, 5, 12, 0.06) + hit(24, 0.2, 3, 6, 0.03) + hit(33, 0.2, 3, 6, 0.03),
     gain=1.0)
clip(('aw_combo', 254), AW0 + 135, 45, zoom=[(0, 1.5), (45, 1.42)], offset=(110, -78),
     fx=cut_in(0.25) + hit(17, 0.45, 6, 14, 0.07) + hit(35, 0.35, 5, 10, 0.05) + [('bloom', 17, 25, 0.3)],
     gain=1.0)
clip(('aw_combo', 366), AW0 + 180, 30, zoom=[(0, 1.38), (30, 1.3)], offset=(120, -80),
     fx=cut_in(0.3) + hit(7, 0.6, 8, 18, 0.1) + [('bloom', 7, 23, 0.4)], gain=1.0)
clip(('ult_angkor', 38), AW0 + 210, 10, zoom=1.0, center=(0.5, 0.5), fx=cut_in(0.45, 10), gain=0.9)
clip(('ult_angkor', 160), AW0 + 220, 20, zoom=[(0, 1.3), (20, 1.4)], offset=(50, -70),
     fx=hit(8, 0.35, 8, 16, 0.08) + [('bloom', 8, 12, 0.35)], gain=0.95)

# ---------- H. the last fight: the Bayon Guardian walks on, Bokator answers with Pounding the Lion,
# and the Guardian falls (2398-3058)
H0 = B(70)
clip(('finale', 0), H0, 90, speed=[(0, 0.7), (50, 1.3)], zoom=[(0, 1.3), (90, 1.18)], center=[(0, (0.45, 0.5)), (90, (0.47, 0.52))],
     fx=[('flash', 0, 10, 0.6), ('shake', 0, 24, 4), ('chroma', 0, 10, 14)], gain=1.0)
H1 = H0 + 90
clip(('finale', 96), H1, 120, zoom=[(0, 1.25), (120, 1.3)], offset=(-40, -80),
     fx=hit(89, 0.4, 4, 10, 0.05) + hit(99, 0.4, 4, 10, 0.05), gain=1.0)
H2 = H1 + 120
ULT_SPEED = [(0, 1), (267, 0.35), (353, 1)]
clip(('finale', 248), H2, B(92) - H2, speed=ULT_SPEED,
     zoom=[(0, 1.0), (52, 1.0), (56, 1.25), (267, 1.32), (326, 1.12), (440, 1.12), (B(92) - H2, 1.22)],
     center=[(0, (0.5, 0.5)), (52, (0.5, 0.5)), (56, (0.35, 0.6)), (267, (0.3, 0.58)), (326, (0.47, 0.52)),
             (440, (0.47, 0.52)), (B(92) - H2, (0.45, 0.56))],
     fx=hit(55, 0.6, 7, 16, 0.08) + [('bloom', 55, 200, 0.25)] + hit(267, 0.9, 10, 22, 0.12, 14)
     + [('bloom', 267, 60, 0.4), ('tint', [(B(92) - H2 - 14, 0), (B(92) - H2, 0.8)], (255, 248, 230))],
     gain=[(0, 1), (267, 1), (296, 0.7), (353, 1)])

# ---------- I. the end card, and back out to the arcade (3058-3600)
I0 = B(92)
clip(('endcard', 20), I0, 220, smooth=True, zoom=[(0, 1.3), (220, 1.26)], center=(0.5, 0.58),
     fx=[('flash', 0, 18, 0.8), ('shake', 0, 20, 2), ('chroma', 0, 8, 10)], embers=[(0, 0.4), (60, 1.0)], gain=0)
HOME_END = I0 + 180
clip(('home', 100), HOME_END, TOTAL - HOME_END, smooth=True, speed=0, xfade=40,
     zoom=[(0, 2.34), (170, 1.0)], center=[(0, (0.57, 0.324)), (170, (0.5, 0.5))],
     fx=[('bottomdim', 140, 60, 0.95)], gain=0)

CLIPS = C

# (name, start, dur, (x, y), anim, scale, out_frames)
HERO_NAMES = []
for n, (hero, _) in enumerate(HEROES):
    HERO_NAMES.append(('text', hero, G0 + 60 * n + 16, 42, (0.5, 0.84), 'rise', 0.62, 6))

TEXTS = [
    ('text', 'ends_angkor', 220, 76, (0.5, 0.80), 'fade', 1.0),
    ('text', 'bokator', L + 258, 44, (0.27, 0.42), 'slam', 0.85, 6),
    ('text', 'bokator_sub', L + 268, 34, (0.27, 0.60), 'rise', 0.72, 6),
    ('text', 'one_road', B(10), 56, (0.5, 0.2), 'slam', 0.72, 8),
    ('text', 'twelve', B(12), 56, (0.5, 0.2), 'slam', 0.72, 8),
    ('text', 'choose', B(48), 100, (0.5, 0.3), 'fade', 0.8, 16),
] + HERO_NAMES + [
    ('text', 'angkor', AW0, 70, (0.5, 0.17), 'slam', 0.78, 8),
    ('text', 'angkor_sub', AW0 + 10, 60, (0.5, 0.31), 'rise', 0.8, 8),
] + [
    ('text', 'tags', I0 + 50, 130, (0.5, 0.64), 'wipe', 1.0, 14),
    ('text', 'free', I0 + 90, 90, (0.5, 0.74), 'slam', 1.0, 14),
    ('text', 'home_url', HOME_END + 190, TOTAL - HOME_END - 190, (0.5, 0.86), 'rise', 0.5, 1),
    ('text', 'home_free', HOME_END + 206, TOTAL - HOME_END - 206, (0.5, 0.925), 'rise', 0.5, 1),
]

LETTERBOX = [(0, 0), (H0, 0), (H0 + 20, 96), (B(92) - 10, 96), (B(92), 0)]

GLOBAL_FX = [('fadeout', TOTAL - 36, 36)]

MARK = dict(logo=L, click=L + 105, select=L + 120, choose=L + 258, road=B(10), arrive=ARRIVE, combo=D0,
            drop1=B(20), legendary=B(29) - 1, charge=D0 + 387, release=D0 + 479, counter=D0 + 520,
            bosses=E0, breakdown=F0, heroes=G0, aw=AW0, finale=H0, fight=H1, ult=H2, ko=H2 + 267, endcard=I0,
            home_end=HOME_END)
