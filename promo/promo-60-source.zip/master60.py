# Mixes the score with the game's own sound, masters to -14 LUFS, and muxes the final promo.
#   python3 master60.py [video.mp4] [out.mp4]
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
video = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, 'promo60_video.mp4')
final = sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, 'steel-and-dust-promo-60.mp4')

# the game's hits ride a touch under the score, glued by a gentle bus compressor; the end fades
CHAIN = (
    "[0:a]volume=1.0[m];[1:a]volume=0.7,acompressor=threshold=-18dB:ratio=3:attack=2:release=80:makeup=1.2[s];"
    "[m][s]amix=inputs=2:normalize=0:duration=longest,atrim=0:60,"
    "afade=t=in:st=0:d=0.25,afade=t=out:st=59.2:d=0.8,"
    "acompressor=threshold=-14dB:ratio=2.2:attack=12:release=220:makeup=1.25,"
    "alimiter=limit=0.89:level=false"
)
inputs = ['-i', os.path.join(OUT, 'music60.wav'), '-i', os.path.join(OUT, 'sfx60.wav')]

r = subprocess.run(['ffmpeg', '-hide_banner', '-y', *inputs, '-filter_complex',
                    CHAIN + ',loudnorm=I=-14:TP=-1.2:LRA=11:print_format=json', '-f', 'null', '-'],
                   capture_output=True, text=True)
m = json.loads(re.findall(r'\{[^{}]*"input_i"[^{}]*\}', r.stderr)[-1])
print('measured', {k: m[k] for k in ('input_i', 'input_tp', 'input_lra')})
norm = (f"loudnorm=I=-14:TP=-1.2:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
        f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
mix = os.path.join(OUT, 'mix60.wav')
subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', *inputs, '-filter_complex',
                CHAIN + ',' + norm + ',aresample=48000', '-c:a', 'pcm_s16le', mix], check=True)
subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', video, '-i', mix,
                '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k',
                '-movflags', '+faststart', '-shortest', final], check=True)
r = subprocess.run(['ffmpeg', '-hide_banner', '-i', mix, '-af', 'ebur128=peak=true', '-f', 'null', '-'],
                   capture_output=True, text=True)
print('\n'.join(r.stderr.strip().splitlines()[-12:]))
print('wrote', final)
